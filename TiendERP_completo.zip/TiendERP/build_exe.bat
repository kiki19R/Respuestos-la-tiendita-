@echo off
:: ============================================================
:: build_exe.bat
:: Script de compilación — ERP Repuestos La Tiendita
:: Ejecutar en Windows dentro de la carpeta del proyecto:
::     build_exe.bat
:: ============================================================

title Compilando ERP Repuestos La Tiendita...
color 0B

echo.
echo  =========================================================
echo   ERP Repuestos La Tiendita — Generador de .EXE
echo  =========================================================
echo.

:: ── 1. Verificar Python ──────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Python no encontrado.
    echo  Descargue Python 3.11 o superior desde https://python.org
    echo  Asegurese de marcar "Add to PATH" al instalar.
    pause & exit /b 1
)
echo  [OK] Python encontrado

:: ── 2. Instalar dependencias ─────────────────────────────────
echo.
echo  Instalando dependencias...
echo  ─────────────────────────────────────────────
pip install customtkinter Pillow fpdf2 openpyxl reportlab PyInstaller ^
    --quiet --upgrade
if errorlevel 1 (
    echo  [ERROR] Fallo al instalar dependencias
    pause & exit /b 1
)
echo  [OK] Dependencias instaladas

:: ── 3. Limpiar compilaciones anteriores ──────────────────────
echo.
echo  Limpiando compilaciones anteriores...
if exist "dist\TiendERP" rmdir /s /q "dist\TiendERP"
if exist "build"         rmdir /s /q "build"
echo  [OK] Limpieza completada

:: ── 4. Compilar con PyInstaller ──────────────────────────────
echo.
echo  Compilando (esto tarda 2-5 minutos)...
echo  ─────────────────────────────────────────────
pyinstaller tiendita.spec --clean --noconfirm
if errorlevel 1 (
    echo.
    echo  [ERROR] La compilacion fallo.
    echo  Revise los mensajes de error arriba.
    pause & exit /b 1
)

:: ── 5. Copiar archivos de datos al dist ──────────────────────
echo.
echo  Copiando base de datos y recursos...
set DEST=dist\TiendERP

:: Base de datos SQLite
if exist "tiendita_erp.db" (
    copy /y "tiendita_erp.db" "%DEST%\tiendita_erp.db" >nul
    echo  [OK] tiendita_erp.db copiada
) else (
    echo  [WARN] tiendita_erp.db no encontrada - se creara al primer inicio
)

:: Carpeta de activos
if exist "assets" (
    xcopy /e /i /q "assets" "%DEST%\assets" >nul
    echo  [OK] assets copiada
)

:: Crear carpetas necesarias en dist
mkdir "%DEST%\facturas_pdf" 2>nul
mkdir "%DEST%\reports"      2>nul
echo  [OK] Carpetas de trabajo creadas

:: ── 6. Crear acceso directo ───────────────────────────────────
echo.
echo  Creando acceso directo en el escritorio...
set SCRIPT=%TEMP%\create_shortcut.vbs
echo Set oWS = WScript.CreateObject("WScript.Shell")                > %SCRIPT%
echo sLinkFile = oWS.SpecialFolders("Desktop") ^& "\TiendERP.lnk" >> %SCRIPT%
echo Set oLink = oWS.CreateShortcut(sLinkFile)                     >> %SCRIPT%
echo oLink.TargetPath = "%CD%\dist\TiendERP\TiendERP.exe"         >> %SCRIPT%
echo oLink.WorkingDirectory = "%CD%\dist\TiendERP"                 >> %SCRIPT%
echo oLink.Description = "ERP Repuestos La Tiendita"               >> %SCRIPT%
echo oLink.Save                                                     >> %SCRIPT%
cscript //nologo %SCRIPT%
del %SCRIPT%
echo  [OK] Acceso directo creado en el escritorio

:: ── 7. Resultado final ────────────────────────────────────────
echo.
echo  =========================================================
echo   COMPILACION EXITOSA
echo  =========================================================
echo.
echo   Ejecutable:  dist\TiendERP\TiendERP.exe
echo   Tamano:      %~z0
echo.
echo   Para distribuir: copie la carpeta  dist\TiendERP\
echo   completa a la otra computadora. No requiere Python.
echo.
echo   Para instalar en otra PC:
echo     1. Copie la carpeta TiendERP a C:\TiendERP\
echo     2. Cree un acceso directo a TiendERP.exe
echo     3. ^(Opcional^) Copie su tiendita_erp.db
echo.

:: Abrir la carpeta dist al terminar
explorer "dist\TiendERP"
pause
