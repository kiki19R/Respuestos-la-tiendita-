"""
utils/factura_pdf.py
Generador de facturas PDF con fpdf2 — ERP Repuestos La Tiendita

Instalación:
    pip install fpdf2

Uso directo:
    from utils.factura_pdf import FacturaPDF
    pdf = FacturaPDF(id_venta=3)
    ruta = pdf.guardar()          # guarda en facturas_pdf/FAC-00003.pdf
    pdf.guardar("C:/mis_pdfs/")   # guarda en carpeta específica

Uso desde el ERP (con diálogo):
    from utils.factura_pdf import imprimir_factura
    imprimir_factura(id_venta=3, parent=self)
"""

import os
import sqlite3
from datetime import datetime

# ── Rutas ─────────────────────────────────────────────────────────────────────
from utils.paths import BASE_DIR, DB_PATH, FACTS_DIR

# ── Paleta corporativa (R,G,B en 0-255) ──────────────────────────────────────
C_AZUL_OSC  = (13,  27,  42)     # #0D1B2A  fondo header
C_AZUL_CLA  = (46, 109, 164)     # #2E6DA4  botones / total
C_AZUL_ACE  = (61, 158, 232)     # #3D9EE8  número de factura
C_GRIS_BG   = (244, 246, 249)    # #F4F6F9  fondo franjas
C_GRIS_BR   = (180, 195, 215)    # texto secundario / bordes
C_NEGRO     = (26,  26,  46)     # #1A1A2E  texto principal
C_VERDE     = (30, 132,  73)     # #1E8449  estado Pagada
C_ROJO      = (192,  57,  43)    # #C0392B  estado Anulada
C_BLANCO    = (255, 255, 255)


# ══════════════════════════════════════════════════════════════════════════════
class FacturaPDF:
    """
    Genera una factura en PDF usando fpdf2.
    Diseño A4 vertical con header azul marino, tabla de productos
    y bloque de totales.
    """

    PAGE_W  = 210   # mm — A4
    PAGE_H  = 297
    MARGIN  = 12    # mm — márgenes laterales

    # anchos de columna de la tabla (mm) — total ~186
    COL_W = [22, 80, 16, 28, 14, 26]
    COL_H  = ["Código", "Descripción", "Cant.", "Precio Unit.", "Desc.", "Subtotal"]
    COL_AL = ["C",      "L",           "C",     "R",            "C",     "R"]

    # ── Constructor ──────────────────────────────────────────────────────────
    def __init__(self, id_venta: int):
        self.id_venta = id_venta
        self._venta, self._detalle, self._cfg = self._cargar_datos()

    # ── Carga de datos ────────────────────────────────────────────────────────
    def _cargar_datos(self):
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row

        venta = conn.execute(
            "SELECT * FROM Ventas WHERE id_venta = ?", (self.id_venta,)
        ).fetchone()
        if not venta:
            conn.close()
            raise ValueError(f"No existe la venta id={self.id_venta}")

        detalle = conn.execute("""
            SELECT d.descripcion, d.cantidad, d.precio_unitario,
                   d.descuento,   d.subtotal,
                   COALESCE(i.codigo, '') AS codigo
            FROM VentaDetalle d
            LEFT JOIN Inventario i ON i.id_producto = d.id_producto
            WHERE d.id_venta = ?
            ORDER BY d.id_detalle
        """, (self.id_venta,)).fetchall()

        cfg = {r["clave"]: r["valor"]
               for r in conn.execute("SELECT clave, valor FROM Configuracion")}
        conn.close()
        return dict(venta), [dict(d) for d in detalle], cfg

    # ── API pública ───────────────────────────────────────────────────────────
    def guardar(self, destino: str = None) -> str:
        """
        Genera el PDF y lo guarda.
        destino : carpeta o ruta completa (.pdf). Si None → facturas_pdf/
        Devuelve la ruta absoluta del archivo generado.
        """
        if destino is None:
            ruta = os.path.join(FACTS_DIR,
                                f"{self._num_fac()}.pdf")
        elif os.path.isdir(destino):
            ruta = os.path.join(destino, f"{self._num_fac()}.pdf")
        else:
            ruta = destino

        pdf = self._construir_fpdf2()
        pdf.output(ruta)
        return ruta

    def _num_fac(self) -> str:
        return (self._venta.get("numero_factura") or
                f"FAC-{self.id_venta:05d}").replace("/", "-")

    # ── Construcción con fpdf2 ────────────────────────────────────────────────
    def _construir_fpdf2(self):
        from fpdf import FPDF, XPos, YPos

        v   = self._venta
        det = self._detalle
        cfg = self._cfg

        empresa  = cfg.get("empresa_nombre",    "Repuestos La Tiendita")
        rif      = cfg.get("empresa_rif",       "")
        direccion= cfg.get("empresa_direccion", "")
        telefono = cfg.get("empresa_telefono",  "")
        email    = cfg.get("empresa_email",     "")
        moneda   = cfg.get("moneda_simbolo",    "Bs.")
        iva_pct  = float(cfg.get("iva_porcentaje", "16"))
        num_fac  = self._num_fac()

        # ── Subclase con pie de página ──
        class Doc(FPDF):
            def header(self_inner): pass
            def footer(self_inner):
                self_inner.set_y(-14)
                self_inner.set_font("Helvetica", "I", 7)
                self_inner.set_text_color(*C_GRIS_BR)
                self_inner.cell(
                    0, 5,
                    f"{empresa}  ·  {telefono}  ·  {email}"
                    f"  ·  Generado: {datetime.now().strftime('%d/%m/%Y %H:%M')}",
                    align="C"
                )

        pdf = Doc(orientation="P", unit="mm", format="A4")
        pdf.set_auto_page_break(auto=True, margin=18)
        pdf.set_margins(self.MARGIN, 0, self.MARGIN)
        pdf.add_page()

        m = self.MARGIN          # alias corto
        cw = self.PAGE_W - m*2  # ancho útil

        # ═══════════════════════════════════
        # BLOQUE 1 — HEADER AZUL MARINO
        # ═══════════════════════════════════
        HDR_H = 44
        pdf.set_fill_color(*C_AZUL_OSC)
        pdf.rect(0, 0, self.PAGE_W, HDR_H, style="F")

        # ── Logo real de la empresa ──
        _logo_path = os.path.join(ASSETS_DIR, "logo_factura.png")
        if os.path.exists(_logo_path):
            pdf.image(_logo_path, x=m, y=4, h=34)   # altura fija 34mm, ancho auto
        else:
            # Fallback: círculo con iniciales
            pdf.set_fill_color(*C_AZUL_CLA)
            pdf.ellipse(m, 8, 18, 18, style="F")
            pdf.set_font("Helvetica", "B", 13)
            pdf.set_text_color(*C_BLANCO)
            pdf.set_xy(m, 11)
            pdf.cell(18, 12, "RT", align="C")

        # ── Nombre de la empresa ──
        pdf.set_font("Helvetica", "B", 19)
        pdf.set_text_color(*C_BLANCO)
        pdf.set_xy(m + 40, 9)
        pdf.cell(0, 10, empresa, new_x=XPos.LMARGIN, new_y=YPos.NEXT)

        # ── Datos de contacto ──
        pdf.set_font("Helvetica", "", 7.5)
        pdf.set_text_color(*C_GRIS_BR)
        pdf.set_x(m + 22)
        linea_contacto = (
            f"RIF: {rif}"
            + (f"   |   {direccion}"  if direccion  else "")
            + (f"   |   Tel: {telefono}" if telefono else "")
            + (f"   |   {email}"      if email      else "")
        )
        pdf.cell(0, 5, linea_contacto)

        # ── Número de factura (derecha del header) ──
        pdf.set_font("Helvetica", "B", 17)
        pdf.set_text_color(*C_AZUL_ACE)
        pdf.set_xy(self.PAGE_W - m - 68, 9)
        pdf.cell(68, 10, num_fac, align="R")

        pdf.set_font("Helvetica", "B", 8)
        pdf.set_text_color(*C_GRIS_BR)
        pdf.set_xy(self.PAGE_W - m - 68, 20)
        pdf.cell(68, 5, "F A C T U R A", align="R")

        # ═══════════════════════════════════
        # BLOQUE 2 — DATOS CLIENTE / FECHA
        # ═══════════════════════════════════
        y2 = HDR_H + 6
        CLIENTE_H = 28

        pdf.set_fill_color(*C_GRIS_BG)
        pdf.rect(m, y2, cw, CLIENTE_H, style="F")

        # Columna izquierda — cliente
        pdf.set_xy(m + 4, y2 + 4)
        pdf.set_font("Helvetica", "B", 7)
        pdf.set_text_color(*C_GRIS_BR)
        pdf.cell(50, 4, "CLIENTE", new_x=XPos.LMARGIN, new_y=YPos.NEXT)

        pdf.set_x(m + 4)
        pdf.set_font("Helvetica", "B", 12)
        pdf.set_text_color(*C_NEGRO)
        nombre_cli = v.get("nombre_cliente") or "Consumidor Final"
        pdf.cell(100, 7, nombre_cli)

        # Estado de la factura
        estado = v.get("estado") or "Pagada"
        col_est = C_VERDE if estado == "Pagada" else (C_AZUL_CLA if estado == "Crédito" else C_ROJO)
        pdf.set_font("Helvetica", "B", 9)
        pdf.set_text_color(*col_est)
        pdf.set_xy(m + 4, y2 + 18)
        pdf.cell(50, 5, f"● {estado}")

        # Columna derecha — fecha, forma de pago
        fecha_str = v.get("fecha") or ""
        try:
            fecha_str = datetime.strptime(fecha_str[:10], "%Y-%m-%d").strftime("%d/%m/%Y")
        except Exception:
            pass

        derecha = [
            ("FECHA",          fecha_str),
            ("FORMA DE PAGO",  v.get("forma_pago") or "Contado"),
        ]
        for i, (lbl, val) in enumerate(derecha):
            y_d = y2 + 4 + i * 12
            pdf.set_xy(self.PAGE_W - m - 70, y_d)
            pdf.set_font("Helvetica", "B", 7)
            pdf.set_text_color(*C_GRIS_BR)
            pdf.cell(70, 4, lbl, align="R")
            pdf.set_xy(self.PAGE_W - m - 70, y_d + 4)
            pdf.set_font("Helvetica", "", 10)
            pdf.set_text_color(*C_NEGRO)
            pdf.cell(70, 5, val, align="R")

        # ═══════════════════════════════════
        # BLOQUE 3 — TABLA DE PRODUCTOS
        # ═══════════════════════════════════
        y3 = y2 + CLIENTE_H + 6
        pdf.set_y(y3)

        # — Cabecera de tabla —
        pdf.set_fill_color(*C_AZUL_OSC)
        pdf.set_text_color(*C_BLANCO)
        pdf.set_font("Helvetica", "B", 8)
        pdf.set_x(m)
        for txt, w, al in zip(self.COL_H, self.COL_W, self.COL_AL):
            pdf.cell(w, 8, txt, border=0, align=al, fill=True)
        pdf.ln()

        # — Filas de productos —
        pdf.set_font("Helvetica", "", 9)
        for idx, item in enumerate(det):
            bg = C_GRIS_BG if idx % 2 == 0 else C_BLANCO
            pdf.set_fill_color(*bg)
            pdf.set_text_color(*C_NEGRO)
            pdf.set_x(m)

            qty = float(item.get("cantidad") or 0)
            pu  = float(item.get("precio_unitario") or 0)
            dsc = float(item.get("descuento") or 0)
            sub = float(item.get("subtotal") or 0)

            filas_vals = [
                (item.get("codigo", "") or "—",      self.COL_AL[0]),
                ((item.get("descripcion") or "")[:46], self.COL_AL[1]),
                (f"{qty:g}",                          self.COL_AL[2]),
                (f"{moneda} {pu:,.2f}",               self.COL_AL[3]),
                (f"{dsc:.0f}%",                       self.COL_AL[4]),
                (f"{moneda} {sub:,.2f}",              self.COL_AL[5]),
            ]
            for (txt, al), w in zip(filas_vals, self.COL_W):
                pdf.cell(w, 7, txt, border=0, align=al, fill=True)
            pdf.ln()

        # — Línea inferior de tabla —
        y_fin_tabla = pdf.get_y()
        pdf.set_draw_color(*C_GRIS_BR)
        pdf.line(m, y_fin_tabla, self.PAGE_W - m, y_fin_tabla)

        # ═══════════════════════════════════
        # BLOQUE 4 — TOTALES
        # ═══════════════════════════════════
        subtotal  = float(v.get("subtotal")  or 0)
        descuento = float(v.get("descuento") or 0)
        impuesto  = float(v.get("impuesto")  or 0)
        total     = float(v.get("total")     or 0)

        y4 = y_fin_tabla + 4
        TX = self.PAGE_W - m - 70    # x inicial columna de totales
        TW_LBL = 42                  # ancho del label
        TW_VAL = 28                  # ancho del valor

        def _fila_tot(label, valor, bold=False, color=C_NEGRO, bg=None):
            nonlocal y4
            if bg:
                pdf.set_fill_color(*bg)
                pdf.rect(TX - 2, y4 - 1, TW_LBL + TW_VAL + 4, 8, style="F")
            pdf.set_font("Helvetica", "B" if bold else "", 10 if bold else 9)
            pdf.set_text_color(*color)
            pdf.set_xy(TX, y4)
            pdf.cell(TW_LBL, 7, label, align="R")
            pdf.set_font("Helvetica", "B" if bold else "", 10 if bold else 9)
            pdf.cell(TW_VAL, 7, f"{moneda} {valor:,.2f}", align="R")
            y4 += 7

        _fila_tot("Subtotal:",           subtotal)
        if descuento > 0:
            _fila_tot("Descuento:",      descuento, color=C_ROJO)
        if impuesto > 0:
            _fila_tot(f"IVA ({iva_pct:.0f}%):", impuesto)

        # Total con fondo azul marino
        y4 += 1
        _fila_tot("TOTAL:", total, bold=True,
                  color=C_BLANCO, bg=C_AZUL_OSC)

        # ═══════════════════════════════════
        # BLOQUE 5 — NOTAS (si hay)
        # ═══════════════════════════════════
        notas = (v.get("notas") or "").strip()
        if notas:
            y5 = pdf.get_y() + 8
            pdf.set_xy(m, y5)
            pdf.set_font("Helvetica", "B", 8)
            pdf.set_text_color(*C_GRIS_BR)
            pdf.cell(0, 5, "NOTAS", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            pdf.set_x(m)
            pdf.set_font("Helvetica", "", 8.5)
            pdf.set_text_color(*C_NEGRO)
            pdf.multi_cell(cw, 5, notas[:400])

        # ═══════════════════════════════════
        # BLOQUE 6 — AGRADECIMIENTO
        # ═══════════════════════════════════
        y6 = max(pdf.get_y() + 10, self.PAGE_H - 38)
        pdf.set_xy(0, y6)
        pdf.set_font("Helvetica", "I", 10)
        pdf.set_text_color(*C_AZUL_CLA)
        pdf.cell(self.PAGE_W, 6,
                 "¡Gracias por su preferencia!  —  " + empresa,
                 align="C")

        return pdf


# ══════════════════════════════════════════════════════════════════════════════
# FUNCIÓN DE ALTO NIVEL — usar desde módulos del ERP
# ══════════════════════════════════════════════════════════════════════════════
def imprimir_factura(id_venta: int, parent=None) -> None:
    """
    Muestra diálogo "Guardar PDF", genera la factura y la abre.
    Llamar desde VentasFrame o DetalleVenta:

        from utils.factura_pdf import imprimir_factura
        imprimir_factura(id_venta=self._id, parent=self)
    """
    try:
        from tkinter import filedialog, messagebox

        pdf_obj = FacturaPDF(id_venta)
        num     = pdf_obj._num_fac()

        ruta = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF", "*.pdf"), ("Todos", "*.*")],
            initialdir=FACTS_DIR,
            initialfile=f"{num}.pdf",
            title=f"Guardar factura {num}",
            parent=parent,
        )
        if not ruta:
            return   # usuario canceló

        ruta_final = pdf_obj.guardar(ruta)

        abrir = messagebox.askyesno(
            "✅  Factura generada",
            f"PDF guardado:\n{ruta_final}\n\n¿Abrir ahora?",
            parent=parent,
        )
        if abrir:
            _abrir_archivo(ruta_final)

    except ImportError as e:
        # fpdf2 no instalado
        _mostrar_error_fpdf2(parent)
    except Exception as e:
        try:
            from tkinter import messagebox
            messagebox.showerror("Error PDF", str(e), parent=parent)
        except Exception:
            print(f"Error generando PDF: {e}")


def _abrir_archivo(ruta: str) -> None:
    """Abre el PDF con el visor predeterminado del sistema operativo."""
    import subprocess, sys
    try:
        if sys.platform.startswith("win"):
            os.startfile(ruta)          # Windows
        elif sys.platform == "darwin":
            subprocess.Popen(["open", ruta])    # macOS
        else:
            subprocess.Popen(["xdg-open", ruta])  # Linux
    except Exception as e:
        print(f"No se pudo abrir el visor PDF: {e}")


def _mostrar_error_fpdf2(parent=None) -> None:
    msg = (
        "La librería fpdf2 no está instalada.\n\n"
        "Instálela con:\n\n"
        "    pip install fpdf2\n\n"
        "Luego reinicie el ERP."
    )
    try:
        from tkinter import messagebox
        messagebox.showerror("fpdf2 requerida", msg, parent=parent)
    except Exception:
        print(msg)


# ── CLI rápido: python factura_pdf.py <id_venta> ─────────────────────────────
if __name__ == "__main__":
    import sys
    vid = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    try:
        obj  = FacturaPDF(vid)
        ruta = obj.guardar()
        print(f"✅  PDF generado: {ruta}")
        _abrir_archivo(ruta)
    except ImportError:
        print("❌  fpdf2 no instalado. Ejecute: pip install fpdf2")
        sys.exit(1)
