"""
utils/paths.py
Resolución de rutas compatible con modo normal y empaquetado con PyInstaller.

Importar en TODOS los módulos que accedan a archivos:
    from utils.paths import BASE_DIR, DB_PATH, FACTS_DIR, resource_path
"""

import sys
import os


def _base_dir() -> str:
    """
    Devuelve el directorio raíz de la aplicación.
    - En desarrollo:   carpeta que contiene main.py
    - Empaquetado exe: carpeta donde está el .exe  (junto al cual
                       vive tiendita_erp.db y la carpeta facturas_pdf)
    """
    if getattr(sys, "frozen", False):
        # PyInstaller extrae los archivos a sys._MEIPASS (tmp),
        # pero los datos EXTERNOS (BD, PDFs) van junto al .exe
        return os.path.dirname(sys.executable)
    # Modo desarrollo: sube desde utils/ → raíz del proyecto
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def resource_path(relative: str) -> str:
    """
    Resuelve la ruta de un recurso EMPAQUETADO (imágenes, iconos, etc.)
    que PyInstaller extrae a sys._MEIPASS en tiempo de ejecución.
    Para archivos de datos mutables (BD, PDFs) usa BASE_DIR directamente.
    """
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, relative)


BASE_DIR  = _base_dir()
DB_PATH   = os.path.join(BASE_DIR, "tiendita_erp.db")
FACTS_DIR = os.path.join(BASE_DIR, "facturas_pdf")

# Crear carpetas necesarias si no existen
os.makedirs(FACTS_DIR, exist_ok=True)
os.makedirs(os.path.join(BASE_DIR, "reports"), exist_ok=True)
