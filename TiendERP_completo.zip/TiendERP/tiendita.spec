# -*- mode: python ; coding: utf-8 -*-
"""
tiendita.spec
Archivo de configuración de PyInstaller para ERP Repuestos La Tiendita.

Genera:  dist/TiendERP/TiendERP.exe   (carpeta con dependencias)
         dist/TiendERP.exe             (un solo archivo, más lento al iniciar)

Ejecutar en Windows, dentro de la carpeta del proyecto:
    pyinstaller tiendita.spec
"""

import sys
import os
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

# ── Módulos ocultos que PyInstaller no detecta automáticamente ────────────────
hiddenimports = [
    # CustomTkinter y sus sub-paquetes
    "customtkinter",
    *collect_submodules("customtkinter"),

    # Pillow (requerido por CustomTkinter)
    "PIL",
    "PIL.Image",
    "PIL.ImageTk",
    *collect_submodules("PIL"),

    # fpdf2 (generación de PDFs)
    "fpdf",
    *collect_submodules("fpdf"),

    # Módulos del ERP
    "core",
    "core.database",
    "core.main_window",
    "core.theme",
    "modules",
    "modules.dashboard",
    "modules.inventario",
    "modules.inventario.vista",
    "modules.ventas",
    "modules.ventas.vista",
    "modules.compras",
    "modules.compras.vista",
    "modules.clientes",
    "modules.clientes.vista",
    "modules.proveedores",
    "utils",
    "utils.paths",
    "utils.factura_pdf",

    # Tkinter (suele estar pero incluirlo explícito ayuda)
    "tkinter",
    "tkinter.ttk",
    "tkinter.filedialog",
    "tkinter.messagebox",
    "tkinter.font",

    # stdlib que PyInstaller a veces omite
    "sqlite3",
    "importlib",
    "importlib.util",
    "importlib.metadata",
    "email.mime.text",
    "decimal",
    "unicodedata",
]

# ── Datos extra que deben ir dentro del ejecutable ────────────────────────────
#    (archivos de recursos: temas de CTk, fuentes de fpdf2, etc.)
datas = []

# Tema y assets de CustomTkinter
try:
    import customtkinter
    ctk_path = os.path.dirname(customtkinter.__file__)
    datas += [(ctk_path, "customtkinter")]
except ImportError:
    pass

# Assets de fpdf2 (fuentes core)
try:
    import fpdf
    fpdf_path = os.path.dirname(fpdf.__file__)
    datas += [(fpdf_path, "fpdf")]
except ImportError:
    pass

# Icono de la aplicación (si existe)
icon_path = None
for posible in ["assets/icon.ico", "assets/logo.ico"]:
    if os.path.exists(posible):
        icon_path = posible
        break

# ── Análisis principal ────────────────────────────────────────────────────────
a = Analysis(
    ["main.py"],                     # punto de entrada
    pathex=["."],                    # directorio raíz del proyecto
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Excluir lo que NO necesitamos (reduce tamaño)
        "matplotlib",
        "numpy",
        "pandas",
        "scipy",
        "pytest",
        "IPython",
        "notebook",
        "jupyter",
        "setuptools",
        "distutils",
        "pkg_resources",
        "xmlrpc",
        "unittest",
    ],
    noarchive=False,
    optimize=1,
)

pyz = PYZ(a.pure)

# ── Opción A: carpeta (más rápido al iniciar, recomendado) ───────────────────
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,          # las DLL van en la carpeta, no dentro del exe
    name="TiendERP",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,                       # compresión UPX si está instalada
    console=False,                  # sin ventana negra de consola
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=icon_path,
    version_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="TiendERP",                # → dist/TiendERP/TiendERP.exe
)

# ── Opción B: un solo archivo .exe (descomenta si prefieres) ─────────────────
# exe_onefile = EXE(
#     pyz,
#     a.scripts,
#     a.binaries,
#     a.datas,
#     name="TiendERP",
#     debug=False,
#     strip=False,
#     upx=True,
#     console=False,
#     icon=icon_path,
#     onefile=True,                  # → dist/TiendERP.exe  (~80-100 MB)
# )
