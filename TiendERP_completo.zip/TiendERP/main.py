"""
main.py
Punto de entrada del ERP Repuestos La Tiendita
Compatible con ejecucion normal (python main.py) y empaquetado PyInstaller.
"""

import sys
import os

# ── Compatibilidad con PyInstaller ───────────────────────────────────────────
if getattr(sys, "frozen", False):
    # Ejecutando como .exe compilado
    _app_dir = os.path.dirname(sys.executable)
    os.chdir(_app_dir)
    sys.path.insert(0, sys._MEIPASS)
else:
    # Modo desarrollo
    _app_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, _app_dir)


def _error_gui(titulo, mensaje):
    try:
        import tkinter as tk
        import tkinter.messagebox as mb
        root = tk.Tk(); root.withdraw()
        mb.showerror(titulo, mensaje)
        root.destroy()
    except Exception:
        print(f"[{titulo}] {mensaje}")


def verificar_dependencias():
    faltantes = []
    for lib, pip_name in [("customtkinter", "customtkinter"), ("PIL", "Pillow")]:
        try:
            __import__(lib)
        except ImportError:
            faltantes.append(pip_name)
    if faltantes:
        cmd = " ".join(faltantes)
        _error_gui(
            "Dependencias faltantes",
            f"Falta instalar:\n    pip install {cmd}\n\n"
            f"Luego vuelva a abrir el programa."
        )
        sys.exit(1)


def main():
    verificar_dependencias()

    from core.database import inicializar_base_de_datos
    try:
        inicializar_base_de_datos()
    except Exception as e:
        _error_gui(
            "Error de base de datos",
            f"No se pudo inicializar tiendita_erp.db:\n\n{e}\n\n"
            f"Carpeta del programa: {_app_dir}"
        )
        sys.exit(1)

    try:
        from core.main_window import MainWindow
        app = MainWindow()
        app.mainloop()
    except Exception as e:
        _error_gui("Error al iniciar", f"Error inesperado:\n\n{e}")
        raise


if __name__ == "__main__":
    main()
