"""
modules/clientes/vista.py
Módulo de Clientes — gestión de clientes del negocio.
"""

import customtkinter as ctk
from tkinter import ttk, messagebox
from core.theme import *
from core.database import get_connection


class ClientesFrame(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="transparent")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        self._construir()
        self._cargar_datos()

    def _construir(self):
        # Toolbar
        tb = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        tb.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        tb.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(tb, text="🔍", font=("Segoe UI", 14)).grid(row=0, column=0, padx=(15, 5), pady=12)
        self.entry_buscar = ctk.CTkEntry(tb, placeholder_text="Buscar cliente...", width=320, height=34)
        self.entry_buscar.grid(row=0, column=1, padx=5, pady=12, sticky="w")
        self.entry_buscar.bind("<KeyRelease>", lambda e: self._buscar())

        for texto, color, cmd in [
            ("➕ Nuevo",   AZUL_CLARO,  self._nuevo),
            ("✏️ Editar",  AZUL_MEDIO,  self._editar),
            ("🗑️ Eliminar", ROJO_ERROR, self._eliminar),
        ]:
            ctk.CTkButton(tb, text=texto, fg_color=color, hover_color=AZUL_MARINO,
                          height=34, corner_radius=6, font=FUENTE_BOTON, command=cmd
                          ).grid(row=0, column=tb.grid_size()[0], padx=5, pady=12)

        # Tabla
        tf = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        tf.grid(row=1, column=0, sticky="nsew")
        tf.grid_columnconfigure(0, weight=1)
        tf.grid_rowconfigure(0, weight=1)

        cols = ("nombre", "rif", "telefono", "email", "tipo", "limite", "saldo")
        self.tabla = ttk.Treeview(tf, columns=cols, show="headings", height=20)

        headers = {
            "nombre":  ("Nombre / Razón Social", 200),
            "rif":     ("RIF / Cédula",           120),
            "telefono":("Teléfono",                110),
            "email":   ("Email",                   160),
            "tipo":    ("Tipo",                     80),
            "limite":  ("Límite Crédito",          110),
            "saldo":   ("Saldo Pendiente",         110),
        }
        for col, (h, w) in headers.items():
            self.tabla.heading(col, text=h)
            self.tabla.column(col, width=w, anchor="center")

        vsb = ttk.Scrollbar(tf, orient="vertical", command=self.tabla.yview)
        self.tabla.configure(yscrollcommand=vsb.set)
        self.tabla.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        vsb.grid(row=0, column=1, sticky="ns")

        style = ttk.Style()
        style.configure("Treeview.Heading",
                        background=AZUL_MARINO, foreground=BLANCO,
                        font=(FUENTE_FAMILIA, 10, "bold"))
        style.configure("Treeview", rowheight=28, font=(FUENTE_FAMILIA, 10))
        style.map("Treeview", background=[("selected", AZUL_CLARO)],
                  foreground=[("selected", BLANCO)])

        self.tabla.tag_configure("par",  background="#F8FAFC")
        self.tabla.tag_configure("impar", background=BLANCO)

        self.lbl_estado = ctk.CTkLabel(self, text="", font=FUENTE_PEQUEÑA, text_color=GRIS_TEXTO)
        self.lbl_estado.grid(row=2, column=0, sticky="w", pady=(5, 0))

    def _cargar_datos(self, filtro=""):
        for item in self.tabla.get_children():
            self.tabla.delete(item)
        conn = get_connection()
        like = f"%{filtro}%"
        rows = conn.execute("""
            SELECT nombre, rif_cedula, telefono, email,
                   tipo_cliente, limite_credito, saldo_pendiente
            FROM Clientes WHERE activo=1
              AND (nombre LIKE ? OR rif_cedula LIKE ? OR email LIKE ?)
            ORDER BY nombre
        """, (like, like, like)).fetchall()
        conn.close()
        for i, r in enumerate(rows):
            tag = "par" if i % 2 == 0 else "impar"
            self.tabla.insert("", "end", values=(
                r["nombre"], r["rif_cedula"] or "—",
                r["telefono"] or "—", r["email"] or "—",
                r["tipo_cliente"],
                f"Bs. {r['limite_credito']:,.2f}",
                f"Bs. {r['saldo_pendiente']:,.2f}",
            ), tags=(tag,))
        self.lbl_estado.configure(text=f"  👥 {len(rows)} cliente(s) encontrado(s)")

    def _buscar(self):
        self._cargar_datos(self.entry_buscar.get().strip())

    def _nuevo(self):
        FormularioCliente(self, modo="nuevo", callback=self._cargar_datos)

    def _editar(self):
        sel = self.tabla.selection()
        if not sel:
            messagebox.showwarning("Selección", "Seleccione un cliente para editar.")
            return
        nombre = self.tabla.item(sel[0])["values"][0]
        FormularioCliente(self, modo="editar", nombre=nombre, callback=self._cargar_datos)

    def _eliminar(self):
        sel = self.tabla.selection()
        if not sel:
            messagebox.showwarning("Selección", "Seleccione un cliente.")
            return
        nombre = self.tabla.item(sel[0])["values"][0]
        if messagebox.askyesno("Confirmar", f"¿Desactivar al cliente:\n{nombre}?"):
            conn = get_connection()
            conn.execute("UPDATE Clientes SET activo=0 WHERE nombre=?", (nombre,))
            conn.commit()
            conn.close()
            self._cargar_datos(self.entry_buscar.get().strip())


class FormularioCliente(ctk.CTkToplevel):
    def __init__(self, parent, modo="nuevo", nombre=None, callback=None):
        super().__init__(parent)
        self.modo = modo
        self.nombre_original = nombre
        self.callback = callback
        self.title("Nuevo Cliente" if modo == "nuevo" else "Editar Cliente")
        self.geometry("520x500")
        self.resizable(False, False)
        self.grab_set()
        self.configure(fg_color=GRIS_CLARO)
        self._construir()
        if modo == "editar" and nombre:
            self._cargar(nombre)

    def _construir(self):
        ctk.CTkLabel(self, text="Datos del Cliente",
                     font=FUENTE_SUBTITULO, text_color=AZUL_MARINO).pack(
            padx=20, pady=(20, 10), anchor="w")

        form = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        form.pack(fill="both", expand=True, padx=20, pady=(0, 10))
        form.grid_columnconfigure((0, 2), weight=1)

        campos = [
            ("Nombre / Razón Social *", "nombre"),
            ("RIF / Cédula",            "rif"),
            ("Teléfono",                "telefono"),
            ("Email",                   "email"),
            ("Dirección",               "direccion"),
            ("Límite de Crédito",       "limite"),
        ]
        self.entries = {}
        for i, (lbl, key) in enumerate(campos):
            col = (i % 2) * 2
            row = i // 2
            ctk.CTkLabel(form, text=lbl, font=FUENTE_PEQUEÑA, text_color=GRIS_TEXTO).grid(
                row=row * 2, column=col, padx=15, pady=(10, 2), sticky="w")
            e = ctk.CTkEntry(form, height=32, width=180)
            e.grid(row=row * 2 + 1, column=col, padx=15, pady=(0, 5), sticky="ew")
            self.entries[key] = e

        # Tipo de cliente
        ctk.CTkLabel(form, text="Tipo de Cliente", font=FUENTE_PEQUEÑA,
                     text_color=GRIS_TEXTO).grid(row=6, column=0, padx=15, pady=(10, 2), sticky="w")
        self.combo_tipo = ctk.CTkComboBox(
            form, values=["Regular", "Mayorista", "VIP"], width=180, height=32)
        self.combo_tipo.grid(row=7, column=0, padx=15, pady=(0, 15), sticky="ew")

        # Botones
        bf = ctk.CTkFrame(self, fg_color="transparent")
        bf.pack(fill="x", padx=20, pady=(0, 20))
        ctk.CTkButton(bf, text="Cancelar", fg_color=GRIS_MEDIO, text_color=NEGRO_TEXTO,
                      hover_color=GRIS_CLARO, command=self.destroy, width=120).pack(side="right", padx=(5, 0))
        ctk.CTkButton(bf, text="💾 Guardar", fg_color=AZUL_CLARO,
                      command=self._guardar, width=140).pack(side="right")

    def _cargar(self, nombre):
        conn = get_connection()
        c = conn.execute("SELECT * FROM Clientes WHERE nombre=?", (nombre,)).fetchone()
        conn.close()
        if not c:
            return
        for key, val in [("nombre", c["nombre"]), ("rif", c["rif_cedula"] or ""),
                          ("telefono", c["telefono"] or ""), ("email", c["email"] or ""),
                          ("direccion", c["direccion"] or ""), ("limite", str(c["limite_credito"]))]:
            self.entries[key].insert(0, val)
        self.combo_tipo.set(c["tipo_cliente"] or "Regular")

    def _guardar(self):
        nombre = self.entries["nombre"].get().strip()
        if not nombre:
            messagebox.showerror("Error", "El nombre es obligatorio.")
            return
        def _f(k):
            try: return float(self.entries[k].get().replace(",", ".") or 0)
            except: return 0.0

        datos = {
            "nombre": nombre, "rif": self.entries["rif"].get().strip(),
            "telefono": self.entries["telefono"].get().strip(),
            "email": self.entries["email"].get().strip(),
            "direccion": self.entries["direccion"].get().strip(),
            "limite": _f("limite"), "tipo": self.combo_tipo.get(),
        }
        conn = get_connection()
        try:
            if self.modo == "nuevo":
                conn.execute("""
                    INSERT INTO Clientes (nombre, rif_cedula, telefono, email, direccion, limite_credito, tipo_cliente)
                    VALUES (:nombre,:rif,:telefono,:email,:direccion,:limite,:tipo)
                """, datos)
            else:
                datos["nombre_orig"] = self.nombre_original
                conn.execute("""
                    UPDATE Clientes SET nombre=:nombre, rif_cedula=:rif, telefono=:telefono,
                        email=:email, direccion=:direccion, limite_credito=:limite, tipo_cliente=:tipo
                    WHERE nombre=:nombre_orig
                """, datos)
            conn.commit()
            messagebox.showinfo("Éxito", "Cliente guardado correctamente.")
            if self.callback:
                self.callback()
            self.destroy()
        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            conn.close()
