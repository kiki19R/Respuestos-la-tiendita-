"""
modules/dashboard.py
Dashboard principal — ERP Repuestos La Tiendita
  · KPIs: ventas, compras, utilidad, agotados
  · Gráfica de barras: ventas por cliente (Canvas nativo)
  · Gráfica de pie: inventario por estado (Canvas nativo)
  · Lista de alertas: stock bajo y agotado
Sin dependencias externas de graficado — todo con tkinter Canvas.
"""

import customtkinter as ctk
import tkinter as tk
from tkinter import font as tkfont
import sqlite3, os, math
from datetime import date, datetime

# ── Ruta DB ───────────────────────────────────────────────────────────────────
from utils.paths import BASE_DIR, DB_PATH

# ── Paleta ────────────────────────────────────────────────────────────────────
AZ_OSC   = "#0D1B2A"
AZ_MED   = "#1B3A5C"
AZ_CLA   = "#2E6DA4"
AZ_ACE   = "#3D9EE8"
BLANCO   = "#FFFFFF"
GRIS_BG  = "#F4F6F9"
GRIS_BR  = "#DDE3EA"
GRIS_TX  = "#5A6478"
NEGRO    = "#1A1A2E"
VERDE    = "#1E8449"
VERDE_L  = "#27AE60"
AMBAR    = "#E67E22"
AMBAR_L  = "#F39C12"
ROJO     = "#C0392B"
ROJO_L   = "#E74C3C"
PURPURA  = "#7D3C98"
CIAN     = "#117A8B"
FF       = "Segoe UI"

PALETA_BARRAS = [AZ_CLA, VERDE_L, AMBAR_L, PURPURA, CIAN,
                 "#E91E63", "#FF5722", "#009688", "#795548"]

# ── Helper DB ─────────────────────────────────────────────────────────────────
def _conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c

def _q(sql, params=()):
    c = _conn()
    r = c.execute(sql, params).fetchall()
    c.close()
    return r

def _q1(sql, params=()):
    c = _conn()
    r = c.execute(sql, params).fetchone()
    c.close()
    return r


# ══════════════════════════════════════════════════════════════════════════════
# FRAME PRINCIPAL
# ══════════════════════════════════════════════════════════════════════════════
class DashboardFrame(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="transparent")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        self._build()
        self._cargar()

    def _build(self):
        # ── Fila 0: encabezado + botón actualizar ──
        hdr = ctk.CTkFrame(self, fg_color="transparent")
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        hdr.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(hdr, text="Dashboard",
                     font=(FF, 20, "bold"), text_color=AZ_OSC
                     ).grid(row=0, column=0, sticky="w")

        self._lbl_fecha = ctk.CTkLabel(
            hdr, text="", font=(FF, 10), text_color=GRIS_TX)
        self._lbl_fecha.grid(row=0, column=1, sticky="w", padx=16)

        ctk.CTkButton(
            hdr, text="🔄  Actualizar",
            fg_color=AZ_MED, hover_color=AZ_OSC,
            text_color=BLANCO, height=34, width=140,
            corner_radius=8, font=(FF, 11, "bold"),
            command=self._cargar
        ).grid(row=0, column=2, sticky="e")

        # ── Fila 1: scroll container ──
        self._scroll = ctk.CTkScrollableFrame(
            self, fg_color="transparent", corner_radius=0)
        self._scroll.grid(row=1, column=0, sticky="nsew")
        self._scroll.grid_columnconfigure((0, 1), weight=1)

    # ── Cargar / refrescar todos los datos ────────────────────────────────────
    def _cargar(self):
        # Limpiar contenido anterior
        for w in self._scroll.winfo_children():
            w.destroy()

        hoy = date.today()
        self._lbl_fecha.configure(
            text=f"Actualizado: {hoy.strftime('%d/%m/%Y  %H:%M')}")

        datos = self._obtener_datos()

        self._kpis(datos)           # Fila 0: 4 tarjetas KPI
        self._grafica_barras(datos) # Fila 1 col 0: ventas por cliente
        self._grafica_pie(datos)    # Fila 1 col 1: inventario por estado
        self._alertas(datos)        # Fila 2: lista de alertas
        self._top_productos(datos)  # Fila 2 col 1: top productos

    # ── Consultas a la BD ─────────────────────────────────────────────────────
    def _obtener_datos(self):
        tv  = (_q1("SELECT COALESCE(SUM(total),0) t FROM Ventas  WHERE estado!='Anulada'")["t"] or 0)
        tc  = (_q1("SELECT COALESCE(SUM(total),0) t FROM Compras WHERE estado!='Anulada'")["t"] or 0)
        ut  = tv - tc
        ag  = (_q1("SELECT COUNT(*) c FROM Inventario WHERE activo=1 AND stock_actual<=0")["c"] or 0)
        sb  = (_q1("SELECT COUNT(*) c FROM Inventario WHERE activo=1 AND stock_actual>0 AND stock_actual<=stock_minimo")["c"] or 0)
        disp= (_q1("SELECT COUNT(*) c FROM Inventario WHERE activo=1 AND stock_actual>stock_minimo")["c"] or 0)
        tot_prod = ag + sb + disp

        ventas_cli = _q("""
            SELECT COALESCE(nombre_cliente,'Consumidor Final') AS cli,
                   SUM(total) AS tot, COUNT(*) AS n
            FROM Ventas WHERE estado!='Anulada'
            GROUP BY cli ORDER BY tot DESC
        """)

        alertas = _q("""
            SELECT codigo, descripcion, stock_actual, stock_minimo
            FROM Inventario
            WHERE activo=1 AND stock_actual <= stock_minimo
            ORDER BY stock_actual ASC, descripcion
        """)

        top_prods = _q("""
            SELECT d.descripcion,
                   SUM(d.cantidad)  AS qty,
                   SUM(d.subtotal)  AS rev
            FROM VentaDetalle d
            GROUP BY d.id_producto
            ORDER BY rev DESC LIMIT 6
        """)

        compras_prov = _q("""
            SELECT nombre_proveedor, SUM(total) AS tot, COUNT(*) AS n
            FROM Compras WHERE estado!='Anulada'
            GROUP BY nombre_proveedor ORDER BY tot DESC
        """)

        return {
            "tv": tv, "tc": tc, "ut": ut,
            "ag": ag, "sb": sb, "disp": disp, "tot_prod": tot_prod,
            "ventas_cli":  ventas_cli,
            "alertas":     alertas,
            "top_prods":   top_prods,
            "compras_prov":compras_prov,
        }

    # ══════════════════════════════════════════════════════════════════════════
    # KPIs — 4 tarjetas en la fila superior
    # ══════════════════════════════════════════════════════════════════════════
    def _kpis(self, d):
        frame = ctk.CTkFrame(self._scroll, fg_color="transparent")
        frame.grid(row=0, column=0, columnspan=2,
                   sticky="ew", pady=(0, 12))
        frame.grid_columnconfigure((0, 1, 2, 3), weight=1)

        ut_color = VERDE if d["ut"] >= 0 else ROJO
        ut_icon  = "📈" if d["ut"] >= 0 else "📉"

        kpis = [
            ("💰", "Total Ventas",   f"$ {d['tv']:,.2f}",  AZ_CLA,   BLANCO),
            ("🛒", "Total Compras",  f"$ {d['tc']:,.2f}",  AZ_MED,   BLANCO),
            (ut_icon,"Utilidad",     f"$ {d['ut']:,.2f}",  ut_color, BLANCO),
            ("🔴", "Agotados",       str(d["ag"]),          ROJO,     BLANCO),
        ]

        for col, (icono, titulo, valor, bg, fg) in enumerate(kpis):
            self._tarjeta_kpi(frame, col, icono, titulo, valor, bg, fg)

    def _tarjeta_kpi(self, parent, col, icono, titulo, valor, bg, fg):
        card = ctk.CTkFrame(parent, fg_color=bg, corner_radius=14)
        card.grid(row=0, column=col, padx=6, sticky="ew")

        ctk.CTkLabel(card, text=icono, font=(FF, 28),
                     text_color=fg).pack(padx=18, pady=(18, 2), anchor="w")
        ctk.CTkLabel(card, text=titulo, font=(FF, 10),
                     text_color=fg + "CC").pack(padx=18, anchor="w")
        ctk.CTkLabel(card, text=valor, font=(FF, 22, "bold"),
                     text_color=fg).pack(padx=18, pady=(2, 18), anchor="w")

    # ══════════════════════════════════════════════════════════════════════════
    # GRÁFICA DE BARRAS — Ventas por cliente
    # ══════════════════════════════════════════════════════════════════════════
    def _grafica_barras(self, d):
        card = ctk.CTkFrame(self._scroll, fg_color=BLANCO, corner_radius=14)
        card.grid(row=1, column=0, padx=(0, 6), pady=(0, 12), sticky="nsew")
        card.grid_columnconfigure(0, weight=1)
        card.grid_rowconfigure(1, weight=1)

        # Título
        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.grid(row=0, column=0, sticky="ew", padx=16, pady=(14, 6))
        ctk.CTkLabel(hdr, text="📊  Ventas por Cliente",
                     font=(FF, 13, "bold"), text_color=AZ_OSC
                     ).pack(side="left")
        ctk.CTkLabel(hdr, text=f"Total: $ {d['tv']:,.2f}",
                     font=(FF, 10), text_color=GRIS_TX
                     ).pack(side="right")

        # Canvas
        cv = tk.Canvas(card, bg=BLANCO, highlightthickness=0, height=240)
        cv.grid(row=1, column=0, sticky="nsew", padx=16, pady=(0, 14))
        cv.bind("<Configure>", lambda e, cv=cv, d=d:
                self._dibujar_barras(cv, d["ventas_cli"], d["tv"]))
        card.update_idletasks()
        self._dibujar_barras(cv, d["ventas_cli"], d["tv"])

    def _dibujar_barras(self, cv, datos, tv_total):
        cv.delete("all")
        cv.update_idletasks()
        W = cv.winfo_width()  or 420
        H = cv.winfo_height() or 240

        if not datos:
            cv.create_text(W//2, H//2, text="Sin datos de ventas",
                           fill=GRIS_TX, font=(FF, 11))
            return

        pad_l, pad_r, pad_t, pad_b = 60, 20, 20, 55
        area_w = W - pad_l - pad_r
        area_h = H - pad_t - pad_b

        max_val = max(float(r["tot"] or 0) for r in datos) * 1.15 or 1

        n = len(datos)
        gap   = max(6, area_w // (n * 6))
        bw    = (area_w - gap * (n + 1)) // n

        # Líneas de cuadrícula y etiquetas eje Y
        pasos = 4
        cv.create_line(pad_l, pad_t, pad_l, H - pad_b,
                       fill=GRIS_BR, width=1)
        for i in range(pasos + 1):
            y_val = max_val * i / pasos
            y_px  = H - pad_b - int(area_h * i / pasos)
            cv.create_line(pad_l - 4, y_px, W - pad_r, y_px,
                           fill=GRIS_BR if i > 0 else NEGRO, width=1,
                           dash=(4, 4) if i > 0 else ())
            lbl = f"${y_val:,.0f}" if y_val >= 1 else f"${y_val:.2f}"
            cv.create_text(pad_l - 6, y_px, text=lbl,
                           anchor="e", fill=GRIS_TX, font=(FF, 8))

        # Barras
        for idx, row in enumerate(datos):
            val = float(row["tot"] or 0)
            pct = val / tv_total * 100 if tv_total else 0
            bar_h = int(area_h * val / max_val)
            x0 = pad_l + gap + idx * (bw + gap)
            x1 = x0 + bw
            y0 = H - pad_b - bar_h
            y1 = H - pad_b
            color = PALETA_BARRAS[idx % len(PALETA_BARRAS)]

            # Sombra suave
            cv.create_rectangle(x0+2, y0+2, x1+2, y1+2,
                                 fill="#CCCCCC", outline="", width=0)
            # Barra principal con radio simulado
            cv.create_rectangle(x0, y0, x1, y1,
                                 fill=color, outline="", width=0)
            # Brillo superior
            cv.create_rectangle(x0, y0, x1, y0+4,
                                 fill=self._aclarar(color), outline="", width=0)

            # Valor encima de la barra
            if bar_h > 18:
                cv.create_text((x0+x1)//2, y0 - 6,
                               text=f"${val:,.1f}",
                               fill=NEGRO, font=(FF, 8, "bold"), anchor="s")

            # Etiqueta eje X
            nombre = str(row["cli"])
            palabras = nombre.split()
            linea1 = palabras[0] if palabras else nombre
            linea2 = " ".join(palabras[1:]) if len(palabras) > 1 else ""
            cx = (x0 + x1) // 2
            cv.create_text(cx, y1 + 10, text=linea1,
                           fill=NEGRO, font=(FF, 8, "bold"), anchor="n")
            if linea2:
                cv.create_text(cx, y1 + 22, text=linea2[:14],
                               fill=GRIS_TX, font=(FF, 7), anchor="n")
            cv.create_text(cx, y1 + 34, text=f"{pct:.0f}%",
                           fill=color, font=(FF, 7, "bold"), anchor="n")

    # ══════════════════════════════════════════════════════════════════════════
    # GRÁFICA DE PIE — Inventario por estado
    # ══════════════════════════════════════════════════════════════════════════
    def _grafica_pie(self, d):
        card = ctk.CTkFrame(self._scroll, fg_color=BLANCO, corner_radius=14)
        card.grid(row=1, column=1, padx=(6, 0), pady=(0, 12), sticky="nsew")
        card.grid_columnconfigure(0, weight=1)
        card.grid_rowconfigure(1, weight=1)

        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.grid(row=0, column=0, sticky="ew", padx=16, pady=(14, 6))
        ctk.CTkLabel(hdr, text="🥧  Inventario por Estado",
                     font=(FF, 13, "bold"), text_color=AZ_OSC
                     ).pack(side="left")
        ctk.CTkLabel(hdr, text=f"{d['tot_prod']} productos",
                     font=(FF, 10), text_color=GRIS_TX
                     ).pack(side="right")

        cv = tk.Canvas(card, bg=BLANCO, highlightthickness=0, height=240)
        cv.grid(row=1, column=0, sticky="nsew", padx=16, pady=(0, 14))
        cv.bind("<Configure>", lambda e, cv=cv, d=d:
                self._dibujar_pie(cv, d))
        card.update_idletasks()
        self._dibujar_pie(cv, d)

    def _dibujar_pie(self, cv, d):
        cv.delete("all")
        cv.update_idletasks()
        W = cv.winfo_width()  or 360
        H = cv.winfo_height() or 240

        segmentos = [
            ("Disponible", d["disp"], VERDE_L),
            ("Stock Bajo",  d["sb"],  AMBAR_L),
            ("Agotado",     d["ag"],  ROJO_L),
        ]
        total = sum(v for _, v, _ in segmentos)
        if total == 0:
            cv.create_text(W//2, H//2, text="Sin productos",
                           fill=GRIS_TX, font=(FF, 11))
            return

        # Zona del pie
        pie_size = min(W * 0.52, H - 30)
        cx  = int(W * 0.38)
        cy  = H // 2
        r   = int(pie_size / 2)
        r_i = int(r * 0.45)   # radio interior (dona)

        inicio = -90.0
        hover_segs = []

        for nombre, val, color in segmentos:
            if val == 0:
                continue
            angulo = 360 * val / total
            # Sombra
            cv.create_arc(cx-r+2, cy-r+2, cx+r+2, cy+r+2,
                          start=inicio, extent=angulo,
                          fill="#BBBBBB", outline="", style="pieslice")
            # Sector exterior
            cv.create_arc(cx-r, cy-r, cx+r, cy+r,
                          start=inicio, extent=angulo,
                          fill=color, outline=BLANCO, width=2,
                          style="pieslice")
            # Hueco interior (dona)
            cv.create_oval(cx-r_i, cy-r_i, cx+r_i, cy+r_i,
                           fill=BLANCO, outline=BLANCO, width=2)
            inicio += angulo

        # Texto central de la dona
        cv.create_text(cx, cy - 10, text=str(total),
                       fill=AZ_OSC, font=(FF, 18, "bold"), anchor="center")
        cv.create_text(cx, cy + 12, text="productos",
                       fill=GRIS_TX, font=(FF, 9), anchor="center")

        # Leyenda a la derecha
        ley_x = cx + r + 24
        ley_y = cy - (len([s for s in segmentos if s[1]>0]) * 28) // 2 + 10

        for nombre, val, color in segmentos:
            pct = val / total * 100
            # Cuadro de color
            cv.create_rectangle(ley_x, ley_y - 8,
                                 ley_x + 14, ley_y + 6,
                                 fill=color, outline="", width=0)
            cv.create_text(ley_x + 20, ley_y - 1,
                           text=f"{nombre}", fill=NEGRO,
                           font=(FF, 9, "bold"), anchor="w")
            cv.create_text(ley_x + 20, ley_y + 12,
                           text=f"{val} uds  ({pct:.0f}%)",
                           fill=GRIS_TX, font=(FF, 8), anchor="w")
            ley_y += 38

    # ══════════════════════════════════════════════════════════════════════════
    # ALERTAS DE STOCK
    # ══════════════════════════════════════════════════════════════════════════
    def _alertas(self, d):
        card = ctk.CTkFrame(self._scroll, fg_color=BLANCO, corner_radius=14)
        card.grid(row=2, column=0, padx=(0, 6), pady=(0, 12), sticky="nsew")
        card.grid_columnconfigure(0, weight=1)

        # Título con contador badge
        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.grid(row=0, column=0, sticky="ew", padx=16, pady=(14, 8))
        hdr.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(hdr, text="⚠️  Alertas de Stock",
                     font=(FF, 13, "bold"), text_color=AZ_OSC
                     ).grid(row=0, column=0, sticky="w")

        n_alertas = len(d["alertas"])
        badge_color = ROJO if n_alertas > 0 else VERDE
        pill = ctk.CTkFrame(hdr, fg_color=badge_color, corner_radius=10)
        pill.grid(row=0, column=2, sticky="e")
        ctk.CTkLabel(pill, text=f"  {n_alertas} alertas  ",
                     font=(FF, 9, "bold"), text_color=BLANCO
                     ).pack(padx=4, pady=3)

        if not d["alertas"]:
            ctk.CTkLabel(card,
                         text="✅  Todos los productos están en niveles óptimos",
                         font=(FF, 11), text_color=VERDE
                         ).grid(row=1, column=0, padx=16, pady=20, sticky="w")
            return

        # Cabecera de tabla
        cab = ctk.CTkFrame(card, fg_color=GRIS_BG, corner_radius=6)
        cab.grid(row=1, column=0, sticky="ew", padx=16, pady=(0, 4))
        cab.grid_columnconfigure(1, weight=1)
        for c_idx, (txt, w) in enumerate([
            ("Código", 90), ("Descripción", 1), ("Stock", 60), ("Mín.", 55), ("Estado", 85)
        ]):
            ctk.CTkLabel(cab, text=txt, font=(FF, 9, "bold"),
                         text_color=GRIS_TX, width=w if w > 1 else 0,
                         anchor="w" if c_idx == 1 else "center"
                         ).grid(row=0, column=c_idx,
                                padx=(10 if c_idx==0 else 4, 4),
                                pady=6, sticky="ew" if c_idx==1 else "")

        # Filas de alertas
        for i, row in enumerate(d["alertas"]):
            stk = row["stock_actual"] or 0
            mn  = row["stock_minimo"] or 0
            agotado = stk <= 0

            bg_fila = ROJO_BG   if agotado else (AMBAR_BG if i % 2 == 0 else "#FFF8F0")
            fg_est  = ROJO      if agotado else AMBAR
            est_txt = "⛔ Agotado" if agotado else "⚠️ Stock Bajo"

            fila = ctk.CTkFrame(card, fg_color=bg_fila, corner_radius=4)
            fila.grid(row=i+2, column=0, sticky="ew", padx=16, pady=2)
            fila.grid_columnconfigure(1, weight=1)

            datos_col = [
                (row["codigo"][:12],         90,  "center", GRIS_TX),
                (row["descripcion"][:36],     0,   "w",     NEGRO),
                (f"{stk:g}",                 60,  "center", fg_est),
                (f"{mn:g}",                  55,  "center", GRIS_TX),
                (est_txt,                    85,  "center", fg_est),
            ]
            for c_idx, (txt, w, anch, color) in enumerate(datos_col):
                ctk.CTkLabel(
                    fila, text=txt,
                    font=(FF, 10, "bold" if c_idx == 4 else "normal"),
                    text_color=color,
                    width=w if w > 0 else 0,
                    anchor=anch
                ).grid(row=0, column=c_idx,
                       padx=(10 if c_idx==0 else 4, 4),
                       pady=6, sticky="ew" if c_idx==1 else "")

    # ══════════════════════════════════════════════════════════════════════════
    # TOP PRODUCTOS + COMPRAS POR PROVEEDOR
    # ══════════════════════════════════════════════════════════════════════════
    def _top_productos(self, d):
        card = ctk.CTkFrame(self._scroll, fg_color=BLANCO, corner_radius=14)
        card.grid(row=2, column=1, padx=(6, 0), pady=(0, 12), sticky="nsew")
        card.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(card, text="🏆  Top Productos Vendidos",
                     font=(FF, 13, "bold"), text_color=AZ_OSC
                     ).grid(row=0, column=0, sticky="w", padx=16, pady=(14, 10))

        if not d["top_prods"]:
            ctk.CTkLabel(card, text="Sin ventas registradas",
                         font=(FF, 11), text_color=GRIS_TX
                         ).grid(row=1, column=0, padx=16, pady=20)
        else:
            max_rev = float(d["top_prods"][0]["rev"] or 1)
            for i, row in enumerate(d["top_prods"]):
                rev = float(row["rev"] or 0)
                qty = float(row["qty"] or 0)
                pct = rev / max_rev

                fila = ctk.CTkFrame(card, fg_color="transparent")
                fila.grid(row=i+1, column=0, sticky="ew", padx=16, pady=3)
                fila.grid_columnconfigure(0, weight=1)

                # Nombre + cantidad
                ctk.CTkLabel(
                    fila,
                    text=f"{i+1}. {str(row['descripcion'])[:34]}",
                    font=(FF, 10, "bold"), text_color=NEGRO, anchor="w"
                ).grid(row=0, column=0, sticky="w")

                ctk.CTkLabel(
                    fila, text=f"$ {rev:,.2f}",
                    font=(FF, 10, "bold"), text_color=AZ_CLA, anchor="e"
                ).grid(row=0, column=1, sticky="e", padx=(8, 0))

                # Barra de progreso
                color = PALETA_BARRAS[i % len(PALETA_BARRAS)]
                barra_frame = ctk.CTkFrame(fila, fg_color=GRIS_BG,
                                           corner_radius=4, height=6)
                barra_frame.grid(row=1, column=0, columnspan=2,
                                 sticky="ew", pady=(1, 0))
                barra_frame.grid_propagate(False)
                barra_frame.grid_columnconfigure(0, weight=int(pct * 100))
                barra_frame.grid_columnconfigure(1, weight=int((1-pct) * 100)+1)

                ctk.CTkFrame(barra_frame, fg_color=color,
                             corner_radius=4, height=6
                             ).grid(row=0, column=0, sticky="ew")
                ctk.CTkFrame(barra_frame, fg_color="transparent",
                             height=6
                             ).grid(row=0, column=1, sticky="ew")

                ctk.CTkLabel(fila, text=f"{qty:g} uds",
                             font=(FF, 8), text_color=GRIS_TX
                             ).grid(row=2, column=0, sticky="w", pady=(1, 0))

        # ── Compras por proveedor ──
        sep = ctk.CTkFrame(card, height=1, fg_color=GRIS_BR)
        sep.grid(row=10, column=0, sticky="ew", padx=16, pady=(12, 8))

        ctk.CTkLabel(card, text="📦  Compras por Proveedor",
                     font=(FF, 12, "bold"), text_color=AZ_OSC
                     ).grid(row=11, column=0, sticky="w", padx=16, pady=(0, 8))

        for i, row in enumerate(d["compras_prov"]):
            fila = ctk.CTkFrame(card, fg_color=GRIS_BG if i%2==0 else BLANCO,
                                corner_radius=6)
            fila.grid(row=12+i, column=0, sticky="ew", padx=16, pady=2)
            fila.grid_columnconfigure(0, weight=1)

            ctk.CTkLabel(
                fila, text=str(row["nombre_proveedor"]) or "—",
                font=(FF, 10), text_color=NEGRO, anchor="w"
            ).grid(row=0, column=0, padx=10, pady=6, sticky="w")

            ctk.CTkLabel(
                fila,
                text=f"$ {row['tot']:,.2f}  ·  {row['n']} OC",
                font=(FF, 10, "bold"), text_color=AZ_CLA, anchor="e"
            ).grid(row=0, column=1, padx=10, pady=6, sticky="e")

        # Espaciado final
        ctk.CTkLabel(card, text="").grid(row=99, column=0, pady=6)

    # ── Utilidades de color ───────────────────────────────────────────────────
    @staticmethod
    def _aclarar(hex_color, factor=1.25):
        try:
            r = min(255, int(int(hex_color[1:3], 16) * factor))
            g = min(255, int(int(hex_color[3:5], 16) * factor))
            b = min(255, int(int(hex_color[5:7], 16) * factor))
            return f"#{r:02x}{g:02x}{b:02x}"
        except:
            return hex_color
