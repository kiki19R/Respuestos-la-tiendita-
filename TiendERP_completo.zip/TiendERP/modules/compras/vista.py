"""
modules/compras/vista.py
Módulo de Compras completo — ERP Repuestos La Tiendita
  · Historial de todas las órdenes de compra con badges resumen
  · Formulario nueva compra: proveedor, búsqueda de producto,
    cantidad, costo unitario — todo validado
  · Al guardar: suma al stock de Inventario automáticamente
  · Ventana de detalle por orden
"""

import customtkinter as ctk
from tkinter import ttk, messagebox
import sqlite3, os
from datetime import datetime, date

# ── Rutas ─────────────────────────────────────────────────────────────────────
from utils.paths import BASE_DIR, DB_PATH

# ── Paleta ────────────────────────────────────────────────────────────────────
AZ_OSC   = "#0D1B2A"
AZ_MED   = "#1B3A5C"
AZ_CLA   = "#2E6DA4"
AZ_ACE   = "#3D9EE8"
BLANCO   = "#FFFFFF"
GRIS_BG  = "#F4F6F9"
GRIS_BR  = "#DDE3EA"
GRIS_TX  = "#5A6478"
NEGRO    = "#1A1A2E"
VERDE    = "#1E8449"
VERDE_BG = "#EAFAF1"
AMBAR    = "#B7770D"
AMBAR_BG = "#FEF9E7"
ROJO     = "#C0392B"
ROJO_BG  = "#FDEDEC"
NARANJA  = "#D35400"
NARAN_BG = "#FDEBD0"
FF       = "Segoe UI"

# ── Helpers ───────────────────────────────────────────────────────────────────
def _conn():
    c = sqlite3.connect(DB_PATH)
    c.execute("PRAGMA foreign_keys = ON")
    c.row_factory = sqlite3.Row
    return c

def _fl(v, d=0.0):
    try:    return float(str(v).replace(",", ".").strip()) if str(v).strip() else d
    except: return d

def _cfg(clave, default=""):
    try:
        c = _conn()
        r = c.execute("SELECT valor FROM Configuracion WHERE clave=?", (clave,)).fetchone()
        c.close()
        return r["valor"] if r else default
    except: return default

def _sig_orden():
    """Genera el siguiente número de OC y actualiza el contador."""
    c = _conn()
    n = int(_cfg("siguiente_orden", "1"))
    num = f"OC-{n:05d}"
    c.execute("UPDATE Configuracion SET valor=? WHERE clave='siguiente_orden'",
              (str(n + 1),))
    c.commit(); c.close()
    return num

_TAG_ESTADO = {
    "Recibida":  ("REC",  VERDE,  VERDE_BG),
    "Pendiente": ("PEN",  AMBAR,  AMBAR_BG),
    "Pagada":    ("PAG",  AZ_CLA, "#E8F4FD"),
    "Anulada":   ("ANU",  ROJO,   ROJO_BG),
    "Parcial":   ("PAR",  NARANJA,NARAN_BG),
}


# ══════════════════════════════════════════════════════════════════════════════
# FRAME PRINCIPAL — Historial de compras
# ══════════════════════════════════════════════════════════════════════════════
class ComprasFrame(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="transparent")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)
        self._build()
        self.recargar()

    # ── Layout ────────────────────────────────────────────────────────────────
    def _build(self):
        # — Fila 0: título + botón —
        hdr = ctk.CTkFrame(self, fg_color="transparent")
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        hdr.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(hdr, text="Historial de Compras",
                     font=(FF, 20, "bold"), text_color=AZ_OSC
                     ).grid(row=0, column=0, sticky="w")

        ctk.CTkButton(
            hdr, text="➕  Nueva Compra",
            fg_color=AZ_CLA, hover_color=AZ_MED,
            text_color=BLANCO, height=38, width=170,
            corner_radius=8, font=(FF, 12, "bold"),
            command=self._nueva
        ).grid(row=0, column=2, sticky="e")

        # — Fila 1: barra buscar + badges —
        tb = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        tb.grid(row=1, column=0, sticky="ew", pady=(0, 8))

        ctk.CTkLabel(tb, text="🔍", font=(FF, 14), text_color=GRIS_TX
                     ).pack(side="left", padx=(14, 4), pady=10)
        self._e_bus = ctk.CTkEntry(
            tb, placeholder_text="Buscar por N° orden o proveedor...",
            width=300, height=34, corner_radius=8,
            border_color=GRIS_BR, border_width=1)
        self._e_bus.pack(side="left", padx=(0, 16), pady=10)
        self._e_bus.bind("<KeyRelease>", lambda e: self.recargar())

        # Filtro estado
        ctk.CTkLabel(tb, text="Estado:", font=(FF, 11), text_color=GRIS_TX
                     ).pack(side="left", padx=(0, 6))
        self._cb_est = ctk.CTkComboBox(
            tb, values=["Todos","Recibida","Pendiente","Pagada","Anulada"],
            width=140, height=34, corner_radius=8,
            border_color=GRIS_BR, fg_color=BLANCO,
            button_color=AZ_CLA, dropdown_fg_color=BLANCO,
            command=lambda v: self.recargar())
        self._cb_est.set("Todos")
        self._cb_est.pack(side="left", padx=(0, 16), pady=10)

        # Badges
        self._bdg = {}
        for key, lbl, bg in [
            ("count", "Órdenes",    AZ_OSC),
            ("total", "Total $",    AZ_CLA),
            ("mes",   "Este mes $", VERDE),
        ]:
            pill = ctk.CTkFrame(tb, fg_color=bg, corner_radius=12)
            pill.pack(side="right", padx=6, pady=8)
            v = ctk.CTkLabel(pill, text="—", font=(FF, 13, "bold"),
                             text_color=BLANCO, width=90)
            v.pack(padx=12, pady=(4, 1))
            ctk.CTkLabel(pill, text=lbl, font=(FF, 8),
                         text_color=BLANCO).pack(padx=12, pady=(0, 4))
            self._bdg[key] = v

        # — Fila 2: tabla —
        wrap = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        wrap.grid(row=2, column=0, sticky="nsew")
        wrap.grid_columnconfigure(0, weight=1)
        wrap.grid_rowconfigure(0, weight=1)

        s = ttk.Style()
        s.theme_use("clam")
        s.configure("C.Treeview",
                    background=BLANCO, fieldbackground=BLANCO,
                    rowheight=28, font=(FF, 10), borderwidth=0)
        s.configure("C.Treeview.Heading",
                    background=AZ_OSC, foreground=BLANCO,
                    font=(FF, 10, "bold"), relief="flat", padding=(6, 7))
        s.map("C.Treeview",
              background=[("selected", AZ_ACE)],
              foreground=[("selected", BLANCO)])
        s.map("C.Treeview.Heading",
              background=[("active", AZ_MED)])

        cols = [
            ("orden",      "N° Orden",       115, "center"),
            ("fecha",      "Fecha",            90, "center"),
            ("proveedor",  "Proveedor",       175, "w"),
            ("items",      "Ítems",            55, "center"),
            ("subtotal",   "Subtotal $",      100, "e"),
            ("total",      "Total $",         110, "e"),
            ("pagado",     "Pagado $",        100, "e"),
            ("saldo",      "Saldo $",         100, "e"),
            ("forma",      "Forma Pago",       95, "center"),
            ("estado",     "Estado",           90, "center"),
        ]
        self._tree = ttk.Treeview(
            wrap, columns=[c[0] for c in cols],
            show="headings", style="C.Treeview", selectmode="browse")

        for cid, hdr_txt, w, anch in cols:
            self._tree.heading(cid, text=hdr_txt)
            self._tree.column(cid, width=w, anchor=anch,
                              stretch=(cid == "proveedor"))

        # Tags de color por estado
        for est, (_, fg, bg) in _TAG_ESTADO.items():
            self._tree.tag_configure(est,      background=bg,  foreground=fg)
            self._tree.tag_configure(est+"_a", background=self._oscurecer(bg),
                                     foreground=fg)

        vsb = ttk.Scrollbar(wrap, orient="vertical",   command=self._tree.yview)
        hsb = ttk.Scrollbar(wrap, orient="horizontal", command=self._tree.xview)
        self._tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self._tree.grid(row=0, column=0, sticky="nsew", padx=(12, 0), pady=10)
        vsb.grid(row=0, column=1, sticky="ns",  pady=10)
        hsb.grid(row=1, column=0, sticky="ew", padx=12, pady=(0, 6))
        self._tree.bind("<Double-1>", lambda e: self._ver_detalle())

        # — Fila 3: pie —
        pie = ctk.CTkFrame(self, fg_color="transparent")
        pie.grid(row=3, column=0, sticky="ew", pady=(6, 0))
        pie.grid_columnconfigure(0, weight=1)

        self._lbl_pie = ctk.CTkLabel(pie, text="", font=(FF, 10),
                                     text_color=GRIS_TX)
        self._lbl_pie.grid(row=0, column=0, sticky="w")

        btns = ctk.CTkFrame(pie, fg_color="transparent")
        btns.grid(row=0, column=1, sticky="e")
        ctk.CTkButton(btns, text="📄  Ver Detalle",
                      fg_color=AZ_MED, hover_color=AZ_OSC,
                      text_color=BLANCO, height=32, width=130,
                      corner_radius=7, font=(FF, 10, "bold"),
                      command=self._ver_detalle
                      ).pack(side="left", padx=(0, 8))

        # Leyenda de estados
        ley = ctk.CTkFrame(pie, fg_color="transparent")
        ley.grid(row=1, column=0, columnspan=2, sticky="w", pady=(4, 0))
        for est, (_, fg, bg) in _TAG_ESTADO.items():
            f = ctk.CTkFrame(ley, fg_color="transparent")
            f.pack(side="left", padx=8)
            ctk.CTkFrame(f, width=11, height=11, fg_color=bg,
                         corner_radius=3).pack(side="left", padx=(0, 3))
            ctk.CTkLabel(f, text=est, font=(FF, 9),
                         text_color=fg).pack(side="left")

    # ── Helpers visuales ──────────────────────────────────────────────────────
    @staticmethod
    def _oscurecer(hex_color):
        """Versión ligeramente más oscura de un color hex para filas alternas."""
        try:
            r = int(hex_color[1:3], 16)
            g = int(hex_color[3:5], 16)
            b = int(hex_color[5:7], 16)
            factor = 0.93
            return f"#{int(r*factor):02x}{int(g*factor):02x}{int(b*factor):02x}"
        except:
            return hex_color

    # ── Carga de datos ────────────────────────────────────────────────────────
    def recargar(self):
        for i in self._tree.get_children():
            self._tree.delete(i)

        q   = self._e_bus.get().strip().lower() if hasattr(self, "_e_bus") else ""
        est = self._cb_est.get() if hasattr(self, "_cb_est") else "Todos"

        try:
            c = _conn()
            rows = c.execute("""
                SELECT cp.id_compra, cp.numero_orden, cp.fecha,
                       cp.nombre_proveedor, cp.subtotal, cp.total,
                       cp.monto_pagado, cp.saldo,
                       cp.forma_pago, cp.estado,
                       COUNT(d.id_detalle) AS items
                FROM Compras cp
                LEFT JOIN CompraDetalle d ON d.id_compra = cp.id_compra
                GROUP BY cp.id_compra
                ORDER BY cp.id_compra DESC
            """).fetchall()
            c.close()
        except Exception as e:
            messagebox.showerror("Error DB", str(e)); return

        mes_act   = date.today().strftime("%Y-%m")
        total_mes = sum(r["total"] or 0 for r in rows
                        if (r["fecha"] or "").startswith(mes_act)
                        and r["estado"] != "Anulada")
        total_all = sum(r["total"] or 0 for r in rows
                        if r["estado"] != "Anulada")

        n = 0
        for i, r in enumerate(rows):
            oc  = r["numero_orden"] or ""
            prv = r["nombre_proveedor"] or "—"
            e   = r["estado"] or "Pendiente"

            if q and q not in oc.lower() and q not in prv.lower(): continue
            if est != "Todos" and e != est:                         continue

            tag = e + ("_a" if i % 2 else "")
            saldo_val = r["saldo"] or 0
            self._tree.insert("", "end", iid=str(r["id_compra"]), tags=(tag,),
                              values=(
                oc,
                r["fecha"] or "",
                prv,
                r["items"] or 0,
                f"$ {r['subtotal'] or 0:,.2f}",
                f"$ {r['total']    or 0:,.2f}",
                f"$ {r['monto_pagado'] or 0:,.2f}",
                f"$ {saldo_val:,.2f}",
                r["forma_pago"] or "Contado",
                e,
            ))
            n += 1

        self._bdg["count"].configure(text=str(n))
        self._bdg["total"].configure(text=f"${total_all:,.2f}")
        self._bdg["mes"].configure(text=f"${total_mes:,.2f}")

        filtros = []
        if q:          filtros.append(f'"{self._e_bus.get().strip()}"')
        if est != "Todos": filtros.append(est)
        self._lbl_pie.configure(
            text=f"  {n} orden{'es' if n!=1 else ''}"
                 + (f"  ·  Filtro: {', '.join(filtros)}" if filtros else ""))

    # ── Acciones ──────────────────────────────────────────────────────────────
    def _id_sel(self):
        sel = self._tree.selection()
        return int(sel[0]) if sel else None

    def _nueva(self):
        FormCompra(self, callback=self.recargar)

    def _ver_detalle(self):
        id_c = self._id_sel()
        if not id_c:
            messagebox.showwarning("Sin selección",
                "Seleccione una orden de la tabla."); return
        DetalleCompra(self, id_compra=id_c)


# ══════════════════════════════════════════════════════════════════════════════
# FORMULARIO NUEVA COMPRA
# ══════════════════════════════════════════════════════════════════════════════
class FormCompra(ctk.CTkToplevel):
    def __init__(self, parent, callback=None):
        super().__init__(parent)
        self._cb    = callback
        self._items = []   # lista de líneas del pedido

        self.title("Nueva Orden de Compra")
        self.geometry("940x700")
        self.minsize(880, 620)
        self.configure(fg_color=GRIS_BG)
        self.grab_set(); self.lift(); self.focus()
        self._build()

    # ── Layout general ────────────────────────────────────────────────────────
    def _build(self):
        # Header
        hdr = ctk.CTkFrame(self, fg_color=AZ_OSC, corner_radius=0)
        hdr.pack(fill="x")
        hdr.grid_columnconfigure(1, weight=1)

        self._num_oc = int(_cfg("siguiente_orden", "1"))
        ctk.CTkLabel(hdr, text="🛒  Nueva Orden de Compra",
                     font=(FF, 16, "bold"), text_color=BLANCO
                     ).grid(row=0, column=0, padx=20, pady=14, sticky="w")
        ctk.CTkLabel(hdr, text=f"OC-{self._num_oc:05d}",
                     font=(FF, 13, "bold"), text_color=AZ_ACE
                     ).grid(row=0, column=2, padx=20, pady=14, sticky="e")

        # Cuerpo dividido
        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=16, pady=12)
        body.grid_columnconfigure(0, weight=3)
        body.grid_columnconfigure(1, weight=2)
        body.grid_rowconfigure(0, weight=1)

        self._build_izq(body)
        self._build_der(body)

    # ── Lado izquierdo: buscador + tabla de ítems ─────────────────────────────
    def _build_izq(self, parent):
        izq = ctk.CTkFrame(parent, fg_color=BLANCO, corner_radius=10)
        izq.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        izq.grid_columnconfigure(0, weight=1)
        izq.grid_rowconfigure(3, weight=1)

        # ── Buscador de producto ──
        bus = ctk.CTkFrame(izq, fg_color=GRIS_BG, corner_radius=8)
        bus.grid(row=0, column=0, sticky="ew", padx=12, pady=(12, 4))
        bus.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(bus, text="Producto:",
                     font=(FF, 10, "bold"), text_color=AZ_OSC
                     ).grid(row=0, column=0, padx=(10, 6), pady=8)
        self._e_prod = ctk.CTkEntry(
            bus, placeholder_text="Código o nombre...",
            height=34, corner_radius=7, border_color=GRIS_BR, border_width=1)
        self._e_prod.grid(row=0, column=1, padx=(0, 8), pady=8, sticky="ew")
        self._e_prod.bind("<KeyRelease>", self._buscar_prod)

        # Dropdown resultados
        self._drop = ctk.CTkScrollableFrame(
            izq, fg_color=BLANCO, corner_radius=6,
            border_color=GRIS_BR, border_width=1, height=0)
        self._drop.grid(row=1, column=0, sticky="ew", padx=12, pady=(0, 4))

        # ── Panel captura cantidad / costo ──
        cap = ctk.CTkFrame(izq, fg_color=GRIS_BG, corner_radius=8)
        cap.grid(row=2, column=0, sticky="ew", padx=12, pady=(0, 8))
        cap.grid_columnconfigure((1, 3, 5, 7), weight=1)

        # Producto seleccionado
        ctk.CTkLabel(cap, text="Seleccionado:",
                     font=(FF, 9), text_color=GRIS_TX
                     ).grid(row=0, column=0, padx=(10, 4), pady=(8, 2))
        self._lbl_sel = ctk.CTkLabel(
            cap, text="— ninguno —",
            font=(FF, 10, "bold"), text_color=AZ_MED, anchor="w")
        self._lbl_sel.grid(row=0, column=1, columnspan=7,
                           padx=4, pady=(8, 2), sticky="w")

        # Campos de captura
        campos = [
            ("Cantidad",   "_e_qty",   "1",    70),
            ("Costo $",    "_e_costo", "0.00", 85),
        ]
        for col_i, (lbl, attr, ph, w) in enumerate(campos):
            ctk.CTkLabel(cap, text=lbl, font=(FF, 9), text_color=GRIS_TX
                         ).grid(row=1, column=col_i*2, padx=(10, 2), pady=(0, 8))
            e = ctk.CTkEntry(cap, width=w, height=32, corner_radius=6,
                             border_color=GRIS_BR, border_width=1,
                             fg_color=BLANCO, placeholder_text=ph)
            e.grid(row=1, column=col_i*2+1, padx=(0, 8), pady=(0, 8))
            setattr(self, attr, e)
            e.bind("<KeyRelease>", self._recalc)

        # Subtotal en vivo
        self._lbl_sub = ctk.CTkLabel(cap, text="$ 0.00",
                                     font=(FF, 13, "bold"), text_color=AZ_CLA)
        self._lbl_sub.grid(row=1, column=4, padx=(4, 8), pady=(0, 8))

        ctk.CTkButton(cap, text="➕ Agregar",
                      fg_color=AZ_CLA, hover_color=AZ_OSC,
                      text_color=BLANCO, height=32, width=110,
                      corner_radius=7, font=(FF, 10, "bold"),
                      command=self._agregar
                      ).grid(row=1, column=5, padx=(0, 10), pady=(0, 8))

        self._prod_sel = None

        # ── Tabla de ítems del pedido ──
        tbl_wrap = ctk.CTkFrame(izq, fg_color="transparent")
        tbl_wrap.grid(row=3, column=0, sticky="nsew", padx=12, pady=(0, 4))
        tbl_wrap.grid_columnconfigure(0, weight=1)
        tbl_wrap.grid_rowconfigure(0, weight=1)

        s = ttk.Style()
        s.configure("NC.Treeview",
                    background=BLANCO, fieldbackground=BLANCO,
                    rowheight=26, font=(FF, 10), borderwidth=0)
        s.configure("NC.Treeview.Heading",
                    background=AZ_MED, foreground=BLANCO,
                    font=(FF, 9, "bold"), relief="flat", padding=(4, 5))
        s.map("NC.Treeview",
              background=[("selected", AZ_ACE)],
              foreground=[("selected", BLANCO)])

        cols = [
            ("cod",  "Código",      80, "center"),
            ("desc", "Producto",   200, "w"),
            ("stk",  "Stock act.", 70,  "center"),
            ("qty",  "Cant.",       55, "center"),
            ("cu",   "Costo U. $",  90, "e"),
            ("sub",  "Subtotal $",  95, "e"),
        ]
        self._t_items = ttk.Treeview(
            tbl_wrap, columns=[c[0] for c in cols],
            show="headings", style="NC.Treeview", height=9)
        for cid, hd, w, anch in cols:
            self._t_items.heading(cid, text=hd)
            self._t_items.column(cid, width=w, anchor=anch,
                                 stretch=(cid == "desc"))

        self._t_items.tag_configure("par",   background="#F0F8FF")
        self._t_items.tag_configure("impar", background=BLANCO)
        self._t_items.tag_configure("bajo",  background=AMBAR_BG, foreground=AMBAR)

        vsb2 = ttk.Scrollbar(tbl_wrap, orient="vertical",
                             command=self._t_items.yview)
        self._t_items.configure(yscrollcommand=vsb2.set)
        self._t_items.grid(row=0, column=0, sticky="nsew")
        vsb2.grid(row=0, column=1, sticky="ns")

        ctk.CTkButton(izq, text="🗑  Quitar ítem seleccionado",
                      fg_color=ROJO_BG, hover_color="#F5B7B1",
                      text_color=ROJO, height=28, corner_radius=6,
                      font=(FF, 9), border_color=ROJO, border_width=1,
                      command=self._quitar
                      ).grid(row=4, column=0, padx=12, pady=(0, 10), sticky="w")

    # ── Lado derecho: proveedor + fecha + totales + guardar ───────────────────
    def _build_der(self, parent):
        der = ctk.CTkFrame(parent, fg_color=BLANCO, corner_radius=10)
        der.grid(row=0, column=1, sticky="nsew")
        der.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(der, text="Datos de la Orden",
                     font=(FF, 13, "bold"), text_color=AZ_OSC
                     ).pack(padx=16, pady=(16, 8), anchor="w")

        def _lbl(txt):
            ctk.CTkLabel(der, text=txt, font=(FF, 10), text_color=GRIS_TX
                         ).pack(anchor="w", padx=16, pady=(8, 2))

        def _entry(attr, ph="", state="normal"):
            e = ctk.CTkEntry(der, height=34, corner_radius=7,
                             border_color=GRIS_BR, border_width=1,
                             fg_color=BLANCO, placeholder_text=ph)
            if state == "disabled":
                e.configure(state="disabled", fg_color=GRIS_BG)
            e.pack(fill="x", padx=16, pady=(0, 4))
            setattr(self, attr, e)
            return e

        # Proveedor: ComboBox
        _lbl("Proveedor *")
        provs = self._get_proveedores()
        self._prov_map = {p[1]: p[0] for p in provs}
        self._cb_prov = ctk.CTkComboBox(
            der, values=[p[1] for p in provs],
            height=34, corner_radius=7,
            border_color=GRIS_BR, fg_color=BLANCO,
            button_color=AZ_CLA, dropdown_fg_color=BLANCO)
        self._cb_prov.set(provs[0][1] if provs else "")
        self._cb_prov.pack(fill="x", padx=16, pady=(0, 4))

        _lbl("Fecha de compra *")
        self._e_fecha = ctk.CTkEntry(
            der, height=34, corner_radius=7,
            border_color=GRIS_BR, border_width=1, fg_color=BLANCO)
        self._e_fecha.insert(0, date.today().strftime("%Y-%m-%d"))
        self._e_fecha.pack(fill="x", padx=16, pady=(0, 4))

        _lbl("Forma de pago")
        self._cb_pago = ctk.CTkComboBox(
            der, values=["Contado","Crédito","Transferencia",
                         "Punto de venta","Mixto"],
            height=34, corner_radius=7,
            border_color=GRIS_BR, fg_color=BLANCO,
            button_color=AZ_CLA, dropdown_fg_color=BLANCO)
        self._cb_pago.set("Contado")
        self._cb_pago.pack(fill="x", padx=16, pady=(0, 4))

        _lbl("Estado de la orden")
        self._cb_est = ctk.CTkComboBox(
            der, values=["Recibida","Pendiente","Parcial"],
            height=34, corner_radius=7,
            border_color=GRIS_BR, fg_color=BLANCO,
            button_color=AZ_CLA, dropdown_fg_color=BLANCO,
            command=self._on_estado)
        self._cb_est.set("Recibida")
        self._cb_est.pack(fill="x", padx=16, pady=(0, 4))

        self._nota_stock = ctk.CTkLabel(
            der, text="✅ Stock se sumará al guardar",
            font=(FF, 9), text_color=VERDE)
        self._nota_stock.pack(anchor="w", padx=16, pady=(0, 4))

        _lbl("Notas")
        self._txt_notas = ctk.CTkTextbox(
            der, height=55, corner_radius=7,
            border_color=GRIS_BR, border_width=1, fg_color=BLANCO)
        self._txt_notas.pack(fill="x", padx=16, pady=(0, 8))

        # ── Totales ──
        ctk.CTkFrame(der, height=1, fg_color=GRIS_BR).pack(fill="x", padx=16, pady=6)

        tot_f = ctk.CTkFrame(der, fg_color=GRIS_BG, corner_radius=8)
        tot_f.pack(fill="x", padx=16, pady=(0, 8))
        tot_f.grid_columnconfigure(1, weight=1)

        self._tot = {}
        for i, (key, lbl, sz, bold, col) in enumerate([
            ("items",    "Ítems en la orden:", 10, False, GRIS_TX),
            ("subtotal", "Subtotal:",           10, False, NEGRO),
            ("total",    "TOTAL a pagar:",      13, True,  AZ_OSC),
        ]):
            fw = "bold" if bold else "normal"
            ctk.CTkLabel(tot_f, text=lbl, font=(FF, sz, fw), text_color=col
                         ).grid(row=i, column=0, padx=(12,4), pady=5, sticky="w")
            v = ctk.CTkLabel(tot_f, text="—", font=(FF, sz, fw),
                             text_color=AZ_CLA if key=="total" else col)
            v.grid(row=i, column=1, padx=(4,12), pady=5, sticky="e")
            self._tot[key] = v

        # ── Botones ──
        ctk.CTkFrame(der, height=1, fg_color=GRIS_BR).pack(fill="x", padx=16, pady=4)

        ctk.CTkButton(der, text="💾  Guardar Orden",
                      fg_color=AZ_CLA, hover_color=AZ_OSC,
                      text_color=BLANCO, height=42, corner_radius=8,
                      font=(FF, 13, "bold"), command=self._guardar
                      ).pack(fill="x", padx=16, pady=(4, 6))

        ctk.CTkButton(der, text="Cancelar",
                      fg_color=GRIS_BR, text_color=NEGRO,
                      hover_color="#C8CDD5", height=34, corner_radius=8,
                      command=self.destroy
                      ).pack(fill="x", padx=16, pady=(0, 16))

    def _on_estado(self, val):
        suma = val == "Recibida"
        msg  = ("✅ Stock se sumará al guardar"
                if suma else "⚠️ Stock NO se modificará")
        col  = VERDE if suma else AMBAR
        self._nota_stock.configure(text=msg, text_color=col)

    # ── Búsqueda de productos ─────────────────────────────────────────────────
    def _buscar_prod(self, _=None):
        q = self._e_prod.get().strip().lower()
        for w in self._drop.winfo_children():
            w.destroy()

        if len(q) < 2:
            self._drop.configure(height=0); return

        try:
            c = _conn()
            rows = c.execute("""
                SELECT id_producto, codigo, descripcion,
                       costo_unitario, stock_actual, stock_minimo
                FROM Inventario
                WHERE activo=1
                  AND (LOWER(codigo) LIKE ? OR LOWER(descripcion) LIKE ?)
                ORDER BY descripcion LIMIT 10
            """, (f"%{q}%", f"%{q}%")).fetchall()
            c.close()
        except: return

        if not rows:
            ctk.CTkLabel(self._drop, text="Sin resultados",
                         font=(FF, 10), text_color=GRIS_TX
                         ).pack(padx=10, pady=6)
            self._drop.configure(height=32)
            return

        self._drop.configure(height=min(len(rows)*34, 170))
        for r in rows:
            stk = r["stock_actual"] or 0
            alerta = stk <= (r["stock_minimo"] or 0)
            fila = ctk.CTkFrame(self._drop, fg_color="transparent", cursor="hand2")
            fila.pack(fill="x")

            icono = "⚠️ " if alerta else "📦 "
            txt = (f"{icono}[{r['codigo']}]  {r['descripcion'][:32]}"
                   f"   Costo: ${r['costo_unitario'] or 0:.2f}"
                   f"   Stock: {stk:g}")
            col  = AMBAR if alerta else NEGRO
            lbl  = ctk.CTkLabel(fila, text=txt, font=(FF, 10),
                                text_color=col, anchor="w")
            lbl.pack(side="left", fill="x", expand=True, padx=8, pady=4)

            for w in (fila, lbl):
                w.bind("<Enter>",  lambda e, f=fila: f.configure(fg_color=GRIS_BG))
                w.bind("<Leave>",  lambda e, f=fila: f.configure(fg_color="transparent"))
                w.bind("<Button-1>",
                       lambda e, row=r: self._sel_prod(row))

    def _sel_prod(self, row):
        self._prod_sel = dict(row)
        self._lbl_sel.configure(
            text=f"[{row['codigo']}]  {row['descripcion']}")
        # Precargar costo actual
        for attr in ("_e_qty", "_e_costo"):
            getattr(self, attr).delete(0, "end")
        self._e_qty.insert(0, "1")
        self._e_costo.insert(0, f"{row['costo_unitario'] or 0:.2f}")
        # Cerrar dropdown
        for w in self._drop.winfo_children(): w.destroy()
        self._drop.configure(height=0)
        self._e_prod.delete(0, "end")
        self._recalc()
        self._e_qty.focus()

    def _recalc(self, _=None):
        qty   = _fl(self._e_qty.get())
        costo = _fl(self._e_costo.get())
        sub   = qty * costo
        self._lbl_sub.configure(text=f"$ {sub:,.2f}")

    # ── Gestión de ítems ──────────────────────────────────────────────────────
    def _agregar(self):
        if not self._prod_sel:
            messagebox.showwarning("Sin producto",
                "Busque y seleccione un producto primero."); return

        qty   = _fl(self._e_qty.get())
        costo = _fl(self._e_costo.get())

        if qty <= 0:
            messagebox.showerror("Cantidad inválida",
                "La cantidad debe ser mayor a 0."); return
        if costo < 0:
            messagebox.showerror("Costo inválido",
                "El costo no puede ser negativo."); return

        sub = qty * costo

        # Si el producto ya está → acumular cantidad
        for it in self._items:
            if it["id_producto"] == self._prod_sel["id_producto"]:
                it["cantidad"]      += qty
                it["costo_unitario"] = costo
                it["subtotal"]       = it["cantidad"] * costo
                self._refrescar_tabla()
                self._actualizar_totales()
                self._limpiar_selector()
                return

        self._items.append({
            "id_producto":    self._prod_sel["id_producto"],
            "codigo":         self._prod_sel["codigo"],
            "descripcion":    self._prod_sel["descripcion"],
            "stock_actual":   self._prod_sel.get("stock_actual", 0) or 0,
            "stock_minimo":   self._prod_sel.get("stock_minimo", 0) or 0,
            "cantidad":       qty,
            "costo_unitario": costo,
            "subtotal":       sub,
        })
        self._refrescar_tabla()
        self._actualizar_totales()
        self._limpiar_selector()

    def _limpiar_selector(self):
        self._prod_sel = None
        self._lbl_sel.configure(text="— ninguno —")
        for attr in ("_e_qty", "_e_costo"):
            getattr(self, attr).delete(0, "end")
        self._lbl_sub.configure(text="$ 0.00")

    def _quitar(self):
        sel = self._t_items.selection()
        if not sel: return
        self._items.pop(int(sel[0]))
        self._refrescar_tabla()
        self._actualizar_totales()

    def _refrescar_tabla(self):
        for i in self._t_items.get_children():
            self._t_items.delete(i)
        for idx, it in enumerate(self._items):
            bajo = it["stock_actual"] <= it["stock_minimo"]
            tag  = "bajo" if bajo else ("par" if idx % 2 == 0 else "impar")
            self._t_items.insert("", "end", iid=str(idx), tags=(tag,),
                                 values=(
                it["codigo"],
                it["descripcion"][:38],
                f"{it['stock_actual']:g}",
                f"{it['cantidad']:g}",
                f"$ {it['costo_unitario']:,.2f}",
                f"$ {it['subtotal']:,.2f}",
            ))

    def _actualizar_totales(self):
        n   = len(self._items)
        sub = sum(it["subtotal"] for it in self._items)
        self._tot["items"].configure(text=str(n))
        self._tot["subtotal"].configure(text=f"$ {sub:,.2f}")
        self._tot["total"].configure(text=f"$ {sub:,.2f}")

    # ── Guardar ───────────────────────────────────────────────────────────────
    def _guardar(self):
        if not self._items:
            messagebox.showwarning("Sin productos",
                "Agregue al menos un producto a la orden."); return

        nom_prov = self._cb_prov.get().strip()
        if not nom_prov:
            messagebox.showerror("Proveedor requerido",
                "Seleccione un proveedor."); return

        id_prov  = self._prov_map.get(nom_prov)
        fecha    = self._e_fecha.get().strip() or date.today().isoformat()
        forma    = self._cb_pago.get()
        estado   = self._cb_est.get()
        notas    = self._txt_notas.get("1.0", "end").strip()
        sub      = sum(it["subtotal"] for it in self._items)
        sumar_stock = (estado == "Recibida")

        num_oc = _sig_orden()

        try:
            c = _conn()

            # 1 — Cabecera de compra
            c.execute("""
                INSERT INTO Compras
                    (numero_orden, id_proveedor, nombre_proveedor, fecha,
                     subtotal, descuento, impuesto, total,
                     monto_pagado, saldo, forma_pago, estado, notas)
                VALUES (?,?,?,?,?,0,0,?,?,?,?,?,?)
            """, (num_oc, id_prov, nom_prov, fecha,
                  sub, sub,
                  sub if sumar_stock else 0,
                  0   if sumar_stock else sub,
                  forma, estado, notas))

            id_compra = c.lastrowid

            # 2 — Líneas de detalle + suma de stock (si Recibida)
            ahora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            for it in self._items:
                c.execute("""
                    INSERT INTO CompraDetalle
                        (id_compra, id_producto, descripcion,
                         cantidad, costo_unitario, subtotal)
                    VALUES (?,?,?,?,?,?)
                """, (id_compra, it["id_producto"], it["descripcion"],
                      it["cantidad"], it["costo_unitario"], it["subtotal"]))

                if sumar_stock:
                    # Suma al stock Y actualiza el costo unitario
                    c.execute("""
                        UPDATE Inventario
                        SET stock_actual      = stock_actual + ?,
                            costo_unitario    = ?,
                            fecha_actualizacion = ?
                        WHERE id_producto = ?
                    """, (it["cantidad"], it["costo_unitario"],
                          ahora, it["id_producto"]))

            c.commit(); c.close()

        except sqlite3.Error as e:
            messagebox.showerror("Error al guardar", str(e)); return

        accion = "Stock actualizado ✅" if sumar_stock else "Stock sin cambios (orden pendiente)"
        messagebox.showinfo(
            "✅ Orden guardada",
            f"Orden {num_oc} registrada correctamente.\n"
            f"Proveedor: {nom_prov}\n"
            f"Total: $ {sub:,.2f}\n"
            f"{accion}"
        )
        if self._cb: self._cb()
        self.destroy()

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _get_proveedores(self):
        try:
            c = _conn()
            rows = c.execute(
                "SELECT id_proveedor, nombre FROM Proveedores "
                "WHERE activo=1 ORDER BY nombre"
            ).fetchall()
            c.close()
            return [(r[0], r[1]) for r in rows]
        except:
            return [(0, "Sin proveedores")]


# ══════════════════════════════════════════════════════════════════════════════
# VENTANA DETALLE DE ORDEN
# ══════════════════════════════════════════════════════════════════════════════
class DetalleCompra(ctk.CTkToplevel):
    def __init__(self, parent, id_compra):
        super().__init__(parent)
        self._id = id_compra
        self.title("Detalle de Orden de Compra")
        self.geometry("720x530")
        self.configure(fg_color=GRIS_BG)
        self.grab_set(); self.lift()
        self._build()

    def _build(self):
        try:
            c   = _conn()
            oc  = c.execute("SELECT * FROM Compras WHERE id_compra=?",
                            (self._id,)).fetchone()
            det = c.execute("""
                SELECT d.*, i.codigo
                FROM CompraDetalle d
                LEFT JOIN Inventario i ON i.id_producto = d.id_producto
                WHERE d.id_compra=?
            """, (self._id,)).fetchall()
            c.close()
        except Exception as e:
            messagebox.showerror("Error", str(e)); self.destroy(); return

        if not oc:
            messagebox.showwarning("No encontrado", "Orden no encontrada.")
            self.destroy(); return

        est = oc["estado"] or "Pendiente"
        _, fg_est, bg_est = _TAG_ESTADO.get(est, ("", NEGRO, BLANCO))

        # Header
        hdr = ctk.CTkFrame(self, fg_color=AZ_OSC, corner_radius=0)
        hdr.pack(fill="x")
        ctk.CTkLabel(hdr,
                     text=f"🛒  {oc['numero_orden']}  —  {oc['fecha']}",
                     font=(FF, 14, "bold"), text_color=BLANCO
                     ).pack(side="left", padx=16, pady=12)
        ctk.CTkLabel(hdr, text=f"  {est}  ",
                     font=(FF, 11, "bold"), text_color=fg_est
                     ).pack(side="right", padx=16, pady=12)

        # Info
        info = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=0)
        info.pack(fill="x", padx=16, pady=(12, 6))
        prv  = oc["nombre_proveedor"] or "—"
        ctk.CTkLabel(info,
                     text=(f"Proveedor: {prv}     |     "
                           f"Forma de pago: {oc['forma_pago']}     |     "
                           f"Total: $ {oc['total']:,.2f}"),
                     font=(FF, 11), text_color=NEGRO
                     ).pack(padx=12, pady=8, anchor="w")

        # Tabla detalle
        wrap = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        wrap.pack(fill="both", expand=True, padx=16, pady=(0, 8))
        wrap.grid_columnconfigure(0, weight=1)
        wrap.grid_rowconfigure(0, weight=1)

        cols = [
            ("cod",  "Código",      80, "center"),
            ("desc", "Descripción",220, "w"),
            ("qty",  "Cant.",       60, "center"),
            ("cu",   "Costo U. $",  95, "e"),
            ("sub",  "Subtotal $", 100, "e"),
        ]
        tree = ttk.Treeview(wrap, columns=[c[0] for c in cols],
                            show="headings", style="C.Treeview", height=10)
        for cid, hd, w, anch in cols:
            tree.heading(cid, text=hd)
            tree.column(cid, width=w, anchor=anch, stretch=(cid == "desc"))
        tree.tag_configure("par",   background="#F0F8FF")
        tree.tag_configure("impar", background=BLANCO)
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        vsb.grid(row=0, column=1, sticky="ns", pady=10)

        for i, d in enumerate(det):
            tree.insert("", "end", tags=("par" if i%2==0 else "impar",),
                        values=(
                d["codigo"] or "—",
                d["descripcion"],
                f"{d['cantidad']:g}",
                f"$ {d['costo_unitario']:,.2f}",
                f"$ {d['subtotal']:,.2f}",
            ))

        # Totales
        tf = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        tf.pack(fill="x", padx=16, pady=(0, 12))
        for lbl, val in [
            ("Subtotal:", f"$ {oc['subtotal']:,.2f}"),
            ("Total:",    f"$ {oc['total']:,.2f}"),
            ("Pagado:",   f"$ {oc['monto_pagado'] or 0:,.2f}"),
            ("Saldo:",    f"$ {oc['saldo'] or 0:,.2f}"),
        ]:
            r = ctk.CTkFrame(tf, fg_color="transparent")
            r.pack(fill="x", padx=16, pady=2)
            ctk.CTkLabel(r, text=lbl, font=(FF, 10), text_color=GRIS_TX
                         ).pack(side="left")
            ctk.CTkLabel(r, text=val, font=(FF, 10, "bold"), text_color=NEGRO
                         ).pack(side="right")
