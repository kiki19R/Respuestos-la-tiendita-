"""
modules/ventas/vista.py
Módulo de Ventas completo — ERP Repuestos La Tiendita
  · Historial de ventas con tabla
  · Formulario nueva venta: búsqueda de producto, cantidad, precios automáticos
  · Descuento de stock al guardar
  · Imprimir factura en PDF con fpdf2
"""

import customtkinter as ctk
from tkinter import ttk, messagebox, filedialog
import sqlite3, os
from datetime import datetime, date
from utils.factura_pdf import imprimir_factura


# ── Rutas ─────────────────────────────────────────────────────────────────────
from utils.paths import BASE_DIR, DB_PATH

# ── Paleta ────────────────────────────────────────────────────────────────────
AZ_OSC   = "#0D1B2A"
AZ_MED   = "#1B3A5C"
AZ_CLA   = "#2E6DA4"
AZ_ACE   = "#3D9EE8"
BLANCO   = "#FFFFFF"
GRIS_BG  = "#F4F6F9"
GRIS_BR  = "#DDE3EA"
GRIS_TX  = "#5A6478"
NEGRO    = "#1A1A2E"
VERDE    = "#1E8449"
VERDE_BG = "#EAFAF1"
AMBAR    = "#B7770D"
AMBAR_BG = "#FEF9E7"
ROJO     = "#C0392B"
ROJO_BG  = "#FDEDEC"
FF       = "Segoe UI"

# ── Helpers ───────────────────────────────────────────────────────────────────
def _conn():
    c = sqlite3.connect(DB_PATH)
    c.execute("PRAGMA foreign_keys = ON")
    c.row_factory = sqlite3.Row
    return c

def _fl(v, d=0.0):
    try:    return float(str(v).replace(",", ".").strip()) if str(v).strip() else d
    except: return d

def _cfg(clave, default=""):
    try:
        c = _conn()
        r = c.execute("SELECT valor FROM Configuracion WHERE clave=?", (clave,)).fetchone()
        c.close()
        return r["valor"] if r else default
    except: return default

def _sig_factura():
    """Genera el siguiente número de factura y actualiza el contador."""
    c = _conn()
    n = int(_cfg("siguiente_factura", "1"))
    num = f"FAC-{n:05d}"
    c.execute("UPDATE Configuracion SET valor=? WHERE clave='siguiente_factura'", (str(n + 1),))
    c.commit(); c.close()
    return num


# ══════════════════════════════════════════════════════════════════════════════
# FRAME PRINCIPAL — Historial de ventas
# ══════════════════════════════════════════════════════════════════════════════
class VentasFrame(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="transparent")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)
        self._build()
        self.recargar()

    # ── Encabezado ────────────────────────────────────────────────────────────
    def _build(self):
        # — Fila 0: título + botón nueva venta —
        hdr = ctk.CTkFrame(self, fg_color="transparent")
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        hdr.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(hdr, text="Historial de Ventas",
                     font=(FF, 20, "bold"), text_color=AZ_OSC
                     ).grid(row=0, column=0, sticky="w")

        ctk.CTkButton(
            hdr, text="➕  Nueva Venta",
            fg_color=VERDE, hover_color="#145A32",
            text_color=BLANCO, height=38, width=160,
            corner_radius=8, font=(FF, 12, "bold"),
            command=self._nueva_venta
        ).grid(row=0, column=2, sticky="e")

        # — Fila 1: buscador + badges —
        tb = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        tb.grid(row=1, column=0, sticky="ew", pady=(0, 8))

        ctk.CTkLabel(tb, text="🔍", font=(FF, 14), text_color=GRIS_TX
                     ).pack(side="left", padx=(14, 4), pady=10)
        self._e_bus = ctk.CTkEntry(
            tb, placeholder_text="Buscar por N° factura o cliente...",
            width=300, height=34, corner_radius=8,
            border_color=GRIS_BR, border_width=1)
        self._e_bus.pack(side="left", padx=(0, 16), pady=10)
        self._e_bus.bind("<KeyRelease>", lambda e: self.recargar())

        # Badges resumen
        self._bdg = {}
        for key, lbl, bg in [
            ("count", "Ventas",    AZ_OSC),
            ("total", "Total $",   VERDE),
            ("mes",   "Este mes $",AZ_CLA),
        ]:
            pill = ctk.CTkFrame(tb, fg_color=bg, corner_radius=12)
            pill.pack(side="right", padx=6, pady=8)
            v = ctk.CTkLabel(pill, text="—", font=(FF, 13, "bold"),
                             text_color=BLANCO, width=80)
            v.pack(padx=12, pady=(4, 1))
            ctk.CTkLabel(pill, text=lbl, font=(FF, 8),
                         text_color=BLANCO).pack(padx=12, pady=(0, 4))
            self._bdg[key] = v

        # — Fila 2: tabla —
        wrap = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        wrap.grid(row=2, column=0, sticky="nsew")
        wrap.grid_columnconfigure(0, weight=1)
        wrap.grid_rowconfigure(0, weight=1)

        s = ttk.Style()
        s.theme_use("clam")
        s.configure("V.Treeview",
                    background=BLANCO, fieldbackground=BLANCO,
                    rowheight=28, font=(FF, 10), borderwidth=0)
        s.configure("V.Treeview.Heading",
                    background=AZ_OSC, foreground=BLANCO,
                    font=(FF, 10, "bold"), relief="flat", padding=(6, 7))
        s.map("V.Treeview",
              background=[("selected", AZ_ACE)],
              foreground=[("selected", BLANCO)])

        cols = [
            ("factura",  "N° Factura",  120, "center"),
            ("fecha",    "Fecha",        90, "center"),
            ("cliente",  "Cliente",     180, "w"),
            ("items",    "Ítems",        55, "center"),
            ("subtotal", "Subtotal $",  100, "e"),
            ("iva",      "IVA $",        80, "e"),
            ("total",    "Total $",     110, "e"),
            ("forma",    "Forma Pago",   95, "center"),
            ("estado",   "Estado",       90, "center"),
        ]
        self._tree = ttk.Treeview(
            wrap, columns=[c[0] for c in cols],
            show="headings", style="V.Treeview", selectmode="browse")

        for cid, hdr_txt, w, anch in cols:
            self._tree.heading(cid, text=hdr_txt)
            self._tree.column(cid, width=w, anchor=anch,
                              stretch=(cid == "cliente"))

        self._tree.tag_configure("Pagada",   background=VERDE_BG, foreground=VERDE)
        self._tree.tag_configure("Pagada_alt",background="#D5F5E3",foreground=VERDE)
        self._tree.tag_configure("Crédito",  background=AMBAR_BG, foreground=AMBAR)
        self._tree.tag_configure("Anulada",  background=ROJO_BG,  foreground=ROJO)

        vsb = ttk.Scrollbar(wrap, orient="vertical",   command=self._tree.yview)
        hsb = ttk.Scrollbar(wrap, orient="horizontal", command=self._tree.xview)
        self._tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self._tree.grid(row=0, column=0, sticky="nsew", padx=(12, 0), pady=10)
        vsb.grid(row=0, column=1, sticky="ns", pady=10)
        hsb.grid(row=1, column=0, sticky="ew", padx=12, pady=(0, 6))

        self._tree.bind("<Double-1>", lambda e: self._ver_detalle())

        # — Fila 3: pie con botones —
        pie = ctk.CTkFrame(self, fg_color="transparent")
        pie.grid(row=3, column=0, sticky="ew", pady=(6, 0))
        pie.grid_columnconfigure(0, weight=1)

        self._lbl_pie = ctk.CTkLabel(pie, text="", font=(FF, 10), text_color=GRIS_TX)
        self._lbl_pie.grid(row=0, column=0, sticky="w")

        btns = ctk.CTkFrame(pie, fg_color="transparent")
        btns.grid(row=0, column=1, sticky="e")
        ctk.CTkButton(btns, text="📄  Ver Detalle",
                      fg_color=AZ_MED, hover_color=AZ_OSC,
                      text_color=BLANCO, height=32, width=130,
                      corner_radius=7, font=(FF, 10, "bold"),
                      command=self._ver_detalle
                      ).pack(side="left", padx=(0, 8))
        ctk.CTkButton(btns, text="🖨  Exportar PDF",
                      fg_color=AZ_CLA, hover_color=AZ_OSC,
                      text_color=BLANCO, height=32, width=140,
                      corner_radius=7, font=(FF, 10, "bold"),
                      command=self._exportar_pdf
                      ).pack(side="left")

    # ── Carga de datos ────────────────────────────────────────────────────────
    def recargar(self):
        for i in self._tree.get_children():
            self._tree.delete(i)

        q = self._e_bus.get().strip().lower() if hasattr(self, "_e_bus") else ""

        try:
            c = _conn()
            rows = c.execute("""
                SELECT v.id_venta, v.numero_factura, v.fecha,
                       v.nombre_cliente, v.subtotal, v.impuesto,
                       v.total, v.forma_pago, v.estado,
                       COUNT(d.id_detalle) as items
                FROM Ventas v
                LEFT JOIN VentaDetalle d ON d.id_venta = v.id_venta
                GROUP BY v.id_venta
                ORDER BY v.id_venta DESC
            """).fetchall()

            mes_actual = date.today().strftime("%Y-%m")
            total_mes  = sum(r["total"] or 0 for r in rows
                             if (r["fecha"] or "").startswith(mes_actual)
                             and r["estado"] != "Anulada")
            total_all  = sum(r["total"] or 0 for r in rows
                             if r["estado"] != "Anulada")
            c.close()
        except Exception as e:
            messagebox.showerror("Error DB", str(e)); return

        n = 0
        for i, r in enumerate(rows):
            fac = r["numero_factura"] or ""
            cli = r["nombre_cliente"] or "— Consumidor Final —"
            if q and q not in fac.lower() and q not in cli.lower():
                continue
            est = r["estado"] or "Pagada"
            tag = est if i % 2 == 0 else f"{est}_alt"

            self._tree.insert("", "end", iid=str(r["id_venta"]), tags=(tag,),
                              values=(
                fac,
                r["fecha"] or "",
                cli,
                r["items"] or 0,
                f"$ {r['subtotal'] or 0:,.2f}",
                f"$ {r['impuesto'] or 0:,.2f}",
                f"$ {r['total'] or 0:,.2f}",
                r["forma_pago"] or "Contado",
                est,
            ))
            n += 1

        self._bdg["count"].configure(text=str(n))
        self._bdg["total"].configure(text=f"${total_all:,.2f}")
        self._bdg["mes"].configure(text=f"${total_mes:,.2f}")
        self._lbl_pie.configure(
            text=f"  {n} venta{'s' if n != 1 else ''}"
                 + (f"  ·  Filtro: \"{self._e_bus.get().strip()}\"" if q else ""))

    def _id_seleccionado(self):
        sel = self._tree.selection()
        return int(sel[0]) if sel else None

    def _nueva_venta(self):
        FormVenta(self, callback=self.recargar)

    def _ver_detalle(self):
        id_v = self._id_seleccionado()
        if not id_v:
            messagebox.showwarning("Sin selección", "Seleccione una venta de la tabla.")
            return
        DetalleVenta(self, id_venta=id_v)

    def _exportar_pdf(self):
        id_v = self._id_seleccionado()
        if not id_v:
            messagebox.showwarning("Sin selección",
                                   "Seleccione una venta para exportar a PDF.")
            return
        imprimir_factura(id_v, parent=self)


# ══════════════════════════════════════════════════════════════════════════════
# FORMULARIO NUEVA VENTA
# ══════════════════════════════════════════════════════════════════════════════
class FormVenta(ctk.CTkToplevel):
    def __init__(self, parent, callback=None):
        super().__init__(parent)
        self._cb    = callback
        self._items = []         # lista de dicts: producto + cantidad + precio + subtotal
        self._iva   = _fl(_cfg("iva_porcentaje", "16"))

        self.title("Nueva Venta")
        self.geometry("900x680")
        self.minsize(860, 600)
        self.configure(fg_color=GRIS_BG)
        self.grab_set(); self.lift(); self.focus()

        self._build()

    # ── Layout ────────────────────────────────────────────────────────────────
    def _build(self):
        # Header azul
        hdr = ctk.CTkFrame(self, fg_color=AZ_OSC, corner_radius=0)
        hdr.pack(fill="x")
        hdr.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(hdr, text="🧾  Nueva Venta",
                     font=(FF, 16, "bold"), text_color=BLANCO
                     ).grid(row=0, column=0, padx=20, pady=14, sticky="w")

        # N° factura (automático, solo lectura)
        self._num_fac = _cfg("siguiente_factura", "?")
        ctk.CTkLabel(hdr,
                     text=f"N° FAC-{int(self._num_fac):05d}",
                     font=(FF, 13, "bold"), text_color=AZ_ACE
                     ).grid(row=0, column=2, padx=20, pady=14, sticky="e")

        # Cuerpo dividido en 2 mitades
        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=16, pady=12)
        body.grid_columnconfigure(0, weight=3)
        body.grid_columnconfigure(1, weight=2)
        body.grid_rowconfigure(0, weight=1)

        self._build_izq(body)   # Lado izquierdo: buscador + tabla de ítems
        self._build_der(body)   # Lado derecho: cliente, fecha, totales, guardar

    def _build_izq(self, parent):
        izq = ctk.CTkFrame(parent, fg_color=BLANCO, corner_radius=10)
        izq.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        izq.grid_columnconfigure(0, weight=1)
        izq.grid_rowconfigure(2, weight=1)

        # — Buscador de producto —
        bus_frame = ctk.CTkFrame(izq, fg_color=GRIS_BG, corner_radius=8)
        bus_frame.grid(row=0, column=0, sticky="ew", padx=12, pady=(12, 8))
        bus_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(bus_frame, text="Buscar producto:",
                     font=(FF, 10, "bold"), text_color=AZ_OSC
                     ).grid(row=0, column=0, padx=(10, 6), pady=8)
        self._e_prod = ctk.CTkEntry(
            bus_frame, placeholder_text="Código o nombre del producto...",
            height=34, corner_radius=7,
            border_color=GRIS_BR, border_width=1)
        self._e_prod.grid(row=0, column=1, padx=(0, 6), pady=8, sticky="ew")
        self._e_prod.bind("<KeyRelease>", self._buscar_producto)
        self._e_prod.bind("<Return>",     self._buscar_producto)

        # Dropdown de resultados (ListBox simulado con frame)
        self._drop = ctk.CTkScrollableFrame(
            izq, fg_color=BLANCO, corner_radius=6,
            border_color=GRIS_BR, border_width=1, height=0)
        self._drop.grid(row=1, column=0, sticky="ew", padx=12, pady=(0, 4))
        self._drop_visible = False

        # — Panel de cantidad + precio al seleccionar —
        sel_frame = ctk.CTkFrame(izq, fg_color=GRIS_BG, corner_radius=8)
        sel_frame.grid(row=2, column=0, sticky="ew", padx=12, pady=(0, 8))
        sel_frame.grid_columnconfigure((1, 3, 5), weight=1)

        ctk.CTkLabel(sel_frame, text="Producto:",
                     font=(FF, 10), text_color=GRIS_TX
                     ).grid(row=0, column=0, padx=(10, 4), pady=8)
        self._lbl_sel = ctk.CTkLabel(sel_frame, text="— ninguno seleccionado —",
                                     font=(FF, 10, "bold"), text_color=AZ_MED,
                                     anchor="w")
        self._lbl_sel.grid(row=0, column=1, columnspan=5, padx=4, pady=8, sticky="w")

        for col, (lbl, key, ph, w) in enumerate([
            ("Cantidad",  "qty",    "1",      70),
            ("Precio $",  "precio", "0.00",   80),
            ("Desc. %",   "desc",   "0",      60),
        ]):
            ctk.CTkLabel(sel_frame, text=lbl, font=(FF, 9), text_color=GRIS_TX
                         ).grid(row=1, column=col * 2, padx=(10, 2), pady=(0, 8))
            e = ctk.CTkEntry(sel_frame, width=w, height=32, corner_radius=6,
                             border_color=GRIS_BR, border_width=1,
                             placeholder_text=ph, fg_color=BLANCO)
            e.grid(row=1, column=col * 2 + 1, padx=(0, 6), pady=(0, 8))
            setattr(self, f"_e_{key}", e)
            e.bind("<KeyRelease>", self._recalc_linea)

        self._lbl_subtotal = ctk.CTkLabel(sel_frame, text="$ 0.00",
                                          font=(FF, 13, "bold"), text_color=VERDE)
        self._lbl_subtotal.grid(row=1, column=6, padx=(4, 8), pady=(0, 8))

        ctk.CTkButton(sel_frame, text="➕ Agregar",
                      fg_color=AZ_CLA, hover_color=AZ_OSC,
                      text_color=BLANCO, height=32, width=100,
                      corner_radius=7, font=(FF, 10, "bold"),
                      command=self._agregar_item
                      ).grid(row=1, column=7, padx=(0, 10), pady=(0, 8))

        self._prod_sel = None    # producto actualmente en el selector

        # — Tabla de ítems —
        tbl_wrap = ctk.CTkFrame(izq, fg_color="transparent")
        tbl_wrap.grid(row=3, column=0, sticky="nsew", padx=12, pady=(0, 12))
        tbl_wrap.grid_columnconfigure(0, weight=1)
        tbl_wrap.grid_rowconfigure(0, weight=1)
        izq.grid_rowconfigure(3, weight=1)

        s = ttk.Style()
        s.configure("NV.Treeview",
                    background=BLANCO, fieldbackground=BLANCO,
                    rowheight=26, font=(FF, 10), borderwidth=0)
        s.configure("NV.Treeview.Heading",
                    background=AZ_MED, foreground=BLANCO,
                    font=(FF, 9, "bold"), relief="flat", padding=(4, 5))
        s.map("NV.Treeview",
              background=[("selected", AZ_ACE)],
              foreground=[("selected", BLANCO)])

        cols = [
            ("cod",   "Código",    80,  "center"),
            ("desc",  "Producto", 200,  "w"),
            ("qty",   "Cant.",     50,  "center"),
            ("punit", "P.Unit $",  80,  "e"),
            ("desc%", "Desc%",     50,  "center"),
            ("sub",   "Subtotal $",90,  "e"),
        ]
        self._items_tree = ttk.Treeview(
            tbl_wrap, columns=[c[0] for c in cols],
            show="headings", style="NV.Treeview", height=8)

        for cid, hd, w, anch in cols:
            self._items_tree.heading(cid, text=hd)
            self._items_tree.column(cid, width=w, anchor=anch,
                                    stretch=(cid == "desc"))

        vsb2 = ttk.Scrollbar(tbl_wrap, orient="vertical",
                              command=self._items_tree.yview)
        self._items_tree.configure(yscrollcommand=vsb2.set)
        self._items_tree.grid(row=0, column=0, sticky="nsew")
        vsb2.grid(row=0, column=1, sticky="ns")

        # Botón quitar ítem
        ctk.CTkButton(izq, text="🗑  Quitar ítem seleccionado",
                      fg_color=ROJO_BG, hover_color="#F5B7B1",
                      text_color=ROJO, height=28, corner_radius=6,
                      font=(FF, 9), border_color=ROJO, border_width=1,
                      command=self._quitar_item
                      ).grid(row=4, column=0, padx=12, pady=(0, 10), sticky="w")

    def _build_der(self, parent):
        der = ctk.CTkFrame(parent, fg_color=BLANCO, corner_radius=10)
        der.grid(row=0, column=1, sticky="nsew")
        der.grid_columnconfigure(0, weight=1)

        def _lbl(p, txt, bold=False, color=GRIS_TX):
            ctk.CTkLabel(p, text=txt, font=(FF, 10, "bold" if bold else "normal"),
                         text_color=color).pack(anchor="w", padx=16, pady=(10, 2))

        def _entry(p, key, ph="", ancho=None):
            e = ctk.CTkEntry(p, height=34, corner_radius=7,
                             border_color=GRIS_BR, border_width=1,
                             fg_color=BLANCO, placeholder_text=ph)
            if ancho: e.configure(width=ancho)
            e.pack(fill="x", padx=16, pady=(0, 4))
            setattr(self, f"_e_{key}", e)
            return e

        # — Datos de la venta —
        ctk.CTkLabel(der, text="Datos de la Venta",
                     font=(FF, 13, "bold"), text_color=AZ_OSC
                     ).pack(padx=16, pady=(16, 8), anchor="w")

        _lbl(der, "Cliente")
        # Combo de clientes
        clientes = self._get_clientes()
        self._cb_cli = ctk.CTkComboBox(
            der, values=[c[1] for c in clientes],
            height=34, corner_radius=7,
            border_color=GRIS_BR, fg_color=BLANCO,
            button_color=AZ_CLA, dropdown_fg_color=BLANCO)
        self._cb_cli.set("— Consumidor Final —")
        self._cb_cli.pack(fill="x", padx=16, pady=(0, 4))
        self._clientes_map = {c[1]: c[0] for c in clientes}

        _lbl(der, "Fecha")
        self._e_fecha = ctk.CTkEntry(
            der, height=34, corner_radius=7,
            border_color=GRIS_BR, border_width=1, fg_color=BLANCO)
        self._e_fecha.insert(0, date.today().strftime("%Y-%m-%d"))
        self._e_fecha.pack(fill="x", padx=16, pady=(0, 4))

        _lbl(der, "Forma de pago")
        self._cb_pago = ctk.CTkComboBox(
            der, values=["Contado", "Crédito", "Transferencia",
                         "Punto de venta", "Mixto"],
            height=34, corner_radius=7,
            border_color=GRIS_BR, fg_color=BLANCO, button_color=AZ_CLA,
            dropdown_fg_color=BLANCO)
        self._cb_pago.set("Contado")
        self._cb_pago.pack(fill="x", padx=16, pady=(0, 4))

        _lbl(der, "Notas")
        self._txt_notas = ctk.CTkTextbox(
            der, height=55, corner_radius=7,
            border_color=GRIS_BR, border_width=1, fg_color=BLANCO)
        self._txt_notas.pack(fill="x", padx=16, pady=(0, 8))

        # — Totales —
        sep = ctk.CTkFrame(der, height=1, fg_color=GRIS_BR)
        sep.pack(fill="x", padx=16, pady=8)

        totales_frame = ctk.CTkFrame(der, fg_color=GRIS_BG, corner_radius=8)
        totales_frame.pack(fill="x", padx=16, pady=(0, 8))
        totales_frame.grid_columnconfigure(1, weight=1)

        self._tot_labels = {}
        filas_tot = [
            ("subtotal", "Subtotal:",  FF, 10,  NEGRO),
            ("iva",      f"IVA ({self._iva:.0f}%):", FF, 10, NEGRO),
            ("total",    "TOTAL:",      FF, 14, AZ_OSC),
        ]
        for i, (key, lbl, font, size, col) in enumerate(filas_tot):
            bold = "bold" if key == "total" else "normal"
            ctk.CTkLabel(totales_frame, text=lbl,
                         font=(font, size, bold), text_color=col
                         ).grid(row=i, column=0, padx=(12, 4), pady=5, sticky="w")
            v = ctk.CTkLabel(totales_frame, text="$ 0.00",
                             font=(font, size, bold),
                             text_color=VERDE if key == "total" else col)
            v.grid(row=i, column=1, padx=(4, 12), pady=5, sticky="e")
            self._tot_labels[key] = v

        # — Botones —
        ctk.CTkFrame(der, height=1, fg_color=GRIS_BR).pack(fill="x", padx=16, pady=4)

        ctk.CTkButton(der, text="💾  Guardar Venta",
                      fg_color=VERDE, hover_color="#145A32",
                      text_color=BLANCO, height=42, corner_radius=8,
                      font=(FF, 13, "bold"), command=self._guardar
                      ).pack(fill="x", padx=16, pady=(4, 6))

        ctk.CTkButton(der, text="Cancelar",
                      fg_color=GRIS_BR, text_color=NEGRO,
                      hover_color="#C8CDD5", height=34, corner_radius=8,
                      font=(FF, 10), command=self.destroy
                      ).pack(fill="x", padx=16, pady=(0, 16))

    # ── Búsqueda de productos ─────────────────────────────────────────────────
    def _buscar_producto(self, _=None):
        q = self._e_prod.get().strip().lower()
        # Limpiar dropdown
        for w in self._drop.winfo_children():
            w.destroy()

        if len(q) < 2:
            self._drop.configure(height=0)
            return

        try:
            c = _conn()
            rows = c.execute("""
                SELECT id_producto, codigo, descripcion,
                       precio_venta, costo_unitario, stock_actual
                FROM Inventario
                WHERE activo=1
                  AND (LOWER(codigo) LIKE ? OR LOWER(descripcion) LIKE ?)
                ORDER BY descripcion
                LIMIT 12
            """, (f"%{q}%", f"%{q}%")).fetchall()
            c.close()
        except: return

        if not rows:
            ctk.CTkLabel(self._drop, text="Sin resultados",
                         font=(FF, 10), text_color=GRIS_TX).pack(padx=10, pady=6)
            self._drop.configure(height=36)
            return

        self._drop.configure(height=min(len(rows) * 36, 180))
        for r in rows:
            stk   = r["stock_actual"] or 0
            color = VERDE if stk > 0 else ROJO
            fila  = ctk.CTkFrame(self._drop, fg_color="transparent", cursor="hand2")
            fila.pack(fill="x")
            txt = (f"[{r['codigo']}]  {r['descripcion'][:32]}  "
                   f"  $ {r['precio_venta'] or 0:.2f}  "
                   f"  Stock: {stk:g}")
            lbl = ctk.CTkLabel(fila, text=txt, font=(FF, 10),
                               text_color=NEGRO, anchor="w")
            lbl.pack(side="left", fill="x", expand=True, padx=8, pady=5)
            ctk.CTkLabel(fila, text=f"stk:{stk:g}", font=(FF, 9),
                         text_color=color).pack(side="right", padx=8)
            # Hover visual
            for widget in (fila, lbl):
                widget.bind("<Enter>",
                    lambda e, f=fila: f.configure(fg_color=GRIS_BG))
                widget.bind("<Leave>",
                    lambda e, f=fila: f.configure(fg_color="transparent"))
                widget.bind("<Button-1>",
                    lambda e, row=r: self._seleccionar_producto(row))

    def _seleccionar_producto(self, row):
        self._prod_sel = dict(row)
        self._lbl_sel.configure(
            text=f"[{row['codigo']}]  {row['descripcion']}")
        # Limpiar y rellenar campos
        for attr in ("_e_qty", "_e_precio", "_e_desc"):
            e = getattr(self, attr)
            e.delete(0, "end")
        self._e_qty.insert(0, "1")
        self._e_precio.insert(0, f"{row['precio_venta'] or 0:.2f}")
        self._e_desc.insert(0, "0")
        # Cerrar dropdown
        for w in self._drop.winfo_children():
            w.destroy()
        self._drop.configure(height=0)
        self._e_prod.delete(0, "end")
        self._recalc_linea()
        self._e_qty.focus()

    def _recalc_linea(self, _=None):
        qty    = _fl(self._e_qty.get())
        precio = _fl(self._e_precio.get())
        desc   = _fl(self._e_desc.get())
        sub    = qty * precio * (1 - desc / 100)
        self._lbl_subtotal.configure(text=f"$ {sub:,.2f}")

    # ── Gestión de ítems ──────────────────────────────────────────────────────
    def _agregar_item(self):
        if not self._prod_sel:
            messagebox.showwarning("Sin producto",
                "Busque y seleccione un producto primero.")
            return
        qty    = _fl(self._e_qty.get())
        precio = _fl(self._e_precio.get())
        desc_p = _fl(self._e_desc.get())

        if qty <= 0:
            messagebox.showerror("Cantidad inválida",
                "La cantidad debe ser mayor a 0."); return
        if precio <= 0:
            messagebox.showerror("Precio inválido",
                "El precio debe ser mayor a 0."); return

        stk = self._prod_sel.get("stock_actual", 0) or 0
        if qty > stk:
            if not messagebox.askyesno("Stock insuficiente",
                f"Stock disponible: {stk:g}  |  Cantidad pedida: {qty:g}\n"
                f"¿Desea agregarlo de todas formas?"):
                return

        sub = qty * precio * (1 - desc_p / 100)

        # Verificar si el producto ya está en la lista → acumular
        for item in self._items:
            if item["id_producto"] == self._prod_sel["id_producto"]:
                item["cantidad"] += qty
                item["precio_unitario"] = precio
                item["descuento"]       = desc_p
                item["subtotal"]        = item["cantidad"] * precio * (1 - desc_p / 100)
                self._refrescar_items_tree()
                self._actualizar_totales()
                return

        self._items.append({
            "id_producto":    self._prod_sel["id_producto"],
            "codigo":         self._prod_sel["codigo"],
            "descripcion":    self._prod_sel["descripcion"],
            "cantidad":       qty,
            "precio_unitario":precio,
            "costo_unitario": self._prod_sel.get("costo_unitario", 0) or 0,
            "descuento":      desc_p,
            "subtotal":       sub,
        })
        self._refrescar_items_tree()
        self._actualizar_totales()
        self._prod_sel = None
        self._lbl_sel.configure(text="— ninguno seleccionado —")
        self._e_qty.delete(0, "end")
        self._e_precio.delete(0, "end")
        self._e_desc.delete(0, "end")
        self._lbl_subtotal.configure(text="$ 0.00")

    def _quitar_item(self):
        sel = self._items_tree.selection()
        if not sel: return
        idx = int(sel[0])
        self._items.pop(idx)
        self._refrescar_items_tree()
        self._actualizar_totales()

    def _refrescar_items_tree(self):
        for i in self._items_tree.get_children():
            self._items_tree.delete(i)
        for idx, it in enumerate(self._items):
            self._items_tree.insert("", "end", iid=str(idx), values=(
                it["codigo"],
                it["descripcion"][:40],
                f"{it['cantidad']:g}",
                f"$ {it['precio_unitario']:,.2f}",
                f"{it['descuento']:.0f}%",
                f"$ {it['subtotal']:,.2f}",
            ))

    def _actualizar_totales(self):
        sub  = sum(it["subtotal"] for it in self._items)
        iva  = sub * self._iva / 100
        tot  = sub + iva
        self._tot_labels["subtotal"].configure(text=f"$ {sub:,.2f}")
        self._tot_labels["iva"].configure(text=f"$ {iva:,.2f}")
        self._tot_labels["total"].configure(text=f"$ {tot:,.2f}")

    # ── Guardar ───────────────────────────────────────────────────────────────
    def _guardar(self):
        if not self._items:
            messagebox.showwarning("Sin productos",
                "Agregue al menos un producto a la venta."); return

        fecha  = self._e_fecha.get().strip() or date.today().isoformat()
        nombre_cli = self._cb_cli.get().strip()
        id_cli = self._clientes_map.get(nombre_cli)
        if nombre_cli == "— Consumidor Final —":
            nombre_cli = None; id_cli = None

        sub   = sum(it["subtotal"] for it in self._items)
        iva   = sub * self._iva / 100
        total = sub + iva
        forma = self._cb_pago.get()
        notas = self._txt_notas.get("1.0", "end").strip()

        num_fac = _sig_factura()

        try:
            c = _conn()
            # 1 — Insertar cabecera de venta
            c.execute("""
                INSERT INTO Ventas
                    (numero_factura, id_cliente, nombre_cliente, fecha,
                     subtotal, impuesto, total, monto_pagado, saldo,
                     forma_pago, estado, notas)
                VALUES (?,?,?,?,?,?,?,?,?,'{}','Pagada',?)
            """.format(forma),
            (num_fac, id_cli, nombre_cli, fecha,
             sub, iva, total, total, 0, notas))

            id_venta = c.lastrowid

            # 2 — Insertar líneas de detalle + descontar stock
            for it in self._items:
                c.execute("""
                    INSERT INTO VentaDetalle
                        (id_venta, id_producto, descripcion,
                         cantidad, precio_unitario, descuento,
                         costo_unitario, subtotal)
                    VALUES (?,?,?,?,?,?,?,?)
                """, (id_venta, it["id_producto"], it["descripcion"],
                      it["cantidad"], it["precio_unitario"], it["descuento"],
                      it["costo_unitario"], it["subtotal"]))

                # Descuento de stock
                c.execute("""
                    UPDATE Inventario
                       SET stock_actual = stock_actual - ?,
                           fecha_actualizacion = ?
                     WHERE id_producto = ?
                """, (it["cantidad"],
                      datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                      it["id_producto"]))

            c.commit()
            c.close()

        except sqlite3.Error as e:
            messagebox.showerror("Error al guardar", str(e)); return

        if messagebox.askyesno("✅ Venta guardada",
            f"Venta {num_fac} guardada correctamente.\n"
            f"Total: $ {total:,.2f}\n\n"
            f"¿Desea exportar el PDF de la factura?"):
            imprimir_factura(id_venta, parent=self)

        if self._cb: self._cb()
        self.destroy()

    # ── Helpers internos ──────────────────────────────────────────────────────
    def _get_clientes(self):
        try:
            c = _conn()
            rows = c.execute(
                "SELECT id_cliente, nombre FROM Clientes WHERE activo=1 ORDER BY nombre"
            ).fetchall()
            c.close()
            return [(-1, "— Consumidor Final —")] + [(r[0], r[1]) for r in rows]
        except:
            return [(-1, "— Consumidor Final —")]


# ══════════════════════════════════════════════════════════════════════════════
# VENTANA DETALLE DE VENTA
# ══════════════════════════════════════════════════════════════════════════════
class DetalleVenta(ctk.CTkToplevel):
    def __init__(self, parent, id_venta):
        super().__init__(parent)
        self._id = id_venta
        self.title("Detalle de Venta")
        self.geometry("700x500")
        self.configure(fg_color=GRIS_BG)
        self.grab_set(); self.lift()
        self._build()

    def _build(self):
        try:
            c = _conn()
            v = c.execute("SELECT * FROM Ventas WHERE id_venta=?",
                          (self._id,)).fetchone()
            det = c.execute("""
                SELECT d.*, i.codigo
                FROM VentaDetalle d
                LEFT JOIN Inventario i ON i.id_producto = d.id_producto
                WHERE d.id_venta=?
            """, (self._id,)).fetchall()
            c.close()
        except Exception as e:
            messagebox.showerror("Error", str(e)); self.destroy(); return

        if not v:
            messagebox.showwarning("No encontrado", "Venta no encontrada.")
            self.destroy(); return

        # Header
        hdr = ctk.CTkFrame(self, fg_color=AZ_OSC, corner_radius=0)
        hdr.pack(fill="x")
        ctk.CTkLabel(hdr,
                     text=f"📄  {v['numero_factura']}  —  {v['fecha']}",
                     font=(FF, 14, "bold"), text_color=BLANCO
                     ).pack(padx=16, pady=12, side="left")
        est_color = VERDE if v["estado"] == "Pagada" else AMBAR
        ctk.CTkLabel(hdr, text=v["estado"] or "—",
                     font=(FF, 11, "bold"), text_color=est_color
                     ).pack(padx=16, pady=12, side="right")

        # Info
        info = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=0)
        info.pack(fill="x", padx=16, pady=(12, 8))
        cli = v["nombre_cliente"] or "Consumidor Final"
        ctk.CTkLabel(info, text=f"Cliente: {cli}    |    Forma de pago: {v['forma_pago']}",
                     font=(FF, 11), text_color=NEGRO).pack(padx=12, pady=8, anchor="w")

        # Tabla detalle
        wrap = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        wrap.pack(fill="both", expand=True, padx=16, pady=(0, 8))
        wrap.grid_columnconfigure(0, weight=1)
        wrap.grid_rowconfigure(0, weight=1)

        cols = [("cod","Código",80,"center"),("desc","Descripción",220,"w"),
                ("qty","Cant.",60,"center"),("pu","P.Unit $",90,"e"),
                ("dc","Desc%",55,"center"),("sub","Subtotal $",100,"e")]
        tree = ttk.Treeview(wrap, columns=[c[0] for c in cols],
                            show="headings", style="V.Treeview", height=10)
        for cid, hd, w, anch in cols:
            tree.heading(cid, text=hd)
            tree.column(cid, width=w, anchor=anch, stretch=(cid=="desc"))
        tree.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)

        for d in det:
            tree.insert("", "end", values=(
                d["codigo"] or "—", d["descripcion"],
                f"{d['cantidad']:g}", f"$ {d['precio_unitario']:,.2f}",
                f"{d['descuento']:.0f}%", f"$ {d['subtotal']:,.2f}",
            ))

        # Totales
        tot_f = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        tot_f.pack(fill="x", padx=16, pady=(0, 12))
        for lbl, val in [
            ("Subtotal:", f"$ {v['subtotal']:,.2f}"),
            ("IVA:",      f"$ {v['impuesto']:,.2f}"),
            ("TOTAL:",    f"$ {v['total']:,.2f}"),
        ]:
            r = ctk.CTkFrame(tot_f, fg_color="transparent")
            r.pack(fill="x", padx=16, pady=2)
            ctk.CTkLabel(r, text=lbl, font=(FF, 11), text_color=GRIS_TX
                         ).pack(side="left")
            ctk.CTkLabel(r, text=val, font=(FF, 11, "bold"), text_color=NEGRO
                         ).pack(side="right")

        ctk.CTkButton(self, text="🖨  Exportar PDF",
                      fg_color=AZ_CLA, hover_color=AZ_OSC,
                      text_color=BLANCO, height=36, corner_radius=8,
                      font=(FF, 11, "bold"),
                      command=lambda: imprimir_factura(self._id, parent=self)
                      ).pack(pady=(0, 12))


# ══════════════════════════════════════════════════════════════════════════════
