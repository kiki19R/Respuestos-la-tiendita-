"""
modules/inventario/vista.py
Módulo de Inventario completo — ERP Repuestos La Tiendita
"""

import customtkinter as ctk
from tkinter import ttk, messagebox
import sqlite3, os
from datetime import datetime

# ── Ruta DB ──────────────────────────────────────────────────────────────────
from utils.paths import BASE_DIR, DB_PATH

# ── Paleta ───────────────────────────────────────────────────────────────────
AZ_OSCURO  = "#0D1B2A"
AZ_MEDIO   = "#1B3A5C"
AZ_CLARO   = "#2E6DA4"
AZ_ACENTO  = "#3D9EE8"
BLANCO     = "#FFFFFF"
GRIS_BG    = "#F4F6F9"
GRIS_BORDE = "#DDE3EA"
GRIS_TXT   = "#5A6478"
NEGRO      = "#1A1A2E"

VD         = "#1E8449"   # Verde texto Disponible
VD_BG      = "#EAFAF1"
AM         = "#B7770D"   # Amarillo texto Stock Bajo
AM_BG      = "#FEF9E7"
RJ         = "#C0392B"   # Rojo texto Agotado
RJ_BG      = "#FDEDEC"

FF = "Segoe UI"

# ── Helpers ──────────────────────────────────────────────────────────────────
def _conn():
    c = sqlite3.connect(DB_PATH)
    c.execute("PRAGMA foreign_keys = ON")
    c.row_factory = sqlite3.Row
    return c

def _estado(stock, minimo):
    if stock is None or stock <= 0:     return "Agotado"
    if stock <= (minimo or 0):          return "Stock Bajo"
    return "Disponible"

def _fl(v, d=0.0):
    try:    return float(str(v).replace(",",".").strip()) if str(v).strip() else d
    except: return d


# ══════════════════════════════════════════════════════════════════════════════
# FRAME PRINCIPAL
# ══════════════════════════════════════════════════════════════════════════════
class InventarioFrame(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="transparent")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        self._col_orden = "descripcion"
        self._asc       = True
        self._txt_q     = ""
        self._cat_q     = "Todas"

        self._hacer_encabezado()
        self._hacer_toolbar()
        self._hacer_tabla()
        self._hacer_pie()
        self.recargar()

    # ── Encabezado con badges ─────────────────────────────────────────────────
    def _hacer_encabezado(self):
        f = ctk.CTkFrame(self, fg_color="transparent")
        f.grid(row=0, column=0, sticky="ew", pady=(0,10))
        f.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(f, text="Inventario de Productos",
                     font=(FF,20,"bold"), text_color=AZ_OSCURO
                     ).grid(row=0, column=0, sticky="w")

        badges_frame = ctk.CTkFrame(f, fg_color="transparent")
        badges_frame.grid(row=0, column=2, sticky="e")

        self._bdg = {}
        specs = [
            ("total",      "Total",      AZ_OSCURO, BLANCO),
            ("disponible", "Disponible", VD,        BLANCO),
            ("stock_bajo", "Stock Bajo", AM,        BLANCO),
            ("agotado",    "Agotado",    RJ,        BLANCO),
        ]
        for key, lbl, bg, fg in specs:
            pill = ctk.CTkFrame(badges_frame, fg_color=bg, corner_radius=14)
            pill.pack(side="left", padx=4)
            num = ctk.CTkLabel(pill, text="—", font=(FF,13,"bold"),
                               text_color=fg, width=50)
            num.pack(padx=12, pady=(5,1))
            ctk.CTkLabel(pill, text=lbl, font=(FF,8),
                         text_color=fg).pack(padx=12, pady=(0,5))
            self._bdg[key] = num

    # ── Barra de herramientas ─────────────────────────────────────────────────
    def _hacer_toolbar(self):
        tb = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        tb.grid(row=1, column=0, sticky="ew", pady=(0,8))

        # Buscador
        ctk.CTkLabel(tb, text="🔍", font=(FF,14), text_color=GRIS_TXT
                     ).pack(side="left", padx=(14,4), pady=12)

        self._e_buscar = ctk.CTkEntry(
            tb, placeholder_text="Buscar por código o nombre...",
            width=290, height=36, corner_radius=8,
            border_color=GRIS_BORDE, border_width=1)
        self._e_buscar.pack(side="left", padx=(0,14), pady=12)
        self._e_buscar.bind("<KeyRelease>", self._on_buscar)

        # Separador visual
        ctk.CTkFrame(tb, width=1, height=32, fg_color=GRIS_BORDE
                     ).pack(side="left", pady=12)

        # Filtro categoría
        ctk.CTkLabel(tb, text="  Categoría:", font=(FF,11),
                     text_color=GRIS_TXT).pack(side="left", padx=(10,6))

        cats = ["Todas"] + self._get_categorias()
        self._cb_cat = ctk.CTkComboBox(
            tb, values=cats, width=185, height=36, corner_radius=8,
            border_color=GRIS_BORDE, fg_color=BLANCO,
            button_color=AZ_CLARO, dropdown_fg_color=BLANCO,
            command=self._on_cat)
        self._cb_cat.set("Todas")
        self._cb_cat.pack(side="left", padx=(0,14), pady=12)

        # Espaciador
        ctk.CTkLabel(tb, text="", width=1).pack(side="left", expand=True)

        # Botones
        btns = [
            ("➕  Agregar",  AZ_CLARO, self._agregar),
            ("✏️  Editar",   AZ_MEDIO, self._editar),
            ("🗑  Eliminar", "#C0392B", self._eliminar),
        ]
        for txt, bg, cmd in btns:
            ctk.CTkButton(
                tb, text=txt, fg_color=bg, hover_color=AZ_OSCURO,
                text_color=BLANCO, height=36, width=120,
                corner_radius=8, font=(FF,11,"bold"), command=cmd
            ).pack(side="left", padx=(0,8), pady=12)
        # margen derecho
        ctk.CTkLabel(tb, text="").pack(side="left", padx=4)

    # ── Tabla ─────────────────────────────────────────────────────────────────
    def _hacer_tabla(self):
        wrap = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=10)
        wrap.grid(row=2, column=0, sticky="nsew")
        wrap.grid_columnconfigure(0, weight=1)
        wrap.grid_rowconfigure(0, weight=1)

        # Estilos TTK
        s = ttk.Style()
        s.theme_use("clam")
        s.configure("I.Treeview",
                    background=BLANCO, fieldbackground=BLANCO,
                    rowheight=28, font=(FF,10), borderwidth=0)
        s.configure("I.Treeview.Heading",
                    background=AZ_OSCURO, foreground=BLANCO,
                    font=(FF,10,"bold"), relief="flat", padding=(6,7))
        s.map("I.Treeview",
              background=[("selected", AZ_ACENTO)],
              foreground=[("selected", BLANCO)])
        s.map("I.Treeview.Heading",
              background=[("active", AZ_MEDIO)])

        # Definición de columnas
        self._COL_DEF = [
            # (id,          header,         width, anchor, db_col)
            ("codigo",      "Código",          95, "center", "codigo"),
            ("descripcion", "Descripción",    230, "w",      "descripcion"),
            ("categoria",   "Categoría",      120, "center", "categoria"),
            ("marca",       "Marca",           90, "center", "marca"),
            ("stock",       "Stock",           60, "center", "stock_actual"),
            ("minimo",      "Mín.",            50, "center", None),
            ("costo",       "Costo $",         85, "e",      "costo_unitario"),
            ("precio",      "Precio $",        85, "e",      "precio_venta"),
            ("margen",      "Margen %",        72, "center", None),
            ("estado",      "Estado",         105, "center", None),
        ]
        ids = [c[0] for c in self._COL_DEF]

        self._tree = ttk.Treeview(
            wrap, columns=ids, show="headings",
            style="I.Treeview", selectmode="browse")

        for cid, hdr, w, anch, _ in self._COL_DEF:
            self._tree.heading(cid, text=hdr,
                               command=lambda c=cid: self._sort(c))
            self._tree.column(cid, width=w, anchor=anch,
                              stretch=(cid == "descripcion"), minwidth=40)

        # Tags de color
        self._tree.tag_configure("D1", background=VD_BG,  foreground=VD)
        self._tree.tag_configure("D2", background="#D5F5E3",foreground=VD)
        self._tree.tag_configure("S1", background=AM_BG,  foreground=AM)
        self._tree.tag_configure("S2", background="#FCF3CF",foreground=AM)
        self._tree.tag_configure("A1", background=RJ_BG,  foreground=RJ)
        self._tree.tag_configure("A2", background="#F5B7B1",foreground=RJ)

        vsb = ttk.Scrollbar(wrap, orient="vertical",   command=self._tree.yview)
        hsb = ttk.Scrollbar(wrap, orient="horizontal", command=self._tree.xview)
        self._tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self._tree.grid(row=0, column=0, sticky="nsew", padx=(12,0), pady=10)
        vsb.grid(row=0, column=1, sticky="ns", pady=10)
        hsb.grid(row=1, column=0, sticky="ew", padx=12, pady=(0,6))

        self._tree.bind("<Double-1>", lambda e: self._editar())

    # ── Pie ───────────────────────────────────────────────────────────────────
    def _hacer_pie(self):
        f = ctk.CTkFrame(self, fg_color="transparent")
        f.grid(row=3, column=0, sticky="ew", pady=(5,0))
        f.grid_columnconfigure(0, weight=1)

        self._lbl_pie = ctk.CTkLabel(f, text="", font=(FF,10), text_color=GRIS_TXT)
        self._lbl_pie.grid(row=0, column=0, sticky="w")

        ley = ctk.CTkFrame(f, fg_color="transparent")
        ley.grid(row=0, column=1, sticky="e")
        for color, txt in [(VD,"Disponible"),(AM,"Stock Bajo"),(RJ,"Agotado")]:
            pill = ctk.CTkFrame(ley, fg_color="transparent")
            pill.pack(side="left", padx=8)
            ctk.CTkFrame(pill, width=11, height=11,
                         fg_color=color, corner_radius=3).pack(side="left", padx=(0,4))
            ctk.CTkLabel(pill, text=txt, font=(FF,10),
                         text_color=GRIS_TXT).pack(side="left")

    # ── Datos ─────────────────────────────────────────────────────────────────
    def _get_categorias(self):
        try:
            c = _conn()
            r = c.execute("SELECT DISTINCT categoria FROM Inventario "
                          "WHERE categoria IS NOT NULL AND activo=1 "
                          "ORDER BY categoria").fetchall()
            c.close()
            return [x[0] for x in r]
        except: return []

    def recargar(self):
        for i in self._tree.get_children():
            self._tree.delete(i)

        q   = self._txt_q.lower()
        cat = self._cat_q

        col_map = {
            "codigo":"codigo","descripcion":"descripcion",
            "categoria":"categoria","marca":"marca",
            "stock":"stock_actual","costo":"costo_unitario","precio":"precio_venta"
        }
        db_col = col_map.get(self._col_orden, "descripcion")
        orden  = "ASC" if self._asc else "DESC"

        try:
            c  = _conn()
            rs = c.execute(f"""
                SELECT codigo, descripcion, categoria, marca,
                       stock_actual, stock_minimo,
                       costo_unitario, precio_venta
                FROM Inventario
                WHERE activo=1
                ORDER BY {db_col} {orden}
            """).fetchall()
            c.close()
        except Exception as e:
            messagebox.showerror("DB Error", str(e)); return

        cnt = {"Disponible":0, "Stock Bajo":0, "Agotado":0}
        n = 0
        for i, r in enumerate(rs):
            if q and q not in r["codigo"].lower() \
                 and q not in r["descripcion"].lower(): continue
            if cat != "Todas" and r["categoria"] != cat: continue

            stk  = r["stock_actual"]  or 0
            mn   = r["stock_minimo"]  or 0
            cos  = r["costo_unitario"] or 0
            pv   = r["precio_venta"]   or 0
            est  = _estado(stk, mn)
            mrg  = f"{(pv-cos)/pv*100:.0f}%" if pv>0 else "—"

            cnt[est] += 1
            n += 1
            pfx = est[0]                     # D / S / A
            tag = f"{pfx}{(i%2)+1}"          # D1/D2, S1/S2, A1/A2

            self._tree.insert("", "end", iid=f"{r['codigo']}_{i}",
                              values=(
                r["codigo"], r["descripcion"],
                r["categoria"] or "—", r["marca"] or "—",
                f"{stk:g}", f"{mn:g}",
                f"$ {cos:,.2f}", f"$ {pv:,.2f}",
                mrg, est,
            ), tags=(tag,))

        # Badges
        total = sum(cnt.values())
        self._bdg["total"].configure(text=str(total))
        self._bdg["disponible"].configure(text=str(cnt["Disponible"]))
        self._bdg["stock_bajo"].configure(text=str(cnt["Stock Bajo"]))
        self._bdg["agotado"].configure(text=str(cnt["Agotado"]))

        # Pie
        txt = f"  {n} producto{'s' if n!=1 else ''}"
        extras = []
        if q:   extras.append(f'"{self._txt_q}"')
        if cat != "Todas": extras.append(cat)
        if extras: txt += f"  ·  Filtro: {', '.join(extras)}"
        self._lbl_pie.configure(text=txt)

    # ── Eventos ───────────────────────────────────────────────────────────────
    def _on_buscar(self, _=None):
        self._txt_q = self._e_buscar.get().strip()
        self.recargar()

    def _on_cat(self, v):
        self._cat_q = v
        self.recargar()

    def _sort(self, cid):
        if self._col_orden == cid:
            self._asc = not self._asc
        else:
            self._col_orden = cid
            self._asc = True
        col_map = {c[0]:c[1] for c in self._COL_DEF}
        for c in self._COL_DEF:
            flecha = (" ▲" if self._asc else " ▼") if c[0]==cid else ""
            self._tree.heading(c[0], text=col_map[c[0]]+flecha)
        self.recargar()

    def _sel_codigo(self):
        sel = self._tree.selection()
        if not sel: return None
        return self._tree.item(sel[0])["values"][0]   # columna 0 = código

    # ── Acciones ──────────────────────────────────────────────────────────────
    def _agregar(self):
        FormProducto(self, modo="nuevo", callback=self.recargar)

    def _editar(self):
        cod = self._sel_codigo()
        if not cod:
            messagebox.showwarning("Sin selección",
                "Haga clic en un producto de la tabla para editarlo.")
            return
        FormProducto(self, modo="editar", codigo=str(cod), callback=self.recargar)

    def _eliminar(self):
        cod = self._sel_codigo()
        if not cod:
            messagebox.showwarning("Sin selección",
                "Haga clic en un producto de la tabla para eliminarlo.")
            return
        vals = self._tree.item(self._tree.selection()[0])["values"]
        desc = vals[1]
        if not messagebox.askyesno("Confirmar",
            f"¿Desactivar este producto?\n\n[{cod}]  {desc}\n\n"
            f"Quedará inactivo pero no se borrará de la base de datos."):
            return
        try:
            c = _conn()
            c.execute("UPDATE Inventario SET activo=0 WHERE codigo=?", (str(cod),))
            c.commit(); c.close()
            self.recargar()
        except Exception as e:
            messagebox.showerror("Error", str(e))


# ══════════════════════════════════════════════════════════════════════════════
# FORMULARIO AGREGAR / EDITAR
# ══════════════════════════════════════════════════════════════════════════════
class FormProducto(ctk.CTkToplevel):

    CATS = ["Eléctrico","Encendido","Filtros","Frenos","Iluminación",
            "Lubricantes","Motor","Repuestos","Retenes y Juntas","Rodamiento","Otro"]

    def __init__(self, parent, modo="nuevo", codigo=None, callback=None):
        super().__init__(parent)
        self._modo    = modo
        self._codigo  = codigo
        self._cb      = callback

        self.title("Agregar Producto" if modo=="nuevo" else "Editar Producto")
        self.geometry("640x660")
        self.resizable(False, False)
        self.configure(fg_color=GRIS_BG)
        self.grab_set(); self.lift(); self.focus()

        self._build()
        if modo == "editar" and codigo:
            self._load()

    # ── Layout ────────────────────────────────────────────────────────────────
    def _build(self):
        # Header
        hdr = ctk.CTkFrame(self, fg_color=AZ_OSCURO, corner_radius=0)
        hdr.pack(fill="x")
        icon = "📦  Agregar Producto" if self._modo=="nuevo" else "✏️  Editar Producto"
        ctk.CTkLabel(hdr, text=icon, font=(FF,15,"bold"),
                     text_color=BLANCO).pack(padx=20, pady=14, anchor="w")

        # Scroll body
        body = ctk.CTkScrollableFrame(self, fg_color=GRIS_BG, corner_radius=0)
        body.pack(fill="both", expand=True)
        body.grid_columnconfigure((0,1), weight=1)

        self._E = {}    # entries dict

        # ── Sección Identificación ──
        self._sep(body, "🔖  Identificación", 0)
        self._fld(body, "Código *",      "codigo",      1, 0)
        self._fld(body, "Descripción *", "descripcion", 1, 1)

        # ── Sección Clasificación ──
        self._sep(body, "🏷️  Clasificación", 3)
        # Categoría = ComboBox
        ctk.CTkLabel(body, text="Categoría", font=(FF,10),
                     text_color=GRIS_TXT).grid(row=4, column=0,
                     padx=(16,8), pady=(0,2), sticky="w")
        self._cb_cat = ctk.CTkComboBox(body, values=self.CATS,
            width=220, height=34, corner_radius=7,
            border_color=GRIS_BORDE, fg_color=BLANCO, button_color=AZ_CLARO)
        self._cb_cat.set("Repuestos")
        self._cb_cat.grid(row=5, column=0, padx=(16,8), pady=(0,10), sticky="ew")

        self._fld(body, "Marca",             "marca",   4, 1)
        self._fld(body, "Modelo compatible", "modelo",  6, 0)
        self._fld(body, "Unidad de medida",  "unidad",  6, 1, ph="PZA")

        # ── Sección Precios ──
        self._sep(body, "💵  Precios", 8)
        self._fld(body, "Costo unitario $",  "costo",  9, 0)
        self._fld(body, "Precio de venta $", "precio", 9, 1)
        self._fld(body, "Precio mayorista $","precio_may", 11, 0)

        # Margen calculado
        self._lbl_mrg = ctk.CTkLabel(body, text="Margen: —",
            font=(FF,12,"bold"), text_color=GRIS_TXT)
        self._lbl_mrg.grid(row=11, column=1, padx=16, sticky="w", pady=(22,0))
        self._E["costo"].bind("<KeyRelease>",  self._upd_margen)
        self._E["precio"].bind("<KeyRelease>", self._upd_margen)

        # ── Sección Stock ──
        self._sep(body, "📦  Stock y ubicación", 13)
        self._fld(body, "Stock actual",  "stock",     14, 0)
        self._fld(body, "Stock mínimo",  "stock_min", 14, 1)
        self._fld(body, "Stock máximo",  "stock_max", 16, 0)
        self._fld(body, "Ubicación",     "ubicacion", 16, 1, ph="Ej: Estante A-3")

        # ── Notas ──
        self._sep(body, "📝  Notas", 18)
        self._txt = ctk.CTkTextbox(body, height=65, corner_radius=7,
            border_color=GRIS_BORDE, border_width=1, fg_color=BLANCO)
        self._txt.grid(row=19, column=0, columnspan=2,
                       padx=16, pady=(0,12), sticky="ew")

        # ── Botones ──
        bf = ctk.CTkFrame(self, fg_color=BLANCO, corner_radius=0)
        bf.pack(fill="x", side="bottom")
        ctk.CTkButton(bf, text="Cancelar",
            fg_color=GRIS_BORDE, text_color=NEGRO, hover_color="#C8CDD5",
            height=38, width=120, corner_radius=8,
            command=self.destroy).pack(side="right", padx=(8,16), pady=12)
        ctk.CTkButton(bf, text="💾  Guardar",
            fg_color=AZ_CLARO, hover_color=AZ_OSCURO,
            text_color=BLANCO, height=38, width=150,
            corner_radius=8, font=(FF,12,"bold"),
            command=self._guardar).pack(side="right", pady=12)

    def _sep(self, p, txt, row):
        f = ctk.CTkFrame(p, fg_color="transparent")
        f.grid(row=row, column=0, columnspan=2,
               padx=16, pady=(14,3), sticky="ew")
        f.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(f, text=txt, font=(FF,11,"bold"),
                     text_color=AZ_OSCURO).grid(row=0, column=0, sticky="w")
        ctk.CTkFrame(f, height=1, fg_color=GRIS_BORDE).grid(
            row=0, column=1, sticky="ew", padx=(10,0))

    def _fld(self, p, lbl, key, row, col, ph=""):
        ctk.CTkLabel(p, text=lbl, font=(FF,10), text_color=GRIS_TXT
                     ).grid(row=row, column=col, padx=(16,8), pady=(0,2), sticky="w")
        e = ctk.CTkEntry(p, height=34, corner_radius=7,
                         border_color=GRIS_BORDE, border_width=1,
                         fg_color=BLANCO, placeholder_text=ph)
        e.grid(row=row+1, column=col, padx=(16,8), pady=(0,8), sticky="ew")
        self._E[key] = e

    # ── Carga para edición ────────────────────────────────────────────────────
    def _load(self):
        try:
            c = _conn()
            p = c.execute("SELECT * FROM Inventario WHERE codigo=?",
                          (self._codigo,)).fetchone()
            c.close()
        except Exception as e:
            messagebox.showerror("Error", str(e)); return
        if not p: return

        def _put(k, v):
            if k in self._E and v is not None:
                self._E[k].delete(0,"end")
                self._E[k].insert(0, str(v))

        _put("codigo",      p["codigo"])
        _put("descripcion", p["descripcion"])
        _put("marca",       p["marca"])
        _put("modelo",      p["modelo_compatible"])
        _put("unidad",      p["unidad_medida"])
        _put("costo",       p["costo_unitario"])
        _put("precio",      p["precio_venta"])
        _put("precio_may",  p["precio_mayor"])
        _put("stock",       p["stock_actual"])
        _put("stock_min",   p["stock_minimo"])
        _put("stock_max",   p["stock_maximo"])
        _put("ubicacion",   p["ubicacion"])

        if p["categoria"]: self._cb_cat.set(p["categoria"])
        if p["notas"]:     self._txt.insert("1.0", p["notas"])

        # Código no editable en modo edición
        self._E["codigo"].configure(state="disabled", fg_color=GRIS_BG)
        self._upd_margen()

    # ── Margen live ───────────────────────────────────────────────────────────
    def _upd_margen(self, _=None):
        cos = _fl(self._E["costo"].get())
        pv  = _fl(self._E["precio"].get())
        if pv > 0:
            m = (pv - cos) / pv * 100
            col = VD if m >= 20 else (AM if m >= 5 else RJ)
            self._lbl_mrg.configure(text=f"Margen: {m:.1f}%", text_color=col)
        else:
            self._lbl_mrg.configure(text="Margen: —", text_color=GRIS_TXT)

    # ── Guardar ───────────────────────────────────────────────────────────────
    def _guardar(self):
        cod  = self._E["codigo"].get().strip()
        desc = self._E["descripcion"].get().strip()

        if not cod:
            self._err("codigo", "El código es obligatorio"); return
        if not desc:
            self._err("descripcion", "La descripción es obligatoria"); return

        d = {
            "codigo":      cod,
            "descripcion": desc,
            "categoria":   self._cb_cat.get(),
            "marca":       self._E["marca"].get().strip(),
            "modelo":      self._E["modelo"].get().strip(),
            "unidad":      self._E["unidad"].get().strip() or "PZA",
            "costo":       _fl(self._E["costo"].get()),
            "precio":      _fl(self._E["precio"].get()),
            "precio_may":  _fl(self._E["precio_may"].get()),
            "stock":       _fl(self._E["stock"].get()),
            "stk_min":     _fl(self._E["stock_min"].get(), 1.0),
            "stk_max":     _fl(self._E["stock_max"].get(), 100.0),
            "ubicacion":   self._E["ubicacion"].get().strip(),
            "notas":       self._txt.get("1.0","end").strip(),
            "fecha":       datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }

        try:
            c = _conn()
            if self._modo == "nuevo":
                if c.execute("SELECT 1 FROM Inventario WHERE codigo=?",
                             (cod,)).fetchone():
                    c.close()
                    self._err("codigo", f"Ya existe un producto con código '{cod}'")
                    return
                c.execute("""
                    INSERT INTO Inventario
                        (codigo,descripcion,categoria,marca,modelo_compatible,
                         unidad_medida,costo_unitario,precio_venta,precio_mayor,
                         stock_actual,stock_minimo,stock_maximo,
                         ubicacion,notas,fecha_actualizacion)
                    VALUES
                        (:codigo,:descripcion,:categoria,:marca,:modelo,
                         :unidad,:costo,:precio,:precio_may,
                         :stock,:stk_min,:stk_max,
                         :ubicacion,:notas,:fecha)
                """, d)
                msg = f"Producto '{desc}' agregado correctamente."
            else:
                d["cod_orig"] = self._codigo
                c.execute("""
                    UPDATE Inventario SET
                        descripcion=:descripcion, categoria=:categoria,
                        marca=:marca, modelo_compatible=:modelo,
                        unidad_medida=:unidad, costo_unitario=:costo,
                        precio_venta=:precio, precio_mayor=:precio_may,
                        stock_actual=:stock, stock_minimo=:stk_min,
                        stock_maximo=:stk_max, ubicacion=:ubicacion,
                        notas=:notas, fecha_actualizacion=:fecha
                    WHERE codigo=:cod_orig
                """, d)
                msg = f"Producto '{desc}' actualizado."
            c.commit(); c.close()
        except sqlite3.Error as e:
            messagebox.showerror("Error al guardar", str(e)); return

        messagebox.showinfo("✅ Guardado", msg)
        if self._cb: self._cb()
        self.destroy()

    def _err(self, key, msg):
        if key in self._E:
            self._E[key].configure(border_color=RJ)
            self._E[key].focus()
            self._E[key].after(2500,
                lambda: self._E[key].configure(border_color=GRIS_BORDE))
        messagebox.showerror("Campo requerido", msg)
