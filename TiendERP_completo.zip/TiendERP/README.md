# 🔧 ERP Repuestos La Tiendita

Sistema de gestión empresarial (ERP) de escritorio para negocio de repuestos automotrices.
Desarrollado con **Python + CustomTkinter + SQLite**.

---

## 📋 Módulos incluidos

| Módulo          | Descripción                                      |
|-----------------|--------------------------------------------------|
| 🏠 Dashboard     | KPIs del día, alertas de stock, últimas ventas   |
| 📦 Inventario    | Gestión de productos, stock, precios             |
| 🧾 Ventas        | Registro de ventas, facturas, detalle por ítem   |
| 🛒 Compras       | Órdenes de compra, recepción de mercancía        |
| 👥 Clientes      | Ficha de clientes, tipo, límite de crédito       |
| 🏭 Proveedores   | Registro de proveedores y condiciones            |
| 📋 Cotizaciones  | Creación y conversión de cotizaciones a ventas   |
| 💰 CxC           | Cuentas por cobrar, pagos y vencimientos         |
| 💳 CxP           | Cuentas por pagar a proveedores                  |
| 📊 Reportes      | Ventas por período, inventario, ganancias        |

---

## 🚀 Instalación y uso

### 1. Requisitos previos
- Python 3.10 o superior
- pip actualizado

### 2. Instalar dependencias
```bash
pip install -r requirements.txt
```

### 3. Ejecutar el sistema
```bash
python main.py
```

La base de datos `tiendita_erp.db` se crea automáticamente en la primera ejecución
con datos de ejemplo listos para probar.

### Credenciales iniciales
- **Usuario:** `admin`
- **Contraseña:** `admin123`

---

## 🗂️ Estructura del proyecto

```
repuestos_la_tiendita/
│
├── main.py                     ← Punto de entrada
├── requirements.txt
├── tiendita_erp.db             ← Base de datos SQLite (se crea automáticamente)
│
├── core/
│   ├── database.py             ← Conexión SQLite, tablas, datos iniciales
│   ├── main_window.py          ← Ventana principal + sidebar de navegación
│   └── theme.py                ← Colores, fuentes y constantes visuales
│
├── modules/
│   ├── dashboard.py            ← Panel de control
│   ├── inventario/
│   │   └── vista.py            ← Lista, búsqueda y formulario de productos
│   ├── ventas/
│   │   └── vista.py            ← Módulo de ventas (próximamente)
│   ├── compras/
│   │   └── vista.py            ← Módulo de compras (próximamente)
│   ├── clientes/
│   │   └── vista.py            ← Gestión de clientes
│   ├── proveedores/
│   │   └── vista.py            ← Gestión de proveedores (próximamente)
│   ├── cotizaciones/
│   │   └── vista.py            ← Cotizaciones (próximamente)
│   ├── cxc/
│   │   └── vista.py            ← Cuentas por cobrar (próximamente)
│   └── cxp/
│       └── vista.py            ← Cuentas por pagar (próximamente)
│
├── assets/                     ← Íconos, logos, imágenes
├── reports/                    ← PDFs y reportes generados
└── utils/                      ← Funciones auxiliares compartidas
```

---

## 🗄️ Tablas de la base de datos

| Tabla                | Descripción                               |
|----------------------|-------------------------------------------|
| `Inventario`         | Productos y repuestos con stock           |
| `Ventas`             | Cabecera de facturas de venta             |
| `VentaDetalle`       | Líneas de cada factura de venta           |
| `Compras`            | Órdenes de compra a proveedores           |
| `CompraDetalle`      | Líneas de cada orden de compra            |
| `Clientes`           | Ficha de clientes                         |
| `Proveedores`        | Ficha de proveedores                      |
| `Cotizaciones`       | Cotizaciones enviadas a clientes          |
| `CotizacionDetalle`  | Líneas de cada cotización                 |
| `CuentasPorCobrar`   | CxC generadas desde ventas a crédito      |
| `PagosCxC`           | Registro de abonos a CxC                 |
| `CuentasPorPagar`    | CxP generadas desde compras a crédito     |
| `PagosCxP`           | Registro de pagos a proveedores           |
| `Configuracion`      | Parámetros del sistema (empresa, IVA...)  |
| `Usuarios`           | Usuarios y roles del sistema              |

---

## 🎨 Tema visual
- **Sidebar:** Azul marino `#0D1B2A`
- **Botones principales:** Azul `#2E6DA4`
- **Fondo de contenido:** Gris claro `#F4F6F9`
- **Alertas:** Verde / Amarillo / Rojo según estado

---

## 🔜 Próximas iteraciones
- [ ] Módulo completo de Ventas con detalle y factura PDF
- [ ] Módulo de Compras con actualización automática de stock
- [ ] Módulo de Cotizaciones con conversión a Venta
- [ ] CxC y CxP con registro de pagos parciales
- [ ] Reportes en PDF y Excel
- [ ] Login con roles y permisos
- [ ] Configuración de empresa e IVA desde la UI
