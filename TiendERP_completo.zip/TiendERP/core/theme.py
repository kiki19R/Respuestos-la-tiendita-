"""
core/theme.py
Paleta de colores y constantes visuales del ERP Repuestos La Tiendita
Tema: Azul Marino y Blanco
"""

# ─────────────────────────────────────────────────────────────
# PALETA PRINCIPAL
# ─────────────────────────────────────────────────────────────
AZUL_MARINO       = "#0D1B2A"   # Fondo del sidebar y cabeceras
AZUL_MEDIO        = "#1B3A5C"   # Hover de botones del sidebar
AZUL_CLARO        = "#2E6DA4"   # Botones de acción principales
AZUL_ACENTO       = "#3D9EE8"   # Resaltados y bordes activos
BLANCO            = "#FFFFFF"
GRIS_CLARO        = "#F4F6F9"   # Fondo del contenido principal
GRIS_MEDIO        = "#DDE3EA"   # Bordes y separadores
GRIS_TEXTO        = "#5A6478"   # Texto secundario
NEGRO_TEXTO       = "#1A1A2E"   # Texto principal

# Estados / Semáforos
VERDE_EXITO       = "#27AE60"
AMARILLO_ALERTA   = "#F39C12"
ROJO_ERROR        = "#E74C3C"
AZUL_INFO         = "#2980B9"

# ─────────────────────────────────────────────────────────────
# TIPOGRAFÍA
# ─────────────────────────────────────────────────────────────
FUENTE_FAMILIA    = "Segoe UI"  # Windows; en Linux usa "DejaVu Sans"
FUENTE_TITULO     = (FUENTE_FAMILIA, 20, "bold")
FUENTE_SUBTITULO  = (FUENTE_FAMILIA, 14, "bold")
FUENTE_NORMAL     = (FUENTE_FAMILIA, 11)
FUENTE_PEQUEÑA    = (FUENTE_FAMILIA, 9)
FUENTE_BOTON      = (FUENTE_FAMILIA, 11, "bold")
FUENTE_SIDEBAR    = (FUENTE_FAMILIA, 12)
FUENTE_SIDEBAR_AK = (FUENTE_FAMILIA, 12, "bold")  # Ítem activo

# ─────────────────────────────────────────────────────────────
# DIMENSIONES
# ─────────────────────────────────────────────────────────────
ANCHO_SIDEBAR     = 220
ALTO_TOPBAR       = 55
RADIO_BOTON       = 8
PADDING_FRAME     = 20
ALTO_FILA_TABLA   = 30

# Ventana principal
VENTANA_ANCHO     = 1280
VENTANA_ALTO      = 780
VENTANA_MIN_ANCHO = 1024
VENTANA_MIN_ALTO  = 600

# ─────────────────────────────────────────────────────────────
# ICONOS (emojis Unicode como fallback)
# ─────────────────────────────────────────────────────────────
ICONOS = {
    "dashboard":    "🏠",
    "inventario":   "📦",
    "ventas":       "🧾",
    "compras":      "🛒",
    "clientes":     "👥",
    "proveedores":  "🏭",
    "cotizaciones": "📋",
    "cxc":          "💰",
    "cxp":          "💳",
    "reportes":     "📊",
    "config":       "⚙️",
    "salir":        "🚪",
    "nuevo":        "➕",
    "editar":       "✏️",
    "eliminar":     "🗑️",
    "buscar":       "🔍",
    "guardar":      "💾",
    "imprimir":     "🖨️",
    "exportar":     "📤",
    "alerta":       "⚠️",
    "ok":           "✅",
    "error":        "❌",
}

# ─────────────────────────────────────────────────────────────
# CONFIGURACIÓN DE CUSTOMTKINTER
# ─────────────────────────────────────────────────────────────
CTK_THEME = {
    "CTk": {
        "fg_color": [GRIS_CLARO, NEGRO_TEXTO]
    },
    "CTkButton": {
        "fg_color":          [AZUL_CLARO, AZUL_CLARO],
        "hover_color":       [AZUL_MEDIO, AZUL_MEDIO],
        "text_color":        [BLANCO, BLANCO],
        "border_width":      0,
        "corner_radius":     RADIO_BOTON,
    },
    "CTkEntry": {
        "fg_color":          [BLANCO, "#2b2b2b"],
        "border_color":      [GRIS_MEDIO, "#555"],
        "border_width":      1,
        "corner_radius":     6,
    },
    "CTkFrame": {
        "fg_color":          [BLANCO, "#1e1e1e"],
        "border_color":      [GRIS_MEDIO, "#333"],
        "corner_radius":     10,
    },
}
