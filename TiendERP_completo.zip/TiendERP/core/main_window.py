"""
core/main_window.py
Ventana principal del ERP Repuestos La Tiendita
Sidebar de navegación + área de contenido dinámico
"""

import customtkinter as ctk
from PIL import Image
from core.theme import *
from core.database import obtener_config
from utils.paths import BASE_DIR
import os
ASSETS_DIR = os.path.join(BASE_DIR, "assets")


class MainWindow(ctk.CTk):
    """
    Ventana principal del ERP.
    Estructura: Sidebar fijo | Área de contenido dinámica
    """

    def __init__(self):
        super().__init__()
        self._configurar_ventana()
        self._crear_layout()
        self._crear_sidebar()
        self._crear_topbar()
        self._crear_area_contenido()
        self._cargar_modulo("dashboard")

    # ─────────────────────────────────────────────
    # SETUP INICIAL
    # ─────────────────────────────────────────────
    def _configurar_ventana(self):
        nombre = obtener_config("empresa_nombre", "Repuestos La Tiendita")
        self.title(f"ERP — {nombre}")
        self.geometry(f"{VENTANA_ANCHO}x{VENTANA_ALTO}")
        self.minsize(VENTANA_MIN_ANCHO, VENTANA_MIN_ALTO)
        _ico = os.path.join(ASSETS_DIR, "icon.ico")
        if os.path.exists(_ico):
            try: self.iconbitmap(_ico)
            except Exception: pass

        # Modo claro forzado (tema azul marino)
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")

        # Centrar en pantalla
        self.update_idletasks()
        x = (self.winfo_screenwidth() - VENTANA_ANCHO) // 2
        y = (self.winfo_screenheight() - VENTANA_ALTO) // 2
        self.geometry(f"{VENTANA_ANCHO}x{VENTANA_ALTO}+{x}+{y}")

        self.configure(fg_color=GRIS_CLARO)

    # ─────────────────────────────────────────────
    # LAYOUT PRINCIPAL
    # ─────────────────────────────────────────────
    def _crear_layout(self):
        """Grid de 2 columnas: sidebar fijo + contenido expandible."""
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

    # ─────────────────────────────────────────────
    # SIDEBAR
    # ─────────────────────────────────────────────
    def _crear_sidebar(self):
        self.sidebar = ctk.CTkFrame(
            self, width=ANCHO_SIDEBAR,
            fg_color=AZUL_MARINO,
            corner_radius=0
        )
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)
        self.sidebar.grid_rowconfigure(20, weight=1)  # Empuja el botón Salir al fondo

        # ── Logo / Nombre de empresa ──
        logo_frame = ctk.CTkFrame(self.sidebar, fg_color=AZUL_MARINO, corner_radius=0)
        logo_frame.grid(row=0, column=0, padx=0, pady=0, sticky="ew")

        ctk.CTkLabel(
            logo_frame,
            text="",   # logo manejado abajo
        ).pack()   # label vacío
        _lp = os.path.join(ASSETS_DIR, "logo_sidebar.png")
        if os.path.exists(_lp):
            _pi = Image.open(_lp)
            _ci = ctk.CTkImage(light_image=_pi, size=(80, 75))
            ctk.CTkLabel(logo_frame, image=_ci, text="",
                         bg_color="transparent").pack(pady=(14, 4))
        else:
            ctk.CTkLabel(logo_frame, text="🔧",
                         font=("Segoe UI", 36),
                         text_color=AZUL_ACENTO).pack(pady=(20, 2))
        ctk.CTkLabel(
            logo_frame,
            text="Sistema ERP",
            font=(FUENTE_FAMILIA, 9),
            text_color=GRIS_MEDIO
        ).pack(pady=(0, 15))

        # ── Separador ──
        ctk.CTkFrame(self.sidebar, height=1, fg_color=AZUL_MEDIO).grid(
            row=1, column=0, sticky="ew", padx=15, pady=0
        )

        # ── Ítems del menú ──
        self._modulo_activo = None
        self._botones_sidebar = {}

        menu_items = [
            ("dashboard",    "🏠  Dashboard"),
            ("inventario",   "📦  Inventario"),
            ("ventas",       "🧾  Ventas"),
            ("compras",      "🛒  Compras"),
            ("clientes",     "👥  Clientes"),
            ("proveedores",  "🏭  Proveedores"),
            ("cotizaciones", "📋  Cotizaciones"),
            ("cxc",          "💰  Cuentas x Cobrar"),
            ("cxp",          "💳  Cuentas x Pagar"),
            ("reportes",     "📊  Reportes"),
        ]

        for i, (modulo, etiqueta) in enumerate(menu_items, start=2):
            btn = ctk.CTkButton(
                self.sidebar,
                text=etiqueta,
                anchor="w",
                width=ANCHO_SIDEBAR - 20,
                height=38,
                fg_color="transparent",
                hover_color=AZUL_MEDIO,
                text_color=GRIS_CLARO,
                font=FUENTE_SIDEBAR,
                corner_radius=6,
                command=lambda m=modulo: self._cargar_modulo(m)
            )
            btn.grid(row=i, column=0, padx=10, pady=2, sticky="ew")
            self._botones_sidebar[modulo] = btn

        # ── Separador inferior ──
        ctk.CTkFrame(self.sidebar, height=1, fg_color=AZUL_MEDIO).grid(
            row=21, column=0, sticky="ew", padx=15, pady=5
        )

        # ── Configuración y Salir ──
        ctk.CTkButton(
            self.sidebar,
            text="⚙️  Configuración",
            anchor="w",
            width=ANCHO_SIDEBAR - 20,
            height=35,
            fg_color="transparent",
            hover_color=AZUL_MEDIO,
            text_color=GRIS_MEDIO,
            font=(FUENTE_FAMILIA, 10),
            corner_radius=6,
            command=lambda: self._cargar_modulo("config")
        ).grid(row=22, column=0, padx=10, pady=2, sticky="ew")

        ctk.CTkButton(
            self.sidebar,
            text="🚪  Cerrar Sesión",
            anchor="w",
            width=ANCHO_SIDEBAR - 20,
            height=35,
            fg_color="transparent",
            hover_color="#4a1010",
            text_color=GRIS_MEDIO,
            font=(FUENTE_FAMILIA, 10),
            corner_radius=6,
            command=self._cerrar_sesion
        ).grid(row=23, column=0, padx=10, pady=(2, 15), sticky="ew")

    # ─────────────────────────────────────────────
    # TOPBAR
    # ─────────────────────────────────────────────
    def _crear_topbar(self):
        self.topbar = ctk.CTkFrame(
            self, height=ALTO_TOPBAR,
            fg_color=BLANCO,
            corner_radius=0
        )
        self.topbar.grid(row=0, column=1, sticky="new")
        self.topbar.grid_propagate(False)
        self.topbar.grid_columnconfigure(1, weight=1)

        # Título del módulo activo
        self.lbl_modulo = ctk.CTkLabel(
            self.topbar,
            text="Dashboard",
            font=FUENTE_SUBTITULO,
            text_color=NEGRO_TEXTO
        )
        self.lbl_modulo.grid(row=0, column=0, padx=20, pady=0, sticky="w")

        # Usuario activo (lado derecho)
        self.lbl_usuario = ctk.CTkLabel(
            self.topbar,
            text="👤 Administrador",
            font=FUENTE_PEQUEÑA,
            text_color=GRIS_TEXTO
        )
        self.lbl_usuario.grid(row=0, column=2, padx=20, pady=0, sticky="e")

        # Línea inferior del topbar
        ctk.CTkFrame(self.topbar, height=1, fg_color=GRIS_MEDIO).grid(
            row=1, column=0, columnspan=3, sticky="ew"
        )

    # ─────────────────────────────────────────────
    # ÁREA DE CONTENIDO
    # ─────────────────────────────────────────────
    def _crear_area_contenido(self):
        self.contenido = ctk.CTkFrame(
            self,
            fg_color=GRIS_CLARO,
            corner_radius=0
        )
        self.contenido.grid(row=0, column=1, sticky="nsew", pady=(ALTO_TOPBAR, 0))
        self.contenido.grid_columnconfigure(0, weight=1)
        self.contenido.grid_rowconfigure(0, weight=1)

        self._frame_actual = None

    # ─────────────────────────────────────────────
    # NAVEGACIÓN
    # ─────────────────────────────────────────────
    def _cargar_modulo(self, modulo: str):
        """Carga dinámicamente el módulo seleccionado en el área de contenido."""
        if modulo == self._modulo_activo:
            return

        # Resaltar botón activo en sidebar
        for nombre, btn in self._botones_sidebar.items():
            if nombre == modulo:
                btn.configure(fg_color=AZUL_CLARO, text_color=BLANCO,
                              font=FUENTE_SIDEBAR_AK)
            else:
                btn.configure(fg_color="transparent", text_color=GRIS_CLARO,
                              font=FUENTE_SIDEBAR)

        # Destruir frame anterior
        if self._frame_actual:
            self._frame_actual.destroy()

        # Actualizar título en topbar
        titulos = {
            "dashboard":    "🏠  Dashboard",
            "inventario":   "📦  Inventario",
            "ventas":       "🧾  Ventas",
            "compras":      "🛒  Compras",
            "clientes":     "👥  Clientes",
            "proveedores":  "🏭  Proveedores",
            "cotizaciones": "📋  Cotizaciones",
            "cxc":          "💰  Cuentas por Cobrar",
            "cxp":          "💳  Cuentas por Pagar",
            "reportes":     "📊  Reportes",
            "config":       "⚙️  Configuración",
        }
        self.lbl_modulo.configure(text=titulos.get(modulo, modulo.title()))
        self._modulo_activo = modulo

        # Importar y cargar el módulo correspondiente
        try:
            frame = self._importar_modulo(modulo)
        except Exception as e:
            frame = self._frame_placeholder(modulo, str(e))

        self._frame_actual = frame
        self._frame_actual.grid(row=0, column=0, sticky="nsew", padx=15, pady=15)

    def _importar_modulo(self, modulo: str):
        """Importa dinámicamente la clase del módulo solicitado."""
        importaciones = {
            "dashboard":    ("modules.dashboard",    "DashboardFrame"),
            "inventario":   ("modules.inventario.vista", "InventarioFrame"),
            "ventas":       ("modules.ventas.vista",     "VentasFrame"),
            "compras":      ("modules.compras.vista",    "ComprasFrame"),
            "clientes":     ("modules.clientes.vista",   "ClientesFrame"),
            "proveedores":  ("modules.proveedores.vista","ProveedoresFrame"),
            "cotizaciones": ("modules.cotizaciones.vista","CotizacionesFrame"),
            "cxc":          ("modules.cxc.vista",        "CxCFrame"),
            "cxp":          ("modules.cxp.vista",        "CxPFrame"),
            "reportes":     ("modules.reportes",         "ReportesFrame"),
            "config":       ("modules.configuracion",    "ConfiguracionFrame"),
        }

        if modulo not in importaciones:
            return self._frame_placeholder(modulo, "Módulo no encontrado")

        modulo_path, clase_nombre = importaciones[modulo]
        import importlib
        mod = importlib.import_module(modulo_path)
        clase = getattr(mod, clase_nombre)
        return clase(self.contenido)

    def _frame_placeholder(self, modulo: str, mensaje: str = ""):
        """Frame temporal mientras el módulo está en construcción."""
        frame = ctk.CTkFrame(self.contenido, fg_color=BLANCO, corner_radius=10)
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_rowconfigure(0, weight=1)

        inner = ctk.CTkFrame(frame, fg_color="transparent")
        inner.grid(row=0, column=0)

        ctk.CTkLabel(inner, text="🚧", font=("Segoe UI", 64)).pack(pady=(30, 5))
        ctk.CTkLabel(
            inner,
            text=f"Módulo: {modulo.title()}",
            font=FUENTE_TITULO,
            text_color=AZUL_MARINO
        ).pack()
        ctk.CTkLabel(
            inner,
            text="En construcción" if not mensaje else mensaje,
            font=FUENTE_NORMAL,
            text_color=GRIS_TEXTO
        ).pack(pady=5)
        return frame

    # ─────────────────────────────────────────────
    # ACCIONES
    # ─────────────────────────────────────────────
    def _cerrar_sesion(self):
        respuesta = ctk.CTkInputDialog(
            text="¿Desea cerrar sesión? (Escriba 'si' para confirmar)",
            title="Cerrar Sesión"
        ).get_input()
        if respuesta and respuesta.strip().lower() in ("si", "sí"):
            self.destroy()

    def actualizar_usuario(self, nombre: str):
        """Actualiza el nombre del usuario mostrado en el topbar."""
        self.lbl_usuario.configure(text=f"👤 {nombre}")
