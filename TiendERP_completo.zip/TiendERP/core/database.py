"""
core/database.py
Módulo central de base de datos para ERP Repuestos La Tiendita
Gestiona la conexión SQLite y la creación de todas las tablas del sistema.
"""

import sqlite3
import os
from datetime import datetime

# Ruta de la base de datos (en la raíz del proyecto)
from utils.paths import BASE_DIR, DB_PATH


def get_connection() -> sqlite3.Connection:
    """Retorna una conexión activa a la base de datos con soporte de claves foráneas."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row  # Acceso por nombre de columna
    return conn


def inicializar_base_de_datos():
    """Crea todas las tablas si no existen. Seguro ejecutar múltiples veces."""
    conn = get_connection()
    cursor = conn.cursor()

    # ─────────────────────────────────────────────
    # CLIENTES
    # ─────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Clientes (
            id_cliente      INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre          TEXT    NOT NULL,
            rif_cedula      TEXT    UNIQUE,
            telefono        TEXT,
            email           TEXT,
            direccion       TEXT,
            tipo_cliente    TEXT    DEFAULT 'Regular',   -- Regular / Mayorista / VIP
            limite_credito  REAL    DEFAULT 0.0,
            saldo_pendiente REAL    DEFAULT 0.0,
            activo          INTEGER DEFAULT 1,
            fecha_registro  TEXT    DEFAULT (datetime('now','localtime')),
            notas           TEXT
        )
    """)

    # ─────────────────────────────────────────────
    # PROVEEDORES
    # ─────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Proveedores (
            id_proveedor    INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre          TEXT    NOT NULL,
            rif             TEXT    UNIQUE,
            contacto        TEXT,
            telefono        TEXT,
            email           TEXT,
            direccion       TEXT,
            pais            TEXT    DEFAULT 'Venezuela',
            saldo_pendiente REAL    DEFAULT 0.0,
            activo          INTEGER DEFAULT 1,
            fecha_registro  TEXT    DEFAULT (datetime('now','localtime')),
            notas           TEXT
        )
    """)

    # ─────────────────────────────────────────────
    # INVENTARIO (Productos / Repuestos)
    # ─────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Inventario (
            id_producto         INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo              TEXT    UNIQUE NOT NULL,
            descripcion         TEXT    NOT NULL,
            categoria           TEXT,
            marca               TEXT,
            modelo_compatible   TEXT,
            unidad_medida       TEXT    DEFAULT 'PZA',
            costo_unitario      REAL    DEFAULT 0.0,
            precio_venta        REAL    DEFAULT 0.0,
            precio_mayor        REAL    DEFAULT 0.0,
            stock_actual        REAL    DEFAULT 0.0,
            stock_minimo        REAL    DEFAULT 1.0,
            stock_maximo        REAL    DEFAULT 100.0,
            ubicacion           TEXT,
            id_proveedor        INTEGER REFERENCES Proveedores(id_proveedor),
            activo              INTEGER DEFAULT 1,
            fecha_actualizacion TEXT    DEFAULT (datetime('now','localtime')),
            imagen_path         TEXT,
            notas               TEXT
        )
    """)

    # ─────────────────────────────────────────────
    # COTIZACIONES
    # ─────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Cotizaciones (
            id_cotizacion   INTEGER PRIMARY KEY AUTOINCREMENT,
            numero          TEXT    UNIQUE NOT NULL,
            id_cliente      INTEGER REFERENCES Clientes(id_cliente),
            nombre_cliente  TEXT,   -- Para cotizaciones sin cliente registrado
            fecha           TEXT    DEFAULT (datetime('now','localtime')),
            fecha_vencimiento TEXT,
            subtotal        REAL    DEFAULT 0.0,
            descuento       REAL    DEFAULT 0.0,
            impuesto        REAL    DEFAULT 0.0,   -- % IVA
            total           REAL    DEFAULT 0.0,
            estado          TEXT    DEFAULT 'Pendiente',  -- Pendiente / Aprobada / Rechazada / Vencida
            notas           TEXT,
            creado_por      TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS CotizacionDetalle (
            id_detalle      INTEGER PRIMARY KEY AUTOINCREMENT,
            id_cotizacion   INTEGER NOT NULL REFERENCES Cotizaciones(id_cotizacion) ON DELETE CASCADE,
            id_producto     INTEGER REFERENCES Inventario(id_producto),
            descripcion     TEXT    NOT NULL,
            cantidad        REAL    NOT NULL,
            precio_unitario REAL    NOT NULL,
            descuento       REAL    DEFAULT 0.0,
            subtotal        REAL    NOT NULL
        )
    """)

    # ─────────────────────────────────────────────
    # VENTAS
    # ─────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Ventas (
            id_venta        INTEGER PRIMARY KEY AUTOINCREMENT,
            numero_factura  TEXT    UNIQUE NOT NULL,
            id_cliente      INTEGER REFERENCES Clientes(id_cliente),
            nombre_cliente  TEXT,
            id_cotizacion   INTEGER REFERENCES Cotizaciones(id_cotizacion),
            fecha           TEXT    DEFAULT (datetime('now','localtime')),
            subtotal        REAL    DEFAULT 0.0,
            descuento       REAL    DEFAULT 0.0,
            impuesto        REAL    DEFAULT 0.0,
            total           REAL    DEFAULT 0.0,
            monto_pagado    REAL    DEFAULT 0.0,
            saldo           REAL    DEFAULT 0.0,
            forma_pago      TEXT    DEFAULT 'Contado',   -- Contado / Crédito / Mixto
            estado          TEXT    DEFAULT 'Pagada',    -- Pagada / Crédito / Anulada
            notas           TEXT,
            creado_por      TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS VentaDetalle (
            id_detalle      INTEGER PRIMARY KEY AUTOINCREMENT,
            id_venta        INTEGER NOT NULL REFERENCES Ventas(id_venta) ON DELETE CASCADE,
            id_producto     INTEGER REFERENCES Inventario(id_producto),
            descripcion     TEXT    NOT NULL,
            cantidad        REAL    NOT NULL,
            precio_unitario REAL    NOT NULL,
            descuento       REAL    DEFAULT 0.0,
            costo_unitario  REAL    DEFAULT 0.0,  -- Para calcular ganancia
            subtotal        REAL    NOT NULL
        )
    """)

    # ─────────────────────────────────────────────
    # COMPRAS
    # ─────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Compras (
            id_compra       INTEGER PRIMARY KEY AUTOINCREMENT,
            numero_orden    TEXT    UNIQUE NOT NULL,
            id_proveedor    INTEGER REFERENCES Proveedores(id_proveedor),
            nombre_proveedor TEXT,
            fecha           TEXT    DEFAULT (datetime('now','localtime')),
            fecha_entrega   TEXT,
            subtotal        REAL    DEFAULT 0.0,
            descuento       REAL    DEFAULT 0.0,
            impuesto        REAL    DEFAULT 0.0,
            total           REAL    DEFAULT 0.0,
            monto_pagado    REAL    DEFAULT 0.0,
            saldo           REAL    DEFAULT 0.0,
            forma_pago      TEXT    DEFAULT 'Contado',
            estado          TEXT    DEFAULT 'Recibida',  -- Pendiente / Recibida / Pagada / Anulada
            notas           TEXT,
            creado_por      TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS CompraDetalle (
            id_detalle      INTEGER PRIMARY KEY AUTOINCREMENT,
            id_compra       INTEGER NOT NULL REFERENCES Compras(id_compra) ON DELETE CASCADE,
            id_producto     INTEGER REFERENCES Inventario(id_producto),
            descripcion     TEXT    NOT NULL,
            cantidad        REAL    NOT NULL,
            costo_unitario  REAL    NOT NULL,
            subtotal        REAL    NOT NULL
        )
    """)

    # ─────────────────────────────────────────────
    # CUENTAS POR COBRAR (CxC)
    # ─────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS CuentasPorCobrar (
            id_cxc          INTEGER PRIMARY KEY AUTOINCREMENT,
            id_venta        INTEGER REFERENCES Ventas(id_venta),
            id_cliente      INTEGER REFERENCES Clientes(id_cliente),
            numero_factura  TEXT,
            concepto        TEXT,
            monto_original  REAL    NOT NULL,
            monto_pagado    REAL    DEFAULT 0.0,
            saldo           REAL    NOT NULL,
            fecha_emision   TEXT    DEFAULT (datetime('now','localtime')),
            fecha_vencimiento TEXT,
            estado          TEXT    DEFAULT 'Pendiente',  -- Pendiente / Parcial / Pagada / Vencida
            notas           TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS PagosCxC (
            id_pago         INTEGER PRIMARY KEY AUTOINCREMENT,
            id_cxc          INTEGER NOT NULL REFERENCES CuentasPorCobrar(id_cxc),
            fecha           TEXT    DEFAULT (datetime('now','localtime')),
            monto           REAL    NOT NULL,
            forma_pago      TEXT,
            referencia      TEXT,
            notas           TEXT
        )
    """)

    # ─────────────────────────────────────────────
    # CUENTAS POR PAGAR (CxP)
    # ─────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS CuentasPorPagar (
            id_cxp          INTEGER PRIMARY KEY AUTOINCREMENT,
            id_compra       INTEGER REFERENCES Compras(id_compra),
            id_proveedor    INTEGER REFERENCES Proveedores(id_proveedor),
            numero_orden    TEXT,
            concepto        TEXT,
            monto_original  REAL    NOT NULL,
            monto_pagado    REAL    DEFAULT 0.0,
            saldo           REAL    NOT NULL,
            fecha_emision   TEXT    DEFAULT (datetime('now','localtime')),
            fecha_vencimiento TEXT,
            estado          TEXT    DEFAULT 'Pendiente',  -- Pendiente / Parcial / Pagada / Vencida
            notas           TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS PagosCxP (
            id_pago         INTEGER PRIMARY KEY AUTOINCREMENT,
            id_cxp          INTEGER NOT NULL REFERENCES CuentasPorPagar(id_cxp),
            fecha           TEXT    DEFAULT (datetime('now','localtime')),
            monto           REAL    NOT NULL,
            forma_pago      TEXT,
            referencia      TEXT,
            notas           TEXT
        )
    """)

    # ─────────────────────────────────────────────
    # CONFIGURACIÓN DEL SISTEMA
    # ─────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Configuracion (
            clave   TEXT PRIMARY KEY,
            valor   TEXT,
            tipo    TEXT DEFAULT 'texto'
        )
    """)

    # ─────────────────────────────────────────────
    # USUARIOS / SESIONES
    # ─────────────────────────────────────────────
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Usuarios (
            id_usuario  INTEGER PRIMARY KEY AUTOINCREMENT,
            username    TEXT UNIQUE NOT NULL,
            password    TEXT NOT NULL,   -- Hash bcrypt en producción
            nombre      TEXT,
            rol         TEXT DEFAULT 'Vendedor',   -- Admin / Vendedor / Almacen / Solo Lectura
            activo      INTEGER DEFAULT 1,
            ultimo_login TEXT
        )
    """)

    # ─────────────────────────────────────────────
    # DATOS INICIALES
    # ─────────────────────────────────────────────
    _insertar_datos_iniciales(cursor)

    conn.commit()
    conn.close()
    print(f"✅ Base de datos inicializada en: {DB_PATH}")


def _insertar_datos_iniciales(cursor: sqlite3.Cursor):
    """Inserta configuración y datos de ejemplo si las tablas están vacías."""

    # Configuración de la empresa
    configs = [
        ("empresa_nombre",      "Repuestos La Tiendita",    "texto"),
        ("empresa_rif",         "J-12345678-9",             "texto"),
        ("empresa_direccion",   "Tu dirección aquí",        "texto"),
        ("empresa_telefono",    "0000-0000000",              "texto"),
        ("empresa_email",       "contacto@latiendita.com",  "texto"),
        ("moneda_simbolo",      "Bs.",                       "texto"),
        ("iva_porcentaje",      "16",                        "numero"),
        ("siguiente_factura",   "0001",                      "numero"),
        ("siguiente_cotizacion","0001",                      "numero"),
        ("siguiente_orden",     "0001",                      "numero"),
        ("tema_color",          "azul_marino",               "texto"),
    ]
    cursor.executemany("""
        INSERT OR IGNORE INTO Configuracion (clave, valor, tipo)
        VALUES (?, ?, ?)
    """, configs)

    # Usuario administrador por defecto
    cursor.execute("""
        INSERT OR IGNORE INTO Usuarios (username, password, nombre, rol)
        VALUES ('admin', 'admin123', 'Administrador', 'Admin')
    """)

    # Categorías de ejemplo en inventario
    productos_demo = [
        ("REP-001", "Filtro de aceite universal",    "Filtros",   "Mann",   "Universal",  1,  8.50, 15.00, 13.00, 25, 5, 50),
        ("REP-002", "Pastillas de freno delanteras", "Frenos",    "Brembo", "Varios",     1, 22.00, 40.00, 35.00, 10, 2, 30),
        ("REP-003", "Bujías NGK (c/u)",              "Encendido", "NGK",    "Universal",  1,  3.00,  6.50,  5.50, 40, 8, 80),
        ("REP-004", "Correa de distribución",        "Motor",     "Gates",  "Varios",     1, 18.00, 35.00, 30.00,  8, 2, 20),
        ("REP-005", "Aceite de motor 1L 20W-50",     "Lubricantes","Mobil", "Universal",  1,  5.50, 10.00,  8.50, 60, 12,100),
    ]
    cursor.executemany("""
        INSERT OR IGNORE INTO Inventario
            (codigo, descripcion, categoria, marca, modelo_compatible, activo,
             costo_unitario, precio_venta, precio_mayor,
             stock_actual, stock_minimo, stock_maximo)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
    """, productos_demo)

    # Clientes de ejemplo
    clientes_demo = [
        ("Cliente General", None, None, None, None, "Regular", 0.0),
        ("Taller Mecánico Pérez", "V-12345678", "0412-1234567", "taller@email.com", "Av. Principal", "Mayorista", 5000.0),
        ("Auto Repuestos Norte", "J-98765432-1", "0424-7654321", "norte@email.com", "Calle 5", "VIP", 10000.0),
    ]
    cursor.executemany("""
        INSERT OR IGNORE INTO Clientes (nombre, rif_cedula, telefono, email, direccion, tipo_cliente, limite_credito)
        VALUES (?,?,?,?,?,?,?)
    """, clientes_demo)

    # Proveedores de ejemplo
    proveedores_demo = [
        ("Distribuidora AutoParts", "J-11111111-1", "Carlos López", "0212-1234567", "ventas@autoparts.com", "Caracas"),
        ("Importadora Motorex",     "J-22222222-2", "Ana García",   "0212-7654321", "info@motorex.com",    "Valencia"),
    ]
    cursor.executemany("""
        INSERT OR IGNORE INTO Proveedores (nombre, rif, contacto, telefono, email, direccion)
        VALUES (?,?,?,?,?,?)
    """, proveedores_demo)


def obtener_config(clave: str, default: str = "") -> str:
    """Obtiene un valor de configuración por su clave."""
    conn = get_connection()
    row = conn.execute("SELECT valor FROM Configuracion WHERE clave = ?", (clave,)).fetchone()
    conn.close()
    return row["valor"] if row else default


def actualizar_config(clave: str, valor: str):
    """Actualiza un valor de configuración."""
    conn = get_connection()
    conn.execute("INSERT OR REPLACE INTO Configuracion (clave, valor) VALUES (?, ?)", (clave, valor))
    conn.commit()
    conn.close()


def siguiente_numero(tipo: str) -> str:
    """
    Genera el siguiente número correlativo para facturas, cotizaciones u órdenes.
    tipo: 'factura' | 'cotizacion' | 'orden'
    """
    claves = {
        "factura":    "siguiente_factura",
        "cotizacion": "siguiente_cotizacion",
        "orden":      "siguiente_orden",
    }
    prefijos = {
        "factura":    "FAC-",
        "cotizacion": "COT-",
        "orden":      "OC-",
    }
    clave = claves.get(tipo, "siguiente_factura")
    prefijo = prefijos.get(tipo, "DOC-")

    numero_actual = int(obtener_config(clave, "1"))
    numero_formateado = f"{prefijo}{numero_actual:05d}"
    actualizar_config(clave, str(numero_actual + 1))
    return numero_formateado


if __name__ == "__main__":
    inicializar_base_de_datos()
