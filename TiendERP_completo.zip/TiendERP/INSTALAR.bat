@echo off
setlocal enabledelayedexpansion
title Instalador ERP Repuestos La Tiendita
color 0A

echo.
echo  =====================================================
echo   Instalador ERP - Repuestos La Tiendita
echo  =====================================================
echo.

:: ── Buscar Python en todas las ubicaciones posibles ──────────
set PYTHON=

:: Opcion 1: python en PATH normal
python --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON=python
    goto :encontrado
)

:: Opcion 2: py launcher (Windows Store o instalador oficial)
py --version >nul 2>&1
if not errorlevel 1 (
    set PYTHON=py
    goto :encontrado
)

:: Opcion 3: rutas comunes de instalacion manual
for %%P in (
    "C:\Python312\python.exe"
    "C:\Python311\python.exe"
    "C:\Python310\python.exe"
    "C:\Python39\python.exe"
    "C:\Program Files\Python312\python.exe"
    "C:\Program Files\Python311\python.exe"
    "C:\Program Files\Python310\python.exe"
    "C:\Users\%USERNAME%\AppData\Local\Programs\Python\Python312\python.exe"
    "C:\Users\%USERNAME%\AppData\Local\Programs\Python\Python311\python.exe"
    "C:\Users\%USERNAME%\AppData\Local\Programs\Python\Python310\python.exe"
    "C:\Users\%USERNAME%\AppData\Local\Microsoft\WindowsApps\python3.exe"
    "C:\Users\%USERNAME%\AppData\Local\Microsoft\WindowsApps\python.exe"
) do (
    if exist %%P (
        set PYTHON=%%P
        goto :encontrado
    )
)

:: No se encontro Python
echo  [!] Python no esta instalado en esta computadora.
echo.
echo  Vamos a descargarlo e instalarlo automaticamente...
echo.

:: Descargar Python con PowerShell
powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile '%TEMP%\python_installer.exe'}" >nul 2>&1

if exist "%TEMP%\python_installer.exe" (
    echo  Instalando Python 3.11 - por favor espere...
    echo  (Esto puede tardar 1-2 minutos)
    echo.
    "%TEMP%\python_installer.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0
    del "%TEMP%\python_installer.exe"

    :: Recargar PATH
    call refreshenv >nul 2>&1
    set "PATH=%PATH%;%LOCALAPPDATA%\Programs\Python\Python311;%LOCALAPPDATA%\Programs\Python\Python311\Scripts"

    python --version >nul 2>&1
    if not errorlevel 1 (
        set PYTHON=python
        echo  [OK] Python instalado correctamente
        goto :encontrado
    )
) 

echo.
echo  =====================================================
echo   ERROR: No se pudo instalar Python automaticamente
echo  =====================================================
echo.
echo  Por favor instale Python manualmente:
echo.
echo  1. Abra su navegador
echo  2. Vaya a:  https://www.python.org/downloads/
echo  3. Descargue Python 3.11 o superior
echo  4. Al instalar, MARQUE la casilla:
echo     [x] Add Python to PATH
echo  5. Luego vuelva a ejecutar este archivo
echo.
pause
exit /b 1

:encontrado
echo  [OK] Python encontrado
%PYTHON% --version
echo.

:: ── Instalar dependencias una por una (mas estable) ──────────
echo  Instalando librerias necesarias...
echo  (Esto puede tardar 3-5 minutos la primera vez)
echo.

echo  [1/5] Instalando customtkinter...
%PYTHON% -m pip install customtkinter --quiet --no-warn-script-location
echo      listo.

echo  [2/5] Instalando Pillow...
%PYTHON% -m pip install Pillow --quiet --no-warn-script-location
echo      listo.

echo  [3/5] Instalando fpdf2...
%PYTHON% -m pip install fpdf2 --quiet --no-warn-script-location
echo      listo.

echo  [4/5] Instalando openpyxl...
%PYTHON% -m pip install openpyxl --quiet --no-warn-script-location
echo      listo.

echo  [5/5] Instalando PyInstaller...
%PYTHON% -m pip install pyinstaller --quiet --no-warn-script-location
echo      listo.

echo.
echo  [OK] Todas las librerias instaladas
echo.

:: ── Crear acceso directo para ejecutar el ERP ─────────────────
echo  Creando acceso directo en el Escritorio...

set "DIR_ACTUAL=%~dp0"
set "DIR_ACTUAL=%DIR_ACTUAL:~0,-1%"

:: Crear script lanzador .bat en la misma carpeta
echo @echo off > "%DIR_ACTUAL%\ERP_Tiendita.bat"
echo cd /d "%DIR_ACTUAL%" >> "%DIR_ACTUAL%\ERP_Tiendita.bat"
echo %PYTHON% main.py >> "%DIR_ACTUAL%\ERP_Tiendita.bat"

:: Crear acceso directo en el escritorio
powershell -Command "& { $s=(New-Object -COM WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\TiendERP.lnk'); $s.TargetPath='%DIR_ACTUAL%\ERP_Tiendita.bat'; $s.WorkingDirectory='%DIR_ACTUAL%'; $s.WindowStyle=7; $s.Description='ERP Repuestos La Tiendita'; $s.Save() }" >nul 2>&1

echo  [OK] Acceso directo creado en el Escritorio

:: ── Verificacion final ────────────────────────────────────────
echo.
echo  Verificando instalacion...
%PYTHON% -c "import customtkinter, PIL, fpdf; print('  [OK] Todo listo')" 2>nul
if errorlevel 1 (
    echo  [!] Alguna libreria no se instalo bien, pero intentaremos ejecutar igual
)

:: ── Preguntar si iniciar el ERP ahora ────────────────────────
echo.
echo  =====================================================
echo   INSTALACION COMPLETADA
echo  =====================================================
echo.
echo   Para abrir el ERP en el futuro:
echo   - Use el acceso directo "TiendERP" en el Escritorio
echo   - O haga doble clic en ERP_Tiendita.bat
echo.
echo  Presione cualquier tecla para INICIAR el ERP ahora...
pause >nul

cd /d "%DIR_ACTUAL%"
start "" %PYTHON% main.py
