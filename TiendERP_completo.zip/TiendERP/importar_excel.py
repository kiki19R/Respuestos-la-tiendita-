"""
importar_excel.py
Importa todos los datos del Excel 'exel_respuesto_la_tiendita.xlsx'
a la base de datos SQLite del ERP Repuestos La Tiendita.

Estrategia:
  - Proveedores y Clientes: INSERT OR IGNORE por nombre (no duplicar)
  - Inventario: INSERT OR REPLACE por código (actualiza si ya existe)
  - Compras / Ventas: se limpian y reimportan completas
  - CxC / CxP / Cotizaciones: vacíos en el Excel, se dejan intactos
"""

import sys
import os
import sqlite3
from openpyxl import load_workbook

# ── Rutas ────────────────────────────────────────────────────
BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
EXCEL_PATH = "/mnt/user-data/uploads/exel_respuesto_la_tiendita.xlsx"
DB_PATH    = os.path.join(BASE_DIR, "tiendita_erp.db")

# ── Helpers ──────────────────────────────────────────────────
def _f(val, default=0.0):
    """Convierte a float de forma segura."""
    try:
        return float(val) if val not in (None, "", "N/A") else default
    except (ValueError, TypeError):
        return default

def _s(val, default=""):
    """Convierte a str de forma segura."""
    return str(val).strip() if val not in (None, "") else default

def _fecha(val):
    """Normaliza fecha a ISO (YYYY-MM-DD). Acepta DD/MM/YYYY y DD/MM/YY."""
    if val is None:
        return None
    s = str(val).strip()
    for fmt in ("%d/%m/%Y", "%d/%m/%y", "%Y-%m-%d"):
        try:
            from datetime import datetime
            return datetime.strptime(s, fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return s  # devuelve tal cual si no reconoce el formato

def rows(ws, min_row=2):
    """Itera solo filas con al menos un valor no nulo en la columna A."""
    for r in ws.iter_rows(min_row=min_row, values_only=True):
        if r[0] is not None:
            yield r

# ─────────────────────────────────────────────────────────────
# IMPORTAR
# ─────────────────────────────────────────────────────────────
def importar():
    print(f"\n📂 Leyendo Excel: {EXCEL_PATH}")
    wb = load_workbook(EXCEL_PATH, read_only=True, data_only=True)

    print(f"🗄️  Base de datos:  {DB_PATH}\n")
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = OFF")   # Off durante la importación masiva
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    totales = {}

    # ══════════════════════════════════════════════════════════
    # 1. PROVEEDORES
    # ══════════════════════════════════════════════════════════
    print("🏭 Importando Proveedores...")
    ws = wb["Proveedores"]
    # Cols: ID Proveedor | Nombre | Contacto | Teléfono | Correo | Notas
    n = 0
    for r in rows(ws):
        nombre   = _s(r[1])
        contacto = _s(r[2])
        telefono = _s(r[3])
        email    = _s(r[4])
        notas    = _s(r[5])
        if not nombre:
            continue
        existe = cur.execute("SELECT id_proveedor FROM Proveedores WHERE nombre=?", (nombre,)).fetchone()
        if existe:
            cur.execute("UPDATE Proveedores SET contacto=?,telefono=?,email=?,notas=? WHERE nombre=?",
                        (contacto, telefono, email, notas, nombre))
        else:
            cur.execute("INSERT INTO Proveedores (nombre,contacto,telefono,email,notas) VALUES (?,?,?,?,?)",
                        (nombre, contacto, telefono, email, notas))
        n += 1
    totales["Proveedores"] = n
    print(f"   ✅ {n} proveedores procesados")

    # Mapa nombre → id para uso posterior
    prov_map = {r["nombre"]: r["id_proveedor"]
                for r in cur.execute("SELECT id_proveedor, nombre FROM Proveedores").fetchall()}

    # ══════════════════════════════════════════════════════════
    # 2. CLIENTES
    # ══════════════════════════════════════════════════════════
    print("👥 Importando Clientes...")
    ws = wb["Clientes"]
    # Cols: ID Cliente | Nombre | Teléfono | Correo | Dirección | Notas
    n = 0
    for r in rows(ws):
        nombre   = _s(r[1])
        telefono = _s(r[2])
        email    = _s(r[3])
        direccion= _s(r[4])
        notas    = _s(r[5])
        if not nombre:
            continue
        existe = cur.execute("SELECT id_cliente FROM Clientes WHERE nombre=?", (nombre,)).fetchone()
        if not existe:
            cur.execute("INSERT INTO Clientes (nombre,telefono,email,direccion,notas) VALUES (?,?,?,?,?)",
                        (nombre, telefono, email, direccion, notas))
        n += 1
    totales["Clientes"] = n
    print(f"   ✅ {n} clientes procesados")

    # Mapa nombre → id
    cli_map = {r["nombre"]: r["id_cliente"]
               for r in cur.execute("SELECT id_cliente, nombre FROM Clientes").fetchall()}

    # ══════════════════════════════════════════════════════════
    # 3. INVENTARIO
    # ══════════════════════════════════════════════════════════
    print("📦 Importando Inventario...")
    ws = wb["Inventario"]
    # Cols: Código | Pieza | Categoría | Stock | Stock Mínimo | Costo Unit. | Precio Venta | % Margen | Estado | Notas
    n = 0
    for r in rows(ws):
        codigo      = _s(r[0])
        descripcion = _s(r[1])
        categoria   = _s(r[2])
        stock       = _f(r[3])
        stock_min   = _f(r[4], 1.0)
        costo       = _f(r[5])
        precio      = _f(r[6])
        notas       = _s(r[9])

        if not codigo or not descripcion:
            continue

        cur.execute("""
            INSERT OR REPLACE INTO Inventario
                (codigo, descripcion, categoria, stock_actual, stock_minimo,
                 costo_unitario, precio_venta, precio_mayor, activo, notas)
            VALUES (?,?,?,?,?,?,?,?,1,?)
        """, (codigo, descripcion, categoria, stock, stock_min,
              costo, precio, precio * 0.9 if precio else 0, notas))
        n += 1
    totales["Inventario"] = n
    print(f"   ✅ {n} productos procesados")

    # Mapa código → id_producto
    prod_map = {r["codigo"]: r["id_producto"]
                for r in cur.execute("SELECT id_producto, codigo FROM Inventario").fetchall()}

    # ══════════════════════════════════════════════════════════
    # 4. COMPRAS
    # Estructura Excel: línea por línea (1 ítem por fila)
    # Agrupamos por # Compra para crear cabecera + detalle
    # ══════════════════════════════════════════════════════════
    print("🛒 Importando Compras...")
    ws = wb["Compras"]
    # Cols: # Compra | Fecha | ID Proveedor | Proveedor | Código | Pieza | Cantidad | Costo Unit. | Costo Total

    # Limpiar compras previas importadas
    cur.execute("DELETE FROM CompraDetalle")
    cur.execute("DELETE FROM Compras")

    compras_dict = {}   # num_compra → {cabecera, líneas}
    for r in rows(ws):
        num      = int(r[0])
        fecha    = _fecha(r[1])
        id_prov_excel = r[2]
        nom_prov = _s(r[3])
        codigo   = _s(r[4])
        pieza    = _s(r[5])
        cant     = _f(r[6])
        costo_u  = _f(r[7])
        costo_t  = _f(r[8])

        id_prov_db = prov_map.get(nom_prov)

        if num not in compras_dict:
            compras_dict[num] = {
                "fecha": fecha, "id_prov": id_prov_db, "nom_prov": nom_prov,
                "lineas": []
            }
        compras_dict[num]["lineas"].append({
            "codigo": codigo, "pieza": pieza,
            "cant": cant, "costo_u": costo_u, "total": costo_t
        })

    nc = 0
    for num, data in sorted(compras_dict.items()):
        total_compra = sum(l["total"] for l in data["lineas"])
        numero_orden = f"OC-{num:05d}"
        cur.execute("""
            INSERT INTO Compras
                (numero_orden, id_proveedor, nombre_proveedor, fecha,
                 subtotal, total, monto_pagado, saldo, estado, forma_pago)
            VALUES (?,?,?,?,?,?,?,?,'Recibida','Contado')
        """, (numero_orden, data["id_prov"], data["nom_prov"],
              data["fecha"], total_compra, total_compra, total_compra, 0))
        id_compra = cur.lastrowid

        for l in data["lineas"]:
            id_prod = prod_map.get(l["codigo"])
            cur.execute("""
                INSERT INTO CompraDetalle
                    (id_compra, id_producto, descripcion, cantidad, costo_unitario, subtotal)
                VALUES (?,?,?,?,?,?)
            """, (id_compra, id_prod, l["pieza"], l["cant"], l["costo_u"], l["total"]))
        nc += 1

    totales["Compras"] = nc
    print(f"   ✅ {nc} órdenes de compra importadas ({sum(len(d['lineas']) for d in compras_dict.values())} líneas)")

    # ══════════════════════════════════════════════════════════
    # 5. VENTAS
    # Estructura igual: 1 ítem por fila, agrupamos por # Venta
    # ══════════════════════════════════════════════════════════
    print("🧾 Importando Ventas...")
    ws = wb["Ventas"]
    # Cols: # Venta | Fecha | ID Cliente | Cliente | Código | Pieza | Cantidad | Precio Unit. | Total | Utilidad

    cur.execute("DELETE FROM VentaDetalle")
    cur.execute("DELETE FROM Ventas")

    ventas_dict = {}
    for r in rows(ws):
        num     = int(r[0])
        fecha   = _fecha(r[1])
        nom_cli = _s(r[3]) if r[3] else None
        codigo  = _s(r[4])
        pieza   = _s(r[5])
        cant    = _f(r[6])
        precio_u= _f(r[7])
        total_l = _f(r[8])
        utilidad= _f(r[9])
        costo_u = precio_u - (utilidad / cant if cant else 0)

        id_cli_db = cli_map.get(nom_cli) if nom_cli else None

        if num not in ventas_dict:
            ventas_dict[num] = {
                "fecha": fecha, "id_cli": id_cli_db, "nom_cli": nom_cli,
                "lineas": []
            }
        ventas_dict[num]["lineas"].append({
            "codigo": codigo, "pieza": pieza,
            "cant": cant, "precio_u": precio_u,
            "total": total_l, "costo_u": costo_u
        })

    nv = 0
    for num, data in sorted(ventas_dict.items()):
        total_venta = sum(l["total"] for l in data["lineas"])
        numero_fac  = f"FAC-{num:05d}"
        cur.execute("""
            INSERT INTO Ventas
                (numero_factura, id_cliente, nombre_cliente, fecha,
                 subtotal, total, monto_pagado, saldo, estado, forma_pago)
            VALUES (?,?,?,?,?,?,?,?,'Pagada','Contado')
        """, (numero_fac, data["id_cli"], data["nom_cli"],
              data["fecha"], total_venta, total_venta, total_venta, 0))
        id_venta = cur.lastrowid

        for l in data["lineas"]:
            id_prod = prod_map.get(l["codigo"])
            cur.execute("""
                INSERT INTO VentaDetalle
                    (id_venta, id_producto, descripcion, cantidad,
                     precio_unitario, costo_unitario, subtotal)
                VALUES (?,?,?,?,?,?,?)
            """, (id_venta, id_prod, l["pieza"], l["cant"],
                  l["precio_u"], l["costo_u"], l["total"]))
        nv += 1

    totales["Ventas"] = nv
    print(f"   ✅ {nv} facturas importadas ({sum(len(d['lineas']) for d in ventas_dict.values())} líneas)")

    # ══════════════════════════════════════════════════════════
    # 6. Actualizar numeración correlativa para no pisar lo importado
    # ══════════════════════════════════════════════════════════
    max_fac = max(ventas_dict.keys()) + 1 if ventas_dict else 1
    max_oc  = max(compras_dict.keys()) + 1 if compras_dict else 1
    cur.execute("INSERT OR REPLACE INTO Configuracion (clave,valor) VALUES ('siguiente_factura',?)", (str(max_fac),))
    cur.execute("INSERT OR REPLACE INTO Configuracion (clave,valor) VALUES ('siguiente_orden',?)",   (str(max_oc),))

    # ══════════════════════════════════════════════════════════
    # COMMIT Y RESUMEN
    # ══════════════════════════════════════════════════════════
    conn.commit()
    conn.close()

    print("\n" + "═" * 50)
    print("  ✅  IMPORTACIÓN COMPLETADA")
    print("═" * 50)
    for tabla, n in totales.items():
        print(f"  {tabla:<20} {n:>4} registros")
    print("═" * 50)
    print(f"  Próxima factura:  FAC-{max_fac:05d}")
    print(f"  Próxima orden:    OC-{max_oc:05d}")
    print("═" * 50 + "\n")


if __name__ == "__main__":
    importar()
